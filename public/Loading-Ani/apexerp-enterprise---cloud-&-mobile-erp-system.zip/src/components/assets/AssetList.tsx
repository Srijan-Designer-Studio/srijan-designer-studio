import React, { useState } from 'react';
import { Briefcase, Plus, Search, Download, X } from 'lucide-react';
import { db } from '../../lib/db';
import { FixedAsset } from '../../types/erp';
import { exportToCSV } from '../../lib/exportUtils';

export const AssetList: React.FC = () => {
  const dbState = db.getState();
  const company = db.getCurrentCompany();

  const [search, setSearch] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  // New Asset Form
  const [name, setName] = useState('');
  const [category, setCategory] = useState<FixedAsset['category']>('Computers');
  const [purchaseCost, setPurchaseCost] = useState(50000);
  const [purchaseDate, setPurchaseDate] = useState(new Date().toISOString().split('T')[0]);
  const [assignedEmployee, setAssignedEmployee] = useState('');
  const [location, setLocation] = useState('Headquarters');
  const [depreciation, setDepreciation] = useState(15);

  const filtered = dbState.assets.filter((a) => {
    return (
      a.name.toLowerCase().includes(search.toLowerCase()) ||
      a.asset_code.toLowerCase().includes(search.toLowerCase()) ||
      a.category.toLowerCase().includes(search.toLowerCase())
    );
  });

  const totalAssetValue = dbState.assets.reduce((acc, a) => acc + a.current_value, 0);

  const handleExport = () => {
    const rows = filtered.map((a) => ({
      Asset_Code: a.asset_code,
      Name: a.name,
      Category: a.category,
      Purchase_Date: a.purchase_date,
      Purchase_Cost: a.purchase_cost,
      Current_Value: a.current_value,
      Location: a.location || '',
      Assigned_To: a.assigned_employee_name || '',
      Status: a.status,
    }));
    exportToCSV(`Fixed_Assets_${company.name.replace(/\s+/g, '_')}`, rows);
  };

  const handleCreateAsset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const assetCode = `AST-${category.slice(0, 3).toUpperCase()}-${(dbState.assets.length + 1).toString().padStart(3, '0')}`;
    const cost = Number(purchaseCost);

    db.addAsset({
      asset_code: assetCode,
      name: name.trim(),
      category,
      purchase_date: purchaseDate,
      purchase_cost: cost,
      assigned_employee_name: assignedEmployee.trim() || undefined,
      location: location.trim(),
      depreciation_rate: Number(depreciation),
      current_value: cost,
      status: 'In Use',
    });

    setShowAddModal(false);
    setName('');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-2xl">
            Fixed Asset Management
          </h1>
          <p className="text-xs text-slate-500">
            Track hardware, vehicles, machinery, depreciation, employee assignments, and location tags.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300"
          >
            <Download className="h-4 w-4" />
            Export CSV
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-md hover:bg-indigo-700 transition"
          >
            <Plus className="h-4 w-4" />
            Register Asset
          </button>
        </div>
      </div>

      {/* Summary */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900 flex items-center justify-between">
        <div>
          <p className="text-xs text-slate-500">Total Book Valuation of Assets</p>
          <p className="text-xl font-bold text-slate-900 dark:text-white">
            ₹{totalAssetValue.toLocaleString('en-IN')}
          </p>
        </div>
        <div className="relative max-w-xs w-full">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search assets by code, category..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 py-1.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
          />
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((asset) => (
          <div
            key={asset.id}
            className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between">
                <div>
                  <span className="rounded bg-indigo-50 px-2 py-0.5 text-[10px] font-bold font-mono text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300">
                    {asset.asset_code}
                  </span>
                  <h3 className="mt-2 text-sm font-bold text-slate-900 dark:text-white">
                    {asset.name}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium">{asset.category}</p>
                </div>
                <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                  {asset.status}
                </span>
              </div>

              <div className="mt-4 space-y-1 text-xs text-slate-600 dark:text-slate-400">
                <p><span className="text-slate-400">Purchased:</span> {asset.purchase_date}</p>
                <p><span className="text-slate-400">Location:</span> {asset.location}</p>
                {asset.assigned_employee_name && (
                  <p><span className="text-slate-400">Assigned To:</span> {asset.assigned_employee_name}</p>
                )}
                <p><span className="text-slate-400">Depreciation:</span> {asset.depreciation_rate}% p.a.</p>
              </div>
            </div>

            <div className="mt-5 border-t border-slate-100 pt-3 dark:border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-400">Current Book Value</span>
              <span className="font-bold font-mono text-slate-900 dark:text-white">
                ₹{asset.current_value.toLocaleString('en-IN')}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Add Asset Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Register Fixed Asset</h3>
              <button onClick={() => setShowAddModal(false)} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCreateAsset} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Asset Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Dell PowerEdge R750 Server"
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    <option value="Computers">Computers & IT</option>
                    <option value="Vehicles">Vehicles</option>
                    <option value="Furniture">Furniture & Fixtures</option>
                    <option value="Machinery">Machinery & Plant</option>
                    <option value="Office Equipment">Office Equipment</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Purchase Cost (₹)</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={purchaseCost}
                    onChange={(e) => setPurchaseCost(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Location</label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="Headquarters Rack 01"
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Assigned Staff</label>
                  <input
                    type="text"
                    value={assignedEmployee}
                    onChange={(e) => setAssignedEmployee(e.target.value)}
                    placeholder="Optional employee name"
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-indigo-600 px-5 py-2 text-xs font-bold text-white shadow hover:bg-indigo-700"
                >
                  Register Asset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
