import React, { useState } from 'react';
import { 
  BookOpen, 
  Layers, 
  FileText, 
  Scale, 
  BarChart, 
  Download, 
  Printer, 
  CheckCircle2,
  DollarSign
} from 'lucide-react';
import { db } from '../../lib/db';
import { exportToCSV, printDocument } from '../../lib/exportUtils';

export const AccountingHub: React.FC = () => {
  const dbState = db.getState();
  const company = db.getCurrentCompany();

  const [activeTab, setActiveTab] = useState<'COA' | 'JOURNALS' | 'TRIAL_BALANCE' | 'PL' | 'BALANCE_SHEET'>('COA');

  // Calculation for P&L
  const totalRevenue = dbState.invoices.reduce((acc, i) => acc + i.taxable_amount, 0);
  const costOfGoodsSold = dbState.purchaseBills.reduce((acc, b) => acc + b.taxable_amount, 0);
  const grossProfit = totalRevenue - costOfGoodsSold;
  const totalOperatingExpenses = dbState.expenses.reduce((acc, e) => acc + e.amount, 0);
  const netProfit = grossProfit - totalOperatingExpenses;

  // Calculation for Balance Sheet
  const bankBalance = dbState.accounts.find(a => a.id === 'acc-bank-01')?.current_balance || 485200;
  const cashBalance = dbState.accounts.find(a => a.id === 'acc-cash-01')?.current_balance || 24500;
  const accountsReceivable = dbState.customers.reduce((acc, c) => acc + c.current_balance, 0);
  const inventoryAssetValuation = dbState.products.reduce((acc, p) => acc + (p.current_stock * p.purchase_price), 0);
  const itcAsset = dbState.purchaseBills.reduce((acc, b) => acc + (b.cgst + b.sgst + b.igst), 0);

  const totalCurrentAssets = bankBalance + cashBalance + accountsReceivable + inventoryAssetValuation + itcAsset;
  const fixedAssetsTotal = dbState.assets.reduce((acc, a) => acc + a.current_value, 0);
  const totalAssets = totalCurrentAssets + fixedAssetsTotal;

  const accountsPayable = dbState.suppliers.reduce((acc, s) => acc + s.current_balance, 0);
  const gstOutputLiability = dbState.invoices.reduce((acc, i) => acc + (i.cgst + i.sgst + i.igst), 0);
  const totalLiabilities = accountsPayable + gstOutputLiability;

  const initialCapital = 2000000;
  const totalEquity = initialCapital + netProfit;

  const handleExportCOA = () => {
    const rows = dbState.accounts.map(a => ({
      Code: a.account_code,
      Name: a.account_name,
      Type: a.account_type,
      Subtype: a.sub_type,
      Balance: a.current_balance,
    }));
    exportToCSV(`Chart_of_Accounts_${company.name.replace(/\s+/g, '_')}`, rows);
  };

  const handleExportTrialBalance = () => {
    const rows = dbState.accounts.map(a => ({
      Code: a.account_code,
      Account_Name: a.account_name,
      Debit: a.account_type === 'Asset' || a.account_type === 'Expense' ? a.current_balance : 0,
      Credit: a.account_type === 'Liability' || a.account_type === 'Revenue' || a.account_type === 'Equity' ? a.current_balance : 0,
    }));
    exportToCSV(`Trial_Balance_${company.name.replace(/\s+/g, '_')}`, rows);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-2xl">
            Double-Entry Accounting System
          </h1>
          <p className="text-xs text-slate-500">
            Real-time General Ledger, balanced Journal Entries, P&L Statement, and Balance Sheet.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={printDocument}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300"
          >
            <Printer className="h-4 w-4" />
            Print Report
          </button>
        </div>
      </div>

      {/* Accounting Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-2 dark:border-slate-800">
        {[
          { id: 'COA', label: 'Chart of Accounts', icon: Layers },
          { id: 'JOURNALS', label: 'General Journal Entries', icon: BookOpen },
          { id: 'TRIAL_BALANCE', label: 'Trial Balance', icon: Scale },
          { id: 'PL', label: 'Profit & Loss (P&L)', icon: BarChart },
          { id: 'BALANCE_SHEET', label: 'Balance Sheet', icon: FileText },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'bg-white text-slate-600 hover:bg-slate-100 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. CHART OF ACCOUNTS */}
      {activeTab === 'COA' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Chart of Accounts (COA)</h3>
            <button
              onClick={handleExportCOA}
              className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:underline"
            >
              <Download className="h-3.5 w-3.5" /> Export COA
            </button>
          </div>

          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:bg-slate-800/50 dark:border-slate-800">
                <tr>
                  <th className="p-3.5">Code</th>
                  <th className="p-3.5">Account Name</th>
                  <th className="p-3.5">Category</th>
                  <th className="p-3.5">Sub-Classification</th>
                  <th className="p-3.5 text-right">Current Balance</th>
                  <th className="p-3.5 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {dbState.accounts.map((acc) => (
                  <tr key={acc.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                    <td className="p-3.5 font-bold font-mono text-indigo-600">{acc.account_code}</td>
                    <td className="p-3.5 font-semibold text-slate-900 dark:text-white">{acc.account_name}</td>
                    <td className="p-3.5">
                      <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                        acc.account_type === 'Asset'
                          ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                          : acc.account_type === 'Liability'
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                          : acc.account_type === 'Revenue'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                      }`}>
                        {acc.account_type}
                      </span>
                    </td>
                    <td className="p-3.5 text-slate-500">{acc.sub_type}</td>
                    <td className="p-3.5 text-right font-mono font-bold text-slate-900 dark:text-white">
                      ₹{acc.current_balance.toLocaleString('en-IN')}
                    </td>
                    <td className="p-3.5 text-center">
                      <span className="flex items-center justify-center gap-1 text-[10px] text-emerald-600 font-bold">
                        <CheckCircle2 className="h-3 w-3" /> Active
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 2. GENERAL JOURNAL ENTRIES */}
      {activeTab === 'JOURNALS' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Balanced Journal Entries</h3>
            <span className="text-xs text-slate-400">Total Entries: {dbState.journalEntries.length}</span>
          </div>

          <div className="space-y-4">
            {dbState.journalEntries.length === 0 ? (
              <div className="rounded-2xl border border-slate-200 bg-white p-12 text-center text-xs text-slate-400 dark:border-slate-800 dark:bg-slate-900">
                No automated journal entries generated yet. Creating an invoice, bill, or expense will record balanced double entries automatically.
              </div>
            ) : (
              dbState.journalEntries.map((je) => (
                <div key={je.id} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900 space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2 dark:border-slate-800 text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-bold font-mono text-indigo-600 dark:text-indigo-400">{je.entry_number}</span>
                      <span className="text-slate-400">•</span>
                      <span className="text-slate-500">{je.entry_date}</span>
                      <span className="text-slate-400">•</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">{je.description}</span>
                    </div>
                    <span className="rounded bg-slate-100 px-2 py-0.5 text-[10px] font-mono font-medium dark:bg-slate-800">
                      Ref: {je.reference_type}
                    </span>
                  </div>

                  <table className="w-full text-left text-xs">
                    <thead className="text-[10px] font-bold uppercase text-slate-400">
                      <tr>
                        <th className="pb-1">Account & Narration</th>
                        <th className="pb-1 text-right w-32">Debit (Dr.)</th>
                        <th className="pb-1 text-right w-32">Credit (Cr.)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800/50">
                      {je.lines.map((line, idx) => (
                        <tr key={idx}>
                          <td className="py-1.5">
                            <p className="font-medium text-slate-800 dark:text-slate-200">{line.account_name}</p>
                            {line.narration && <p className="text-[10px] text-slate-400">{line.narration}</p>}
                          </td>
                          <td className="py-1.5 text-right font-mono font-semibold text-slate-900 dark:text-white">
                            {line.debit > 0 ? `₹${line.debit.toLocaleString('en-IN')}` : '—'}
                          </td>
                          <td className="py-1.5 text-right font-mono font-semibold text-slate-900 dark:text-white">
                            {line.credit > 0 ? `₹${line.credit.toLocaleString('en-IN')}` : '—'}
                          </td>
                        </tr>
                      ))}
                      <tr className="border-t border-slate-200 font-bold dark:border-slate-700">
                        <td className="pt-2 text-right text-slate-500">Totals:</td>
                        <td className="pt-2 text-right font-mono text-indigo-600">₹{je.total_debit.toLocaleString('en-IN')}</td>
                        <td className="pt-2 text-right font-mono text-indigo-600">₹{je.total_credit.toLocaleString('en-IN')}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* 3. TRIAL BALANCE */}
      {activeTab === 'TRIAL_BALANCE' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Trial Balance (General Ledger Balances)</h3>
            <button
              onClick={handleExportTrialBalance}
              className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:underline"
            >
              <Download className="h-3.5 w-3.5" /> Export Trial Balance
            </button>
          </div>

          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:bg-slate-800/50 dark:border-slate-800">
                <tr>
                  <th className="p-3.5">Account Code</th>
                  <th className="p-3.5">Account Title</th>
                  <th className="p-3.5 text-right w-44">Debit (Dr.) ₹</th>
                  <th className="p-3.5 text-right w-44">Credit (Cr.) ₹</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {dbState.accounts.map((acc) => {
                  const isDebitNature = acc.account_type === 'Asset' || acc.account_type === 'Expense';
                  return (
                    <tr key={acc.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="p-3.5 font-bold font-mono text-indigo-600">{acc.account_code}</td>
                      <td className="p-3.5 font-semibold text-slate-900 dark:text-white">{acc.account_name}</td>
                      <td className="p-3.5 text-right font-mono font-medium">
                        {isDebitNature ? `₹${acc.current_balance.toLocaleString('en-IN')}` : '—'}
                      </td>
                      <td className="p-3.5 text-right font-mono font-medium">
                        {!isDebitNature ? `₹${acc.current_balance.toLocaleString('en-IN')}` : '—'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. PROFIT & LOSS STATEMENT */}
      {activeTab === 'PL' && (
        <div className="mx-auto max-w-3xl rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 space-y-6">
          <div className="border-b border-slate-200 pb-4 text-center dark:border-slate-800">
            <h2 className="text-base font-bold uppercase tracking-wider text-slate-900 dark:text-white">
              Statement of Profit and Loss
            </h2>
            <p className="text-xs text-slate-500">
              For the Period Ended Today • Currency: INR (₹)
            </p>
          </div>

          <div className="space-y-4 text-xs font-mono">
            {/* Income */}
            <div>
              <p className="font-sans font-bold uppercase text-slate-400 text-[11px] pb-1 border-b border-slate-100 dark:border-slate-800">
                I. Operating Revenue
              </p>
              <div className="flex justify-between py-2">
                <span>Gross Invoiced Sales Revenue:</span>
                <span className="font-bold text-slate-900 dark:text-white">₹{totalRevenue.toLocaleString('en-IN')}</span>
              </div>
            </div>

            {/* COGS */}
            <div>
              <p className="font-sans font-bold uppercase text-slate-400 text-[11px] pb-1 border-b border-slate-100 dark:border-slate-800">
                II. Cost of Goods Sold (Procurement)
              </p>
              <div className="flex justify-between py-2 text-rose-600">
                <span>Purchase Bills & Procurement Costs:</span>
                <span>(₹{costOfGoodsSold.toLocaleString('en-IN')})</span>
              </div>
            </div>

            {/* Gross Profit */}
            <div className="flex justify-between py-2 border-y border-slate-200 font-bold text-sm bg-slate-50 dark:bg-slate-800/50 px-2 dark:border-slate-700">
              <span className="font-sans">Gross Profit:</span>
              <span className={grossProfit >= 0 ? 'text-emerald-600' : 'text-rose-600'}>
                ₹{grossProfit.toLocaleString('en-IN')}
              </span>
            </div>

            {/* Operating Overheads */}
            <div>
              <p className="font-sans font-bold uppercase text-slate-400 text-[11px] pb-1 border-b border-slate-100 dark:border-slate-800">
                III. Operational Expenses & Overheads
              </p>
              {dbState.expenses.map((exp) => (
                <div key={exp.id} className="flex justify-between py-1 text-slate-600 dark:text-slate-300">
                  <span className="truncate pr-4">{exp.category_name} - {exp.description}:</span>
                  <span>₹{exp.amount.toLocaleString('en-IN')}</span>
                </div>
              ))}
              <div className="flex justify-between py-2 border-t border-slate-100 font-semibold text-rose-600">
                <span>Total Operational Expenses:</span>
                <span>(₹{totalOperatingExpenses.toLocaleString('en-IN')})</span>
              </div>
            </div>

            {/* Net Profit */}
            <div className="flex justify-between py-3 border-t-2 border-slate-900 font-bold text-base bg-indigo-50/50 dark:bg-indigo-950/20 px-3 rounded-xl dark:border-slate-600">
              <span className="font-sans text-indigo-900 dark:text-indigo-300">Net Profit (Loss):</span>
              <span className={netProfit >= 0 ? 'text-emerald-600' : 'text-rose-600'}>
                ₹{netProfit.toLocaleString('en-IN')}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* 5. BALANCE SHEET */}
      {activeTab === 'BALANCE_SHEET' && (
        <div className="mx-auto max-w-4xl rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 space-y-6">
          <div className="border-b border-slate-200 pb-4 text-center dark:border-slate-800">
            <h2 className="text-base font-bold uppercase tracking-wider text-slate-900 dark:text-white">
              Balance Sheet Statement
            </h2>
            <p className="text-xs text-slate-500">
              As of Today • Formula: Assets = Liabilities + Shareholder Equity
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-xs font-mono">
            {/* Left: ASSETS */}
            <div className="space-y-4">
              <div className="border-b-2 border-indigo-600 pb-1 font-sans font-bold uppercase text-indigo-600 text-sm">
                ASSETS
              </div>

              <div className="space-y-2">
                <p className="font-sans font-bold text-slate-400 text-[11px]">Current Assets:</p>
                <div className="flex justify-between py-1">
                  <span>Bank Accounts (HDFC):</span>
                  <span>₹{bankBalance.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span>Petty Cash:</span>
                  <span>₹{cashBalance.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span>Accounts Receivable (Debtors):</span>
                  <span>₹{accountsReceivable.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span>Inventory / Finished Stock:</span>
                  <span>₹{inventoryAssetValuation.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span>GST Input Tax Credit (ITC):</span>
                  <span>₹{itcAsset.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <p className="font-sans font-bold text-slate-400 text-[11px]">Non-Current / Fixed Assets:</p>
                <div className="flex justify-between py-1">
                  <span>Plant, IT Equipment & Assets:</span>
                  <span>₹{fixedAssetsTotal.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <div className="flex justify-between py-3 border-t-2 border-slate-900 font-bold text-sm bg-slate-50 p-2 rounded-lg dark:border-slate-700 dark:bg-slate-800">
                <span className="font-sans">TOTAL ASSETS:</span>
                <span className="text-indigo-600">₹{totalAssets.toLocaleString('en-IN')}</span>
              </div>
            </div>

            {/* Right: LIABILITIES & EQUITY */}
            <div className="space-y-4">
              <div className="border-b-2 border-rose-600 pb-1 font-sans font-bold uppercase text-rose-600 text-sm">
                LIABILITIES & EQUITY
              </div>

              <div className="space-y-2">
                <p className="font-sans font-bold text-slate-400 text-[11px]">Current Liabilities:</p>
                <div className="flex justify-between py-1">
                  <span>Accounts Payable (Creditors):</span>
                  <span>₹{accountsPayable.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span>GST Output Tax Payable:</span>
                  <span>₹{gstOutputLiability.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between py-1 font-semibold border-t border-slate-100 dark:border-slate-800 pt-1">
                  <span>Total Liabilities:</span>
                  <span>₹{totalLiabilities.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <p className="font-sans font-bold text-slate-400 text-[11px]">Shareholders Equity:</p>
                <div className="flex justify-between py-1">
                  <span>Owner Capital:</span>
                  <span>₹{initialCapital.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span>Retained Earnings (Net Profit):</span>
                  <span className={netProfit >= 0 ? 'text-emerald-600' : 'text-rose-600'}>
                    ₹{netProfit.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="flex justify-between py-1 font-semibold border-t border-slate-100 dark:border-slate-800 pt-1">
                  <span>Total Equity:</span>
                  <span>₹{totalEquity.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <div className="flex justify-between py-3 border-t-2 border-slate-900 font-bold text-sm bg-slate-50 p-2 rounded-lg dark:border-slate-700 dark:bg-slate-800">
                <span className="font-sans">TOTAL LIAB. & EQUITY:</span>
                <span className="text-indigo-600">₹{(totalLiabilities + totalEquity).toLocaleString('en-IN')}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
