import React, { useState } from 'react';
import { 
  Package, 
  Plus, 
  Search, 
  Download, 
  Camera, 
  AlertTriangle, 
  SlidersHorizontal,
  ArrowUpRight,
  ArrowDownRight,
  X,
  History
} from 'lucide-react';
import { db } from '../../lib/db';
import { Product } from '../../types/erp';
import { exportToCSV } from '../../lib/exportUtils';
import { scanBarcodeOrQr, triggerHaptic } from '../../lib/capacitor';

export const ProductList: React.FC = () => {
  const dbState = db.getState();
  const company = db.getCurrentCompany();

  const [search, setSearch] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedProductForAdjust, setSelectedProductForAdjust] = useState<Product | null>(null);
  const [showMovementHistory, setShowMovementHistory] = useState(false);

  // New Product Form
  const [sku, setSku] = useState('');
  const [name, setName] = useState('');
  const [brand, setBrand] = useState('');
  const [categoryName, setCategoryName] = useState(dbState.categories[0]?.name || 'Computer Hardware');
  const [unit, setUnit] = useState('Pcs');
  const [hsnSac, setHsnSac] = useState('8471');
  const [barcode, setBarcode] = useState('');
  const [purchasePrice, setPurchasePrice] = useState(1000);
  const [sellingPrice, setSellingPrice] = useState(1500);
  const [taxRate, setTaxRate] = useState(18);
  const [minStock, setMinStock] = useState(5);
  const [openingStock, setOpeningStock] = useState(10);
  const [description, setDescription] = useState('');

  // Stock Adjustment Form
  const [adjustQty, setAdjustQty] = useState(1);
  const [adjustType, setAdjustType] = useState<'IN' | 'OUT'>('IN');
  const [adjustReason, setAdjustReason] = useState('Physical Stock Audit Count');

  const filtered = dbState.products.filter((p) => {
    return (
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.sku.toLowerCase().includes(search.toLowerCase()) ||
      (p.barcode && p.barcode.includes(search)) ||
      (p.category_name && p.category_name.toLowerCase().includes(search.toLowerCase()))
    );
  });

  const handleScanBarcodeForSearch = async () => {
    triggerHaptic('medium');
    const result = await scanBarcodeOrQr();
    if (result.hasContent) {
      setSearch(result.content);
    }
  };

  const handleScanBarcodeForForm = async () => {
    triggerHaptic('medium');
    const result = await scanBarcodeOrQr();
    if (result.hasContent) {
      setBarcode(result.content);
    }
  };

  const handleExport = () => {
    const rows = filtered.map((p) => ({
      SKU: p.sku,
      Name: p.name,
      Category: p.category_name || '',
      Brand: p.brand || '',
      Current_Stock: p.current_stock,
      Unit: p.unit,
      Purchase_Price: p.purchase_price,
      Selling_Price: p.selling_price,
      Tax_Rate_GST: p.tax_rate,
      HSN_SAC: p.hsn_sac,
      Barcode: p.barcode || '',
      Stock_Value: p.current_stock * p.purchase_price,
    }));
    exportToCSV(`Products_Inventory_${company.name.replace(/\s+/g, '_')}`, rows);
  };

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sku.trim() || !name.trim()) {
      alert('SKU and Name are required');
      return;
    }

    db.addProduct({
      sku: sku.trim().toUpperCase(),
      name: name.trim(),
      brand: brand.trim() || undefined,
      category_name: categoryName,
      unit,
      hsn_sac: hsnSac.trim(),
      barcode: barcode.trim() || undefined,
      purchase_price: Number(purchasePrice),
      selling_price: Number(sellingPrice),
      tax_rate: Number(taxRate),
      is_tax_inclusive: false,
      min_stock_alert: Number(minStock),
      max_stock: 500,
      current_stock: Number(openingStock),
      description: description.trim() || undefined,
      status: 'Active',
    });

    setShowAddModal(false);
    // Reset form
    setSku('');
    setName('');
    setBrand('');
    setBarcode('');
    setDescription('');
  };

  const handleApplyStockAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductForAdjust) return;

    const delta = adjustType === 'IN' ? Number(adjustQty) : -Number(adjustQty);
    db.adjustProductStock(selectedProductForAdjust.id, delta, adjustReason);
    setSelectedProductForAdjust(null);
    setAdjustQty(1);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-2xl">
            Inventory & Stock Control
          </h1>
          <p className="text-xs text-slate-500">
            Real-time stock valuation, SKU ledger, barcode identification, and HSN compliance.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowMovementHistory(true)}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300"
          >
            <History className="h-4 w-4" />
            Stock Movements
          </button>
          <button
            onClick={handleExport}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300"
          >
            <Download className="h-4 w-4" />
            Export CSV
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-md hover:bg-indigo-700 active:scale-95 transition"
          >
            <Plus className="h-4 w-4" />
            Add Product
          </button>
        </div>
      </div>

      {/* Search & Barcode Scan Bar */}
      <div className="flex items-center gap-2 max-w-md">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by product, SKU, HSN, barcode..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-xl border border-slate-200 bg-white pl-9 pr-3 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-900 dark:text-white"
          />
        </div>
        <button
          onClick={handleScanBarcodeForSearch}
          title="Scan Barcode with Camera"
          className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300"
        >
          <Camera className="h-4 w-4 text-indigo-600" />
          <span className="hidden sm:inline">Scan</span>
        </button>
      </div>

      {/* Inventory Table */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-100 bg-slate-50/75 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:border-slate-800 dark:bg-slate-800/40">
              <tr>
                <th className="p-3.5">SKU & Item Details</th>
                <th className="p-3.5">Category</th>
                <th className="p-3.5 text-center">HSN/SAC</th>
                <th className="p-3.5 text-right">Cost Price</th>
                <th className="p-3.5 text-right">Selling Price</th>
                <th className="p-3.5 text-center">GST %</th>
                <th className="p-3.5 text-center">Available Stock</th>
                <th className="p-3.5 text-right">Stock Valuation</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filtered.map((prod) => {
                const isLow = prod.current_stock <= prod.min_stock_alert;
                const valuation = prod.current_stock * prod.purchase_price;

                return (
                  <tr key={prod.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                    <td className="p-3.5">
                      <p className="font-bold text-slate-900 dark:text-slate-100">{prod.name}</p>
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono">
                        <span>SKU: {prod.sku}</span>
                        {prod.barcode && <span>• Barcode: {prod.barcode}</span>}
                      </div>
                    </td>
                    <td className="p-3.5 text-slate-600 dark:text-slate-300">
                      <span className="rounded-md bg-slate-100 px-2 py-0.5 text-[10px] font-medium dark:bg-slate-800">
                        {prod.category_name || 'General'}
                      </span>
                    </td>
                    <td className="p-3.5 text-center font-mono font-medium text-slate-600 dark:text-slate-300">
                      {prod.hsn_sac}
                    </td>
                    <td className="p-3.5 text-right font-mono text-slate-600 dark:text-slate-300">
                      ₹{prod.purchase_price.toLocaleString('en-IN')}
                    </td>
                    <td className="p-3.5 text-right font-mono font-bold text-slate-900 dark:text-white">
                      ₹{prod.selling_price.toLocaleString('en-IN')}
                    </td>
                    <td className="p-3.5 text-center font-mono font-medium text-indigo-600">
                      {prod.tax_rate}%
                    </td>
                    <td className="p-3.5 text-center">
                      <div className="inline-flex flex-col items-center">
                        <span className={`font-bold font-mono text-sm ${isLow ? 'text-rose-600' : 'text-slate-900 dark:text-white'}`}>
                          {prod.current_stock} {prod.unit}
                        </span>
                        {isLow && (
                          <span className="flex items-center gap-0.5 text-[9px] font-bold text-rose-500">
                            <AlertTriangle className="h-2.5 w-2.5" /> Low Stock
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="p-3.5 text-right font-mono font-semibold text-slate-800 dark:text-slate-200">
                      ₹{valuation.toLocaleString('en-IN')}
                    </td>
                    <td className="p-3.5 text-right">
                      <button
                        onClick={() => setSelectedProductForAdjust(prod)}
                        className="rounded-lg border border-slate-200 px-2.5 py-1 text-[11px] font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300"
                      >
                        Adjust Stock
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Product Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="w-full max-w-2xl rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Register New Inventory Product
              </h2>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCreateProduct} className="mt-4 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Product SKU *
                  </label>
                  <input
                    type="text"
                    required
                    value={sku}
                    onChange={(e) => setSku(e.target.value)}
                    placeholder="e.g. DELL-OPT-3080"
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono uppercase text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Product Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Dell OptiPlex Core i5 Desktop"
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Category
                  </label>
                  <select
                    value={categoryName}
                    onChange={(e) => setCategoryName(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    {dbState.categories.map((c) => (
                      <option key={c.id} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Unit of Measure
                  </label>
                  <select
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    <option value="Pcs">Pcs (Pieces)</option>
                    <option value="Kg">Kg (Kilograms)</option>
                    <option value="Box">Box (Cartons)</option>
                    <option value="Meter">Meter</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    HSN/SAC Code *
                  </label>
                  <input
                    type="text"
                    required
                    value={hsnSac}
                    onChange={(e) => setHsnSac(e.target.value)}
                    placeholder="8471"
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Barcode / QR (EAN-13)
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={barcode}
                      onChange={(e) => setBarcode(e.target.value)}
                      placeholder="8901030928412"
                      className="mt-1 flex-1 rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    />
                    <button
                      type="button"
                      onClick={handleScanBarcodeForForm}
                      className="mt-1 p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-indigo-600 dark:border-slate-700"
                    >
                      <Camera className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    GST Tax Bracket
                  </label>
                  <select
                    value={taxRate}
                    onChange={(e) => setTaxRate(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    <option value="0">0% (Nil / Exempt)</option>
                    <option value="5">5% GST</option>
                    <option value="12">12% GST</option>
                    <option value="18">18% GST (Standard)</option>
                    <option value="28">28% GST</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Purchase Cost (₹)
                  </label>
                  <input
                    type="number"
                    value={purchasePrice}
                    onChange={(e) => setPurchasePrice(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Selling Price (₹)
                  </label>
                  <input
                    type="number"
                    value={sellingPrice}
                    onChange={(e) => setSellingPrice(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Opening Stock
                  </label>
                  <input
                    type="number"
                    value={openingStock}
                    onChange={(e) => setOpeningStock(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Low Stock Alert
                  </label>
                  <input
                    type="number"
                    value={minStock}
                    onChange={(e) => setMinStock(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-indigo-600 px-5 py-2 text-xs font-bold text-white shadow-md hover:bg-indigo-700 transition"
                >
                  Save Product
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Stock Adjustment Modal */}
      {selectedProductForAdjust && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Adjust Stock: {selectedProductForAdjust.name}
              </h3>
              <button
                onClick={() => setSelectedProductForAdjust(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleApplyStockAdjustment} className="mt-4 space-y-4">
              <div>
                <p className="text-xs text-slate-500">Current Stock: <span className="font-bold text-slate-900 dark:text-white">{selectedProductForAdjust.current_stock} {selectedProductForAdjust.unit}</span></p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Adjustment Type
                </label>
                <div className="mt-1 flex gap-2">
                  <button
                    type="button"
                    onClick={() => setAdjustType('IN')}
                    className={`flex-1 rounded-xl py-2 text-xs font-bold transition ${
                      adjustType === 'IN'
                        ? 'bg-emerald-600 text-white shadow'
                        : 'border border-slate-200 text-slate-600 dark:border-slate-700 dark:text-slate-300'
                    }`}
                  >
                    + Stock In (Add)
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdjustType('OUT')}
                    className={`flex-1 rounded-xl py-2 text-xs font-bold transition ${
                      adjustType === 'OUT'
                        ? 'bg-rose-600 text-white shadow'
                        : 'border border-slate-200 text-slate-600 dark:border-slate-700 dark:text-slate-300'
                    }`}
                  >
                    - Stock Out (Deduct)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Quantity ({selectedProductForAdjust.unit})
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={adjustQty}
                  onChange={(e) => setAdjustQty(Number(e.target.value))}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Audit Reason / Note
                </label>
                <input
                  type="text"
                  required
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  placeholder="e.g. Audit correction, Damaged in transit, Sample"
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setSelectedProductForAdjust(null)}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-indigo-600 px-5 py-2 text-xs font-bold text-white shadow hover:bg-indigo-700"
                >
                  Post Adjustment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Stock Movement History Slide-Over */}
      {showMovementHistory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="w-full max-w-3xl rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900 max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Stock Movements Ledger
              </h3>
              <button
                onClick={() => setShowMovementHistory(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-4 flex-1 overflow-y-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 dark:bg-slate-800 dark:border-slate-700">
                  <tr>
                    <th className="p-2.5">Date & Time</th>
                    <th className="p-2.5">Product</th>
                    <th className="p-2.5">Warehouse</th>
                    <th className="p-2.5 text-center">Type</th>
                    <th className="p-2.5 text-right">Quantity</th>
                    <th className="p-2.5">Ref / Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {dbState.stockMovements.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-xs text-slate-400">
                        No manual or invoice stock movements logged yet.
                      </td>
                    </tr>
                  ) : (
                    dbState.stockMovements.map((mov) => (
                      <tr key={mov.id}>
                        <td className="p-2.5 text-slate-500 font-mono text-[11px]">
                          {new Date(mov.created_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                        </td>
                        <td className="p-2.5 font-semibold text-slate-900 dark:text-white">
                          {mov.product_name}
                        </td>
                        <td className="p-2.5 text-slate-600 dark:text-slate-300">
                          {mov.warehouse_name}
                        </td>
                        <td className="p-2.5 text-center">
                          <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                            mov.movement_type === 'IN'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-400'
                              : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-400'
                          }`}>
                            {mov.movement_type}
                          </span>
                        </td>
                        <td className="p-2.5 text-right font-mono font-bold">
                          {mov.quantity}
                        </td>
                        <td className="p-2.5 text-slate-500 text-[11px]">
                          {mov.reference_type}: {mov.reference_id} {mov.notes ? `(${mov.notes})` : ''}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
