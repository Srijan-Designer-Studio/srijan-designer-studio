import React, { useState } from 'react';
import { 
  ShoppingCart, 
  Plus, 
  Search, 
  Download, 
  Trash2, 
  X,
  CreditCard,
  Truck,
  CheckCircle2
} from 'lucide-react';
import { db } from '../../lib/db';
import { PurchaseBill, PurchaseBillItem } from '../../types/erp';
import { exportToCSV } from '../../lib/exportUtils';

interface PurchaseBillListProps {
  onRecordPaymentForBill?: (bill: PurchaseBill) => void;
}

export const PurchaseBillList: React.FC<PurchaseBillListProps> = ({ onRecordPaymentForBill }) => {
  const dbState = db.getState();
  const company = db.getCurrentCompany();

  const [search, setSearch] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);

  // New Purchase Bill Form
  const [supplierId, setSupplierId] = useState(dbState.suppliers[0]?.id || '');
  const [supplierInvoiceNo, setSupplierInvoiceNo] = useState('');
  const [billDate, setBillDate] = useState(new Date().toISOString().split('T')[0]);
  const [dueDate, setDueDate] = useState(
    new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [warehouseId, setWarehouseId] = useState(dbState.warehouses[0]?.id || '');

  const [items, setItems] = useState<Array<{
    productId: string;
    productName: string;
    hsnSac: string;
    quantity: number;
    rate: number;
    taxPercent: number;
  }>>([
    {
      productId: dbState.products[0]?.id || '',
      productName: dbState.products[0]?.name || '',
      hsnSac: dbState.products[0]?.hsn_sac || '8471',
      quantity: 5,
      rate: dbState.products[0]?.purchase_price || 1000,
      taxPercent: dbState.products[0]?.tax_rate || 18,
    }
  ]);

  const selectedSupplier = dbState.suppliers.find((s) => s.id === supplierId);
  const isInterState = Boolean(
    selectedSupplier &&
    selectedSupplier.state &&
    company.state &&
    selectedSupplier.state.trim().toLowerCase() !== company.state.trim().toLowerCase()
  );

  const filteredBills = dbState.purchaseBills.filter((b) => {
    return (
      b.bill_number.toLowerCase().includes(search.toLowerCase()) ||
      b.supplier_name.toLowerCase().includes(search.toLowerCase()) ||
      (b.supplier_invoice_no && b.supplier_invoice_no.toLowerCase().includes(search.toLowerCase()))
    );
  });

  const handleProductSelect = (index: number, prodId: string) => {
    const prod = dbState.products.find((p) => p.id === prodId);
    if (!prod) return;
    const next = [...items];
    next[index] = {
      ...next[index],
      productId: prod.id,
      productName: prod.name,
      hsnSac: prod.hsn_sac || '8471',
      rate: prod.purchase_price,
      taxPercent: prod.tax_rate,
    };
    setItems(next);
  };

  const handleItemChange = (index: number, field: string, val: any) => {
    const next = [...items];
    (next[index] as any)[field] = val;
    setItems(next);
  };

  const addItem = () => {
    const prod = dbState.products[0];
    setItems([
      ...items,
      {
        productId: prod?.id || '',
        productName: prod?.name || '',
        hsnSac: prod?.hsn_sac || '8471',
        quantity: 1,
        rate: prod?.purchase_price || 1000,
        taxPercent: prod?.tax_rate || 18,
      }
    ]);
  };

  const removeItem = (index: number) => {
    if (items.length <= 1) return;
    setItems(items.filter((_, i) => i !== index));
  };

  let totalTaxable = 0;
  let totalTax = 0;

  const processedItems: PurchaseBillItem[] = items.map((it, idx) => {
    const taxable = it.quantity * it.rate;
    const tax = taxable * (it.taxPercent / 100);
    const lineTotal = taxable + tax;
    totalTaxable += taxable;
    totalTax += tax;

    return {
      id: `bill-item-${idx}-${Date.now()}`,
      product_id: it.productId,
      product_name: it.productName,
      hsn_sac: it.hsnSac,
      quantity: Number(it.quantity),
      rate: Number(it.rate),
      taxable_amount: Number(taxable.toFixed(2)),
      tax_percent: Number(it.taxPercent),
      tax_amount: Number(tax.toFixed(2)),
      total: Number(lineTotal.toFixed(2)),
    };
  });

  const cgst = isInterState ? 0 : totalTax / 2;
  const sgst = isInterState ? 0 : totalTax / 2;
  const igst = isInterState ? totalTax : 0;
  const rawGrandTotal = totalTaxable + totalTax;
  const grandTotal = Math.round(rawGrandTotal);
  const roundOff = Number((grandTotal - rawGrandTotal).toFixed(2));

  const handleCreateBill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSupplier) {
      alert('Please select a supplier');
      return;
    }

    const billNumber = `${company.bill_prefix || 'BILL-'}${Date.now().toString().slice(-4)}`;

    db.createPurchaseBill({
      supplier_id: selectedSupplier.id,
      supplier_name: selectedSupplier.name,
      supplier_gstin: selectedSupplier.gstin,
      supplier_invoice_no: supplierInvoiceNo.trim() || undefined,
      bill_number: billNumber,
      bill_date: billDate,
      due_date: dueDate,
      is_igst: isInterState,
      warehouse_id: warehouseId,
      items: processedItems,
      taxable_amount: Number(totalTaxable.toFixed(2)),
      cgst: Number(cgst.toFixed(2)),
      sgst: Number(sgst.toFixed(2)),
      igst: Number(igst.toFixed(2)),
      round_off: roundOff,
      grand_total: grandTotal,
      paid_amount: 0,
      balance_amount: grandTotal,
      payment_status: 'Unpaid',
    });

    setShowCreateModal(false);
  };

  const handleExport = () => {
    const rows = filteredBills.map((b) => ({
      Bill_Number: b.bill_number,
      Supplier: b.supplier_name,
      Supplier_GSTIN: b.supplier_gstin || '',
      Vendor_Invoice: b.supplier_invoice_no || '',
      Date: b.bill_date,
      Taxable_Amount: b.taxable_amount,
      CGST: b.cgst,
      SGST: b.sgst,
      IGST: b.igst,
      Grand_Total: b.grand_total,
      Balance_Due: b.balance_amount,
      Status: b.payment_status,
    }));
    exportToCSV(`Purchase_Bills_${company.name.replace(/\s+/g, '_')}`, rows);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-2xl">
            Purchase Bills & Procurement
          </h1>
          <p className="text-xs text-slate-500">
            Record incoming vendor bills, claim GST Input Tax Credit (ITC), and automatically increase depot stock.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300"
          >
            <Download className="h-4 w-4" />
            Export CSV
          </button>
          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-md hover:bg-indigo-700 active:scale-95 transition"
          >
            <Plus className="h-4 w-4" />
            Record Purchase Bill
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
        <input
          type="text"
          placeholder="Search by bill #, supplier or vendor invoice..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full rounded-xl border border-slate-200 bg-white pl-9 pr-3 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-900 dark:text-white"
        />
      </div>

      {/* Table */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-100 bg-slate-50/75 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:border-slate-800 dark:bg-slate-800/40">
              <tr>
                <th className="p-3.5">Bill #</th>
                <th className="p-3.5">Supplier / Vendor</th>
                <th className="p-3.5">Date</th>
                <th className="p-3.5 text-right">Taxable</th>
                <th className="p-3.5 text-right">GST (ITC)</th>
                <th className="p-3.5 text-right">Total Bill</th>
                <th className="p-3.5 text-right">Outstanding</th>
                <th className="p-3.5 text-center">Status</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredBills.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-xs text-slate-400">
                    No purchase bills recorded yet. Click "Record Purchase Bill" to add incoming stock.
                  </td>
                </tr>
              ) : (
                filteredBills.map((bill) => {
                  const itcTax = (bill.cgst || 0) + (bill.sgst || 0) + (bill.igst || 0);
                  return (
                    <tr key={bill.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="p-3.5 font-bold font-mono text-indigo-600 dark:text-indigo-400">
                        {bill.bill_number}
                        {bill.supplier_invoice_no && (
                          <span className="block text-[10px] text-slate-400">
                            Inv: {bill.supplier_invoice_no}
                          </span>
                        )}
                      </td>
                      <td className="p-3.5">
                        <p className="font-semibold text-slate-900 dark:text-slate-100">{bill.supplier_name}</p>
                        <p className="text-[10px] text-slate-400 font-mono">{bill.supplier_gstin || 'Unregistered'}</p>
                      </td>
                      <td className="p-3.5 text-slate-500 font-mono">{bill.bill_date}</td>
                      <td className="p-3.5 text-right font-mono text-slate-600 dark:text-slate-300">
                        ₹{bill.taxable_amount.toLocaleString('en-IN')}
                      </td>
                      <td className="p-3.5 text-right font-mono text-emerald-600 font-medium">
                        +₹{itcTax.toLocaleString('en-IN')}
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-slate-900 dark:text-white">
                        ₹{bill.grand_total.toLocaleString('en-IN')}
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-rose-600">
                        ₹{bill.balance_amount.toLocaleString('en-IN')}
                      </td>
                      <td className="p-3.5 text-center">
                        <span className={`inline-flex rounded-full px-2 py-0.5 text-[10px] font-bold ${
                          bill.payment_status === 'Paid'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                        }`}>
                          {bill.payment_status}
                        </span>
                      </td>
                      <td className="p-3.5 text-right">
                        {bill.balance_amount > 0 && onRecordPaymentForBill && (
                          <button
                            onClick={() => onRecordPaymentForBill(bill)}
                            className="rounded-lg bg-emerald-50 px-2.5 py-1 text-[11px] font-semibold text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-950 dark:text-emerald-400"
                          >
                            Pay Vendor
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Purchase Bill Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="w-full max-w-4xl rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h2 className="text-base font-bold text-slate-900 dark:text-white">
                  Record Purchase Bill / Goods Receipt
                </h2>
                <p className="text-xs text-slate-500">
                  Adds received stock to inventory and records liability in Accounts Payable
                </p>
              </div>
              <button onClick={() => setShowCreateModal(false)} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCreateBill} className="mt-4 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Supplier *</label>
                  <select
                    value={supplierId}
                    onChange={(e) => setSupplierId(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    {dbState.suppliers.map((s) => (
                      <option key={s.id} value={s.id}>{s.name} ({s.state})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Supplier Invoice No.</label>
                  <input
                    type="text"
                    value={supplierInvoiceNo}
                    onChange={(e) => setSupplierInvoiceNo(e.target.value)}
                    placeholder="e.g. RED-2026-998"
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Receive Into Warehouse</label>
                  <select
                    value={warehouseId}
                    onChange={(e) => setWarehouseId(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    {dbState.warehouses.map((w) => (
                      <option key={w.id} value={w.id}>{w.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Items */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase text-slate-500">Items Received</span>
                  <button
                    type="button"
                    onClick={addItem}
                    className="flex items-center gap-1 rounded-lg bg-indigo-50 px-2 py-1 text-xs font-semibold text-indigo-600 hover:bg-indigo-100"
                  >
                    <Plus className="h-3 w-3" /> Add Item
                  </button>
                </div>

                <div className="rounded-xl border border-slate-200 overflow-x-auto dark:border-slate-800">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 dark:bg-slate-800">
                      <tr>
                        <th className="p-2">Product</th>
                        <th className="p-2 text-right w-20">Qty</th>
                        <th className="p-2 text-right w-28">Cost Rate (₹)</th>
                        <th className="p-2 text-center w-20">GST %</th>
                        <th className="p-2 text-right w-28">Total (₹)</th>
                        <th className="p-2 w-8"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {items.map((it, idx) => {
                        const taxable = it.quantity * it.rate;
                        const tax = taxable * (it.taxPercent / 100);
                        const total = taxable + tax;
                        return (
                          <tr key={idx}>
                            <td className="p-2">
                              <select
                                value={it.productId}
                                onChange={(e) => handleProductSelect(idx, e.target.value)}
                                className="w-full rounded-lg border border-slate-200 p-1.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                              >
                                {dbState.products.map((p) => (
                                  <option key={p.id} value={p.id}>{p.name}</option>
                                ))}
                              </select>
                            </td>
                            <td className="p-2">
                              <input
                                type="number"
                                min="1"
                                value={it.quantity}
                                onChange={(e) => handleItemChange(idx, 'quantity', Number(e.target.value))}
                                className="w-full rounded-lg border border-slate-200 p-1.5 text-xs text-right font-mono dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                              />
                            </td>
                            <td className="p-2">
                              <input
                                type="number"
                                min="0"
                                value={it.rate}
                                onChange={(e) => handleItemChange(idx, 'rate', Number(e.target.value))}
                                className="w-full rounded-lg border border-slate-200 p-1.5 text-xs text-right font-mono dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                              />
                            </td>
                            <td className="p-2">
                              <select
                                value={it.taxPercent}
                                onChange={(e) => handleItemChange(idx, 'taxPercent', Number(e.target.value))}
                                className="w-full rounded-lg border border-slate-200 p-1.5 text-xs text-center font-mono dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                              >
                                <option value="0">0%</option>
                                <option value="5">5%</option>
                                <option value="12">12%</option>
                                <option value="18">18%</option>
                                <option value="28">28%</option>
                              </select>
                            </td>
                            <td className="p-2 text-right font-mono font-bold">
                              ₹{total.toFixed(2)}
                            </td>
                            <td className="p-2 text-center">
                              <button type="button" onClick={() => removeItem(idx)} className="text-slate-400 hover:text-rose-600">
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Total Summary */}
              <div className="flex justify-end pt-2">
                <div className="w-72 rounded-xl border border-slate-200 bg-slate-50/60 p-3 text-xs space-y-1.5 dark:border-slate-700 dark:bg-slate-800">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Taxable Value:</span>
                    <span className="font-mono">₹{totalTaxable.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Input Tax Credit (ITC):</span>
                    <span className="font-mono text-emerald-600">+₹{totalTax.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between pt-1 border-t border-slate-200 font-bold text-sm text-slate-900 dark:text-white">
                    <span>Grand Total:</span>
                    <span className="font-mono">₹{grandTotal.toLocaleString('en-IN')}.00</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-indigo-600 px-5 py-2 text-xs font-bold text-white shadow hover:bg-indigo-700"
                >
                  Save & Receive Stock
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
