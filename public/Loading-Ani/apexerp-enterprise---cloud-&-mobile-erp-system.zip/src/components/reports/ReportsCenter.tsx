import React, { useState } from 'react';
import { BarChart3, Download, Printer, FileText, CheckCircle2, TrendingUp } from 'lucide-react';
import { db } from '../../lib/db';
import { exportToCSV, printDocument } from '../../lib/exportUtils';

export const ReportsCenter: React.FC = () => {
  const dbState = db.getState();
  const company = db.getCurrentCompany();

  const [reportType, setReportType] = useState<'GST' | 'SALES' | 'PURCHASES' | 'INVENTORY' | 'OUTSTANDING'>('GST');

  // GST Reconciliation Numbers
  const totalSalesTaxable = dbState.invoices.reduce((acc, i) => acc + i.taxable_amount, 0);
  const totalOutputCgst = dbState.invoices.reduce((acc, i) => acc + i.cgst, 0);
  const totalOutputSgst = dbState.invoices.reduce((acc, i) => acc + i.sgst, 0);
  const totalOutputIgst = dbState.invoices.reduce((acc, i) => acc + i.igst, 0);
  const totalOutputTax = totalOutputCgst + totalOutputSgst + totalOutputIgst;

  const totalPurchasesTaxable = dbState.purchaseBills.reduce((acc, b) => acc + b.taxable_amount, 0);
  const totalInputCgst = dbState.purchaseBills.reduce((acc, b) => acc + b.cgst, 0);
  const totalInputSgst = dbState.purchaseBills.reduce((acc, b) => acc + b.sgst, 0);
  const totalInputIgst = dbState.purchaseBills.reduce((acc, b) => acc + b.igst, 0);
  const totalInputTaxCredit = totalInputCgst + totalInputSgst + totalInputIgst;

  const netGstPayable = Math.max(0, totalOutputTax - totalInputTaxCredit);

  const handleExportCurrentReport = () => {
    if (reportType === 'GST') {
      const rows = [
        { Metric: 'Total Outward Supplies (Taxable Sales)', Amount: totalSalesTaxable },
        { Metric: 'Output CGST Liability', Amount: totalOutputCgst },
        { Metric: 'Output SGST Liability', Amount: totalOutputSgst },
        { Metric: 'Output IGST Liability', Amount: totalOutputIgst },
        { Metric: 'Total GST Output Liability', Amount: totalOutputTax },
        { Metric: 'Eligible ITC (CGST Input)', Amount: totalInputCgst },
        { Metric: 'Eligible ITC (SGST Input)', Amount: totalInputSgst },
        { Metric: 'Eligible ITC (IGST Input)', Amount: totalInputIgst },
        { Metric: 'Total Eligible ITC Claimed', Amount: totalInputTaxCredit },
        { Metric: 'Net GST Cash Payable to Govt', Amount: netGstPayable },
      ];
      exportToCSV(`GSTR_Reconciliation_${company.name.replace(/\s+/g, '_')}`, rows);
    } else if (reportType === 'SALES') {
      const rows = dbState.invoices.map(i => ({
        Invoice_No: i.invoice_number,
        Date: i.invoice_date,
        Customer: i.customer_name,
        GSTIN: i.customer_gstin || '',
        Taxable: i.taxable_amount,
        CGST: i.cgst,
        SGST: i.sgst,
        IGST: i.igst,
        Grand_Total: i.grand_total,
        Status: i.payment_status,
      }));
      exportToCSV(`Sales_Report_${company.name.replace(/\s+/g, '_')}`, rows);
    } else if (reportType === 'INVENTORY') {
      const rows = dbState.products.map(p => ({
        SKU: p.sku,
        Name: p.name,
        Category: p.category_name || '',
        Stock_Available: p.current_stock,
        Unit: p.unit,
        Unit_Cost: p.purchase_price,
        Valuation: p.current_stock * p.purchase_price,
      }));
      exportToCSV(`Inventory_Valuation_${company.name.replace(/\s+/g, '_')}`, rows);
    } else if (reportType === 'OUTSTANDING') {
      const rows = dbState.customers.map(c => ({
        Customer_Code: c.customer_code,
        Name: c.name,
        GSTIN: c.gstin || '',
        Credit_Limit: c.credit_limit,
        Outstanding_Receivable: c.current_balance,
      }));
      exportToCSV(`Receivables_Aging_${company.name.replace(/\s+/g, '_')}`, rows);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-2xl">
            Audit & Statutory Reports
          </h1>
          <p className="text-xs text-slate-500">
            GST GSTR-1 / GSTR-3B filings, stock valuation statements, and aging schedules.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={printDocument}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300"
          >
            <Printer className="h-4 w-4" />
            Print Report
          </button>
          <button
            onClick={handleExportCurrentReport}
            className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-md hover:bg-indigo-700 transition"
          >
            <Download className="h-4 w-4" />
            Export Selected Report
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-2 dark:border-slate-800">
        {[
          { id: 'GST', label: 'GST GSTR-1 & 3B Reconciliation' },
          { id: 'SALES', label: 'Sales Register' },
          { id: 'PURCHASES', label: 'Purchase Register' },
          { id: 'INVENTORY', label: 'Inventory Stock Valuation' },
          { id: 'OUTSTANDING', label: 'Customer Receivables' },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setReportType(t.id as any)}
            className={`rounded-xl px-4 py-2 text-xs font-bold transition ${
              reportType === t.id
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-white text-slate-600 hover:bg-slate-100 dark:bg-slate-900 dark:text-slate-300'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* GST REPORT VIEW */}
      {reportType === 'GST' && (
        <div className="mx-auto max-w-4xl rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 space-y-6">
          <div className="border-b border-slate-200 pb-4 text-center dark:border-slate-800">
            <h2 className="text-base font-bold uppercase tracking-wider text-slate-900 dark:text-white">
              GST Return Reconciliation Statement (GSTR-3B Format)
            </h2>
            <p className="text-xs text-slate-500">
              Company GSTIN: <strong className="font-mono text-slate-900 dark:text-white">{company.gstin}</strong> • Period: FY 2026-27 Q3
            </p>
          </div>

          <div className="space-y-4 text-xs font-mono">
            {/* Outward Taxable */}
            <div className="rounded-xl border border-slate-200 p-4 dark:border-slate-800 space-y-2">
              <p className="font-sans font-bold text-slate-700 dark:text-slate-300 text-xs">
                3.1 Details of Outward Supplies (Sales) & Liability:
              </p>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500 font-sans">Total Taxable Value (Sales):</span>
                <span className="font-bold">₹{totalSalesTaxable.toLocaleString('en-IN')}.00</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-sans">Central Tax (CGST):</span>
                <span>₹{totalOutputCgst.toLocaleString('en-IN')}.00</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-sans">State Tax (SGST):</span>
                <span>₹{totalOutputSgst.toLocaleString('en-IN')}.00</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-sans">Integrated Tax (IGST):</span>
                <span>₹{totalOutputIgst.toLocaleString('en-IN')}.00</span>
              </div>
              <div className="flex justify-between py-2 border-t border-slate-200 font-bold text-sm text-indigo-600 dark:border-slate-700">
                <span className="font-sans">Total Output Tax Liability:</span>
                <span>₹{totalOutputTax.toLocaleString('en-IN')}.00</span>
              </div>
            </div>

            {/* Inward Taxable (ITC) */}
            <div className="rounded-xl border border-slate-200 p-4 dark:border-slate-800 space-y-2">
              <p className="font-sans font-bold text-slate-700 dark:text-slate-300 text-xs">
                4. Eligible Input Tax Credit (ITC Claimable on Purchases):
              </p>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500 font-sans">Total Taxable Purchases:</span>
                <span className="font-bold">₹{totalPurchasesTaxable.toLocaleString('en-IN')}.00</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-sans">CGST Input Credit:</span>
                <span>₹{totalInputCgst.toLocaleString('en-IN')}.00</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-sans">SGST Input Credit:</span>
                <span>₹{totalInputSgst.toLocaleString('en-IN')}.00</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-sans">IGST Input Credit:</span>
                <span>₹{totalInputIgst.toLocaleString('en-IN')}.00</span>
              </div>
              <div className="flex justify-between py-2 border-t border-slate-200 font-bold text-sm text-emerald-600 dark:border-slate-700">
                <span className="font-sans">Total Input Tax Credit (ITC):</span>
                <span>₹{totalInputTaxCredit.toLocaleString('en-IN')}.00</span>
              </div>
            </div>

            {/* Net Tax Payable in Cash */}
            <div className="flex justify-between items-center bg-slate-900 text-white p-4 rounded-xl font-bold text-base">
              <span className="font-sans">NET GST CASH PAYABLE (Output - Input):</span>
              <span className="text-emerald-400 font-mono">₹{netGstPayable.toLocaleString('en-IN')}.00</span>
            </div>
          </div>
        </div>
      )}

      {/* SALES REGISTER VIEW */}
      {reportType === 'SALES' && (
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:bg-slate-800">
              <tr>
                <th className="p-3">Invoice #</th>
                <th className="p-3">Customer</th>
                <th className="p-3">GSTIN</th>
                <th className="p-3 text-right">Taxable</th>
                <th className="p-3 text-right">Total GST</th>
                <th className="p-3 text-right">Invoice Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {dbState.invoices.map((inv) => (
                <tr key={inv.id}>
                  <td className="p-3 font-mono font-bold text-indigo-600">{inv.invoice_number}</td>
                  <td className="p-3 font-semibold text-slate-900 dark:text-white">{inv.customer_name}</td>
                  <td className="p-3 font-mono text-slate-500">{inv.customer_gstin || 'B2C'}</td>
                  <td className="p-3 text-right font-mono">₹{inv.taxable_amount.toLocaleString('en-IN')}</td>
                  <td className="p-3 text-right font-mono">₹{((inv.cgst || 0) + (inv.sgst || 0) + (inv.igst || 0)).toLocaleString('en-IN')}</td>
                  <td className="p-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                    ₹{inv.grand_total.toLocaleString('en-IN')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* INVENTORY VALUATION VIEW */}
      {reportType === 'INVENTORY' && (
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:bg-slate-800">
              <tr>
                <th className="p-3">SKU</th>
                <th className="p-3">Item Description</th>
                <th className="p-3 text-center">Available Stock</th>
                <th className="p-3 text-right">Unit Purchase Cost</th>
                <th className="p-3 text-right">Asset Valuation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {dbState.products.map((p) => (
                <tr key={p.id}>
                  <td className="p-3 font-mono font-bold text-indigo-600">{p.sku}</td>
                  <td className="p-3 font-semibold text-slate-900 dark:text-white">{p.name}</td>
                  <td className="p-3 text-center font-mono font-bold">{p.current_stock} {p.unit}</td>
                  <td className="p-3 text-right font-mono">₹{p.purchase_price.toLocaleString('en-IN')}</td>
                  <td className="p-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                    ₹{(p.current_stock * p.purchase_price).toLocaleString('en-IN')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* RECEIVABLES AGING VIEW */}
      {reportType === 'OUTSTANDING' && (
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:bg-slate-800">
              <tr>
                <th className="p-3">Customer Code</th>
                <th className="p-3">Customer / Enterprise</th>
                <th className="p-3">GSTIN</th>
                <th className="p-3 text-right">Credit Limit</th>
                <th className="p-3 text-right">Outstanding Due</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {dbState.customers.map((c) => (
                <tr key={c.id}>
                  <td className="p-3 font-mono font-bold text-indigo-600">{c.customer_code}</td>
                  <td className="p-3 font-semibold text-slate-900 dark:text-white">{c.name}</td>
                  <td className="p-3 font-mono text-slate-500">{c.gstin || 'None'}</td>
                  <td className="p-3 text-right font-mono">₹{c.credit_limit.toLocaleString('en-IN')}</td>
                  <td className="p-3 text-right font-mono font-bold text-amber-600">
                    ₹{c.current_balance.toLocaleString('en-IN')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
