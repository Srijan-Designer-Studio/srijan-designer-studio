import React, { useState } from 'react';
import { X, Plus, Trash2, Calculator, Check, AlertCircle } from 'lucide-react';
import { db } from '../../lib/db';
import { Invoice, InvoiceItem } from '../../types/erp';
import { calculateGstBreakdown } from '../../lib/gst';

interface InvoiceCreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (newInvoice: Invoice) => void;
}

export const InvoiceCreateModal: React.FC<InvoiceCreateModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const dbState = db.getState();
  const company = db.getCurrentCompany();

  const [customerId, setCustomerId] = useState(dbState.customers[0]?.id || '');
  const [warehouseId, setWarehouseId] = useState(dbState.warehouses[0]?.id || '');
  const [invoiceDate, setInvoiceDate] = useState(new Date().toISOString().split('T')[0]);
  const [dueDate, setDueDate] = useState(
    new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [notes, setNotes] = useState('Payment due within 30 days. Thank you for your business.');

  const [items, setItems] = useState<Array<{
    productId: string;
    productName: string;
    hsnSac: string;
    quantity: number;
    unit: string;
    rate: number;
    discountPercent: number;
    taxPercent: number;
  }>>([
    {
      productId: dbState.products[0]?.id || '',
      productName: dbState.products[0]?.name || '',
      hsnSac: dbState.products[0]?.hsn_sac || '8471',
      quantity: 1,
      unit: dbState.products[0]?.unit || 'Pcs',
      rate: dbState.products[0]?.selling_price || 1000,
      discountPercent: 0,
      taxPercent: dbState.products[0]?.tax_rate || 18,
    }
  ]);

  if (!isOpen) return null;

  const selectedCustomer = dbState.customers.find((c) => c.id === customerId);
  const isInterState = Boolean(
    selectedCustomer && 
    selectedCustomer.billing_state && 
    company.state && 
    selectedCustomer.billing_state.trim().toLowerCase() !== company.state.trim().toLowerCase()
  );

  const handleProductSelect = (index: number, prodId: string) => {
    const prod = dbState.products.find((p) => p.id === prodId);
    if (!prod) return;
    const next = [...items];
    next[index] = {
      ...next[index],
      productId: prod.id,
      productName: prod.name,
      hsnSac: prod.hsn_sac || '8471',
      rate: prod.selling_price,
      unit: prod.unit,
      taxPercent: prod.tax_rate,
    };
    setItems(next);
  };

  const handleItemChange = (index: number, field: string, value: any) => {
    const next = [...items];
    (next[index] as any)[field] = value;
    setItems(next);
  };

  const addItem = () => {
    const prod = dbState.products[0];
    setItems([
      ...items,
      {
        productId: prod?.id || '',
        productName: prod?.name || '',
        hsnSac: prod?.hsn_sac || '8471',
        quantity: 1,
        unit: prod?.unit || 'Pcs',
        rate: prod?.selling_price || 1000,
        discountPercent: 0,
        taxPercent: prod?.tax_rate || 18,
      }
    ]);
  };

  const removeItem = (index: number) => {
    if (items.length <= 1) return;
    setItems(items.filter((_, i) => i !== index));
  };

  // Calculations across all items
  let totalSubtotal = 0;
  let totalTaxable = 0;
  let totalTax = 0;

  const processedItems: InvoiceItem[] = items.map((it, idx) => {
    const gross = it.quantity * it.rate;
    const discount = gross * (it.discountPercent / 100);
    const taxable = gross - discount;
    const tax = taxable * (it.taxPercent / 100);
    const lineTotal = taxable + tax;

    totalSubtotal += gross;
    totalTaxable += taxable;
    totalTax += tax;

    return {
      id: `item-${idx}-${Date.now()}`,
      product_id: it.productId,
      product_name: it.productName,
      hsn_sac: it.hsnSac,
      quantity: Number(it.quantity),
      unit: it.unit,
      rate: Number(it.rate),
      discount_percent: Number(it.discountPercent),
      taxable_amount: Number(taxable.toFixed(2)),
      tax_percent: Number(it.taxPercent),
      tax_amount: Number(tax.toFixed(2)),
      total: Number(lineTotal.toFixed(2)),
    };
  });

  const cgst = isInterState ? 0 : totalTax / 2;
  const sgst = isInterState ? 0 : totalTax / 2;
  const igst = isInterState ? totalTax : 0;

  const rawGrandTotal = totalTaxable + totalTax;
  const grandTotal = Math.round(rawGrandTotal);
  const roundOff = Number((grandTotal - rawGrandTotal).toFixed(2));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer) {
      alert('Please select a customer');
      return;
    }

    const invNumber = `${company.invoice_prefix || 'INV-'}${Date.now().toString().slice(-4)}`;

    const newInvoice = db.createInvoice({
      customer_id: selectedCustomer.id,
      customer_name: selectedCustomer.name,
      customer_gstin: selectedCustomer.gstin,
      customer_phone: selectedCustomer.phone,
      customer_address: `${selectedCustomer.billing_address}, ${selectedCustomer.billing_city}, ${selectedCustomer.billing_state}`,
      customer_state: selectedCustomer.billing_state,
      warehouse_id: warehouseId,
      invoice_number: invNumber,
      invoice_date: invoiceDate,
      due_date: dueDate,
      is_igst: isInterState,
      items: processedItems,
      subtotal: Number(totalSubtotal.toFixed(2)),
      discount_amount: Number((totalSubtotal - totalTaxable).toFixed(2)),
      taxable_amount: Number(totalTaxable.toFixed(2)),
      cgst: Number(cgst.toFixed(2)),
      sgst: Number(sgst.toFixed(2)),
      igst: Number(igst.toFixed(2)),
      round_off: roundOff,
      grand_total: grandTotal,
      paid_amount: 0,
      balance_amount: grandTotal,
      payment_status: 'Unpaid',
      notes,
    });

    onSuccess(newInvoice);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-4xl rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900 my-8">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Generate New GST Tax Invoice
            </h2>
            <p className="text-xs text-slate-500">
              Dispatches inventory and writes to double-entry general ledger
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-6">
          {/* Top Row: Customer & Date selection */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Customer (Billed To) *
              </label>
              <select
                value={customerId}
                onChange={(e) => setCustomerId(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-xs text-slate-900 focus:border-indigo-500 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                required
              >
                {dbState.customers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} {c.gstin ? `(${c.gstin})` : ''} - {c.billing_state}
                  </option>
                ))}
              </select>
              {selectedCustomer && (
                <p className="mt-1 text-[11px] text-slate-500">
                  State: <span className="font-semibold text-slate-700 dark:text-slate-300">{selectedCustomer.billing_state}</span> • 
                  Tax Treatment: <span className="font-semibold text-indigo-600">{isInterState ? 'IGST (Inter-State)' : 'CGST + SGST (Intra-State)'}</span>
                </p>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Invoice Date *
              </label>
              <input
                type="date"
                value={invoiceDate}
                onChange={(e) => setInvoiceDate(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Payment Due Date *
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                required
              />
            </div>
          </div>

          {/* Dispatch Warehouse */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Dispatch From Warehouse *
              </label>
              <select
                value={warehouseId}
                onChange={(e) => setWarehouseId(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              >
                {dbState.warehouses.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.name} ({w.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Line Items Table */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300">
                Line Items
              </label>
              <button
                type="button"
                onClick={addItem}
                className="flex items-center gap-1 rounded-lg bg-indigo-50 px-2.5 py-1 text-xs font-semibold text-indigo-600 hover:bg-indigo-100 dark:bg-indigo-950 dark:text-indigo-400"
              >
                <Plus className="h-3.5 w-3.5" />
                Add Item
              </button>
            </div>

            <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 dark:bg-slate-800/60 dark:border-slate-800">
                  <tr>
                    <th className="p-2.5 w-48">Product / Item</th>
                    <th className="p-2.5 w-20">HSN</th>
                    <th className="p-2.5 w-16 text-right">Qty</th>
                    <th className="p-2.5 w-24 text-right">Rate (₹)</th>
                    <th className="p-2.5 w-16 text-right">Disc %</th>
                    <th className="p-2.5 w-20 text-center">GST %</th>
                    <th className="p-2.5 w-28 text-right">Total (₹)</th>
                    <th className="p-2.5 w-8"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {items.map((it, idx) => {
                    const gross = it.quantity * it.rate;
                    const disc = gross * (it.discountPercent / 100);
                    const taxable = gross - disc;
                    const tax = taxable * (it.taxPercent / 100);
                    const total = taxable + tax;

                    return (
                      <tr key={idx} className="bg-white dark:bg-slate-900">
                        <td className="p-2">
                          <select
                            value={it.productId}
                            onChange={(e) => handleProductSelect(idx, e.target.value)}
                            className="w-full rounded-lg border border-slate-200 bg-slate-50 p-1.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                          >
                            {dbState.products.map((p) => (
                              <option key={p.id} value={p.id}>
                                {p.name} (Stock: {p.current_stock})
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={it.hsnSac}
                            onChange={(e) => handleItemChange(idx, 'hsnSac', e.target.value)}
                            className="w-full rounded-lg border border-slate-200 p-1.5 text-xs text-center font-mono dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            min="1"
                            value={it.quantity}
                            onChange={(e) => handleItemChange(idx, 'quantity', Number(e.target.value))}
                            className="w-full rounded-lg border border-slate-200 p-1.5 text-xs text-right font-mono dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            value={it.rate}
                            onChange={(e) => handleItemChange(idx, 'rate', Number(e.target.value))}
                            className="w-full rounded-lg border border-slate-200 p-1.5 text-xs text-right font-mono dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            min="0"
                            max="100"
                            value={it.discountPercent}
                            onChange={(e) => handleItemChange(idx, 'discountPercent', Number(e.target.value))}
                            className="w-full rounded-lg border border-slate-200 p-1.5 text-xs text-right font-mono dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                          />
                        </td>
                        <td className="p-2">
                          <select
                            value={it.taxPercent}
                            onChange={(e) => handleItemChange(idx, 'taxPercent', Number(e.target.value))}
                            className="w-full rounded-lg border border-slate-200 p-1.5 text-xs text-center font-mono dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                          >
                            <option value="0">0%</option>
                            <option value="5">5%</option>
                            <option value="12">12%</option>
                            <option value="18">18%</option>
                            <option value="28">28%</option>
                          </select>
                        </td>
                        <td className="p-2 text-right font-mono font-bold text-slate-900 dark:text-white">
                          ₹{total.toFixed(2)}
                        </td>
                        <td className="p-2 text-center">
                          <button
                            type="button"
                            onClick={() => removeItem(idx)}
                            className="text-slate-400 hover:text-rose-600 transition"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Bottom Summary & Tax Breakdown */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Invoice Notes & Terms
              </label>
              <textarea
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>

            <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-4 text-xs space-y-2 dark:border-slate-800 dark:bg-slate-800/40">
              <div className="flex justify-between">
                <span className="text-slate-500">Taxable Value:</span>
                <span className="font-mono font-semibold">₹{totalTaxable.toFixed(2)}</span>
              </div>
              {!isInterState ? (
                <>
                  <div className="flex justify-between">
                    <span className="text-slate-500">CGST ({items[0]?.taxPercent / 2 || 9}%):</span>
                    <span className="font-mono">₹{cgst.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">SGST ({items[0]?.taxPercent / 2 || 9}%):</span>
                    <span className="font-mono">₹{sgst.toFixed(2)}</span>
                  </div>
                </>
              ) : (
                <div className="flex justify-between">
                  <span className="text-slate-500">IGST ({items[0]?.taxPercent || 18}%):</span>
                  <span className="font-mono">₹{igst.toFixed(2)}</span>
                </div>
              )}
              {roundOff !== 0 && (
                <div className="flex justify-between text-slate-500">
                  <span>Round Off:</span>
                  <span className="font-mono">₹{roundOff.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between pt-2 border-t border-slate-200 dark:border-slate-700 text-sm font-bold text-slate-900 dark:text-white">
                <span>Grand Total:</span>
                <span className="font-mono text-indigo-600 dark:text-indigo-400">
                  ₹{grandTotal.toLocaleString('en-IN')}.00
                </span>
              </div>
            </div>
          </div>

          {/* Modal Footer Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-xl bg-indigo-600 px-5 py-2 text-xs font-bold text-white shadow-md hover:bg-indigo-700 active:scale-95 transition"
            >
              Issue & Post Invoice
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
