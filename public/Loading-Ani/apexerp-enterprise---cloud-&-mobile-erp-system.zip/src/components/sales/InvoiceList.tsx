import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  Printer, 
  CreditCard, 
  Download, 
  Filter, 
  FileText,
  CheckCircle,
  Clock,
  AlertCircle
} from 'lucide-react';
import { db } from '../../lib/db';
import { Invoice } from '../../types/erp';
import { exportToCSV } from '../../lib/exportUtils';
import { InvoicePrintView } from './InvoicePrintView';

interface InvoiceListProps {
  onOpenCreate: () => void;
  onRecordPaymentForInvoice?: (invoice: Invoice) => void;
}

export const InvoiceList: React.FC<InvoiceListProps> = ({
  onOpenCreate,
  onRecordPaymentForInvoice,
}) => {
  const dbState = db.getState();
  const company = db.getCurrentCompany();
  const currency = company.currency_symbol || '₹';

  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [activePrintInvoice, setActivePrintInvoice] = useState<Invoice | null>(null);

  if (activePrintInvoice) {
    return (
      <InvoicePrintView
        invoice={activePrintInvoice}
        onBack={() => setActivePrintInvoice(null)}
      />
    );
  }

  const filteredInvoices = dbState.invoices.filter((inv) => {
    const matchesSearch =
      inv.invoice_number.toLowerCase().includes(search.toLowerCase()) ||
      inv.customer_name.toLowerCase().includes(search.toLowerCase());
    const matchesStatus =
      filterStatus === 'ALL' || inv.payment_status.toUpperCase() === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const handleExport = () => {
    const rows = filteredInvoices.map((i) => ({
      Invoice_Number: i.invoice_number,
      Date: i.invoice_date,
      Due_Date: i.due_date,
      Customer: i.customer_name,
      Customer_GSTIN: i.customer_gstin || 'N/A',
      Taxable_Amount: i.taxable_amount,
      CGST: i.cgst,
      SGST: i.sgst,
      IGST: i.igst,
      Grand_Total: i.grand_total,
      Paid_Amount: i.paid_amount,
      Balance_Amount: i.balance_amount,
      Payment_Status: i.payment_status,
    }));
    exportToCSV(`Invoices_${company.name.replace(/\s+/g, '_')}`, rows);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-2xl">
            GST Sales Invoices
          </h1>
          <p className="text-xs text-slate-500">
            Issue, dispatch, collect payments, and print compliant Indian GST tax invoices.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800"
          >
            <Download className="h-4 w-4" />
            Export CSV
          </button>
          <button
            onClick={onOpenCreate}
            className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-md hover:bg-indigo-700 active:scale-95 transition"
          >
            <Plus className="h-4 w-4" />
            Create Invoice
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between rounded-xl border border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by invoice # or customer..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 py-1.5 text-xs text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-white"
          />
        </div>

        <div className="flex items-center gap-2">
          {['ALL', 'UNPAID', 'PARTIALLY PAID', 'PAID'].map((st) => (
            <button
              key={st}
              onClick={() => setFilterStatus(st)}
              className={`rounded-lg px-2.5 py-1 text-xs font-semibold transition ${
                filterStatus === st
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-100 bg-slate-50/75 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:border-slate-800 dark:bg-slate-800/40">
              <tr>
                <th className="p-3.5">Invoice #</th>
                <th className="p-3.5">Date</th>
                <th className="p-3.5">Customer</th>
                <th className="p-3.5 text-right">Taxable</th>
                <th className="p-3.5 text-right">GST</th>
                <th className="p-3.5 text-right">Total</th>
                <th className="p-3.5 text-right">Balance Due</th>
                <th className="p-3.5 text-center">Status</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-xs text-slate-400">
                    No invoices match your search or filter.
                  </td>
                </tr>
              ) : (
                filteredInvoices.map((inv) => {
                  const totalTax = (inv.cgst || 0) + (inv.sgst || 0) + (inv.igst || 0);
                  return (
                    <tr
                      key={inv.id}
                      className="hover:bg-slate-50/50 transition dark:hover:bg-slate-800/40"
                    >
                      <td className="p-3.5 font-bold font-mono text-indigo-600 dark:text-indigo-400">
                        {inv.invoice_number}
                      </td>
                      <td className="p-3.5 text-slate-500 font-mono">{inv.invoice_date}</td>
                      <td className="p-3.5">
                        <p className="font-semibold text-slate-900 dark:text-slate-100">
                          {inv.customer_name}
                        </p>
                        <p className="text-[10px] text-slate-400 font-mono">
                          {inv.customer_gstin || 'Retail B2C'}
                        </p>
                      </td>
                      <td className="p-3.5 text-right font-mono text-slate-600 dark:text-slate-300">
                        ₹{inv.taxable_amount.toLocaleString('en-IN')}
                      </td>
                      <td className="p-3.5 text-right font-mono text-slate-500">
                        ₹{totalTax.toLocaleString('en-IN')}
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-slate-900 dark:text-white">
                        ₹{inv.grand_total.toLocaleString('en-IN')}
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold">
                        <span className={inv.balance_amount > 0 ? 'text-amber-600' : 'text-emerald-600'}>
                          ₹{inv.balance_amount.toLocaleString('en-IN')}
                        </span>
                      </td>
                      <td className="p-3.5 text-center">
                        <span
                          className={`inline-flex rounded-full px-2 py-0.5 text-[10px] font-bold ${
                            inv.payment_status === 'Paid'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : inv.payment_status === 'Partially Paid'
                              ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300'
                              : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                          }`}
                        >
                          {inv.payment_status}
                        </span>
                      </td>
                      <td className="p-3.5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setActivePrintInvoice(inv)}
                            title="Print / PDF Invoice"
                            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-indigo-600 transition dark:text-slate-400 dark:hover:bg-slate-800"
                          >
                            <Printer className="h-4 w-4" />
                          </button>
                          {inv.balance_amount > 0 && onRecordPaymentForInvoice && (
                            <button
                              onClick={() => onRecordPaymentForInvoice(inv)}
                              title="Record Payment"
                              className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50 transition dark:text-emerald-400 dark:hover:bg-emerald-950"
                            >
                              <CreditCard className="h-4 w-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
