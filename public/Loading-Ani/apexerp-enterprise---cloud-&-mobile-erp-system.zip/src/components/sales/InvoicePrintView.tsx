import React from 'react';
import { Invoice } from '../../types/erp';
import { db } from '../../lib/db';
import { amountInWords } from '../../lib/gst';
import { Printer, Download, ArrowLeft } from 'lucide-react';
import { printDocument } from '../../lib/exportUtils';

interface InvoicePrintViewProps {
  invoice: Invoice;
  onBack: () => void;
}

export const InvoicePrintView: React.FC<InvoicePrintViewProps> = ({ invoice, onBack }) => {
  const company = db.getCurrentCompany();

  return (
    <div className="space-y-4">
      {/* Action Header (Hidden during Print) */}
      <div className="flex items-center justify-between no-print rounded-xl bg-white p-4 shadow-sm border border-slate-200 dark:bg-slate-900 dark:border-slate-800">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Invoices
        </button>
        <div className="flex items-center gap-2">
          <button
            onClick={printDocument}
            className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow hover:bg-indigo-700 transition"
          >
            <Printer className="h-4 w-4" />
            Print / Save as PDF (A4)
          </button>
        </div>
      </div>

      {/* Standard Tax Invoice Document */}
      <div 
        id="printable-invoice" 
        className="mx-auto max-w-[850px] rounded-lg border border-slate-300 bg-white p-8 text-slate-800 shadow-md print:border-none print:shadow-none print:p-0"
      >
        {/* Top Header: Company Info & TAX INVOICE title */}
        <div className="flex items-start justify-between border-b-2 border-slate-900 pb-4">
          <div>
            <h1 className="text-xl font-black uppercase tracking-wider text-slate-900">
              {company.legal_name || company.name}
            </h1>
            <p className="mt-1 text-xs text-slate-600 max-w-sm">
              {company.address_line1}, {company.address_line2 ? `${company.address_line2}, ` : ''}
              {company.city}, {company.state} - {company.pincode}
            </p>
            <p className="text-xs text-slate-600">
              Phone: {company.phone} • Email: {company.email}
            </p>
            <div className="mt-2 inline-block rounded border border-slate-400 bg-slate-50 px-2 py-0.5 text-xs font-mono font-bold text-slate-900">
              GSTIN: {company.gstin || 'UNREGISTERED'}
            </div>
          </div>
          <div className="text-right">
            <span className="rounded bg-slate-900 px-3 py-1 text-xs font-extrabold text-white tracking-widest uppercase">
              TAX INVOICE
            </span>
            <p className="mt-2 text-xs font-semibold text-slate-500">ORIGINAL FOR RECIPIENT</p>
            <p className="mt-2 font-mono text-sm font-bold text-slate-900">
              Invoice #: {invoice.invoice_number}
            </p>
            <p className="text-xs text-slate-600">Date: {invoice.invoice_date}</p>
            <p className="text-xs text-slate-600">Due Date: {invoice.due_date}</p>
          </div>
        </div>

        {/* Bill To & Dispatch Details */}
        <div className="grid grid-cols-2 gap-4 border-b border-slate-200 py-4 text-xs">
          <div>
            <p className="font-bold uppercase tracking-wider text-slate-500 text-[10px]">
              BILLED TO:
            </p>
            <p className="mt-1 font-bold text-slate-900 text-sm">{invoice.customer_name}</p>
            <p className="text-slate-600 mt-0.5">{invoice.customer_address}</p>
            <p className="text-slate-600">State: {invoice.customer_state || 'West Bengal'}</p>
            <p className="mt-1 font-mono font-bold text-slate-900">
              GSTIN: {invoice.customer_gstin || 'B2C / Unregistered'}
            </p>
          </div>
          <div className="text-right">
            <p className="font-bold uppercase tracking-wider text-slate-500 text-[10px]">
              PLACE OF SUPPLY:
            </p>
            <p className="font-semibold text-slate-800">{invoice.customer_state || company.state}</p>
            <p className="mt-2 font-bold uppercase tracking-wider text-slate-500 text-[10px]">
              TAX TYPE:
            </p>
            <p className="font-semibold text-slate-800">
              {invoice.is_igst ? 'Inter-State Supply (IGST)' : 'Intra-State Supply (CGST + SGST)'}
            </p>
          </div>
        </div>

        {/* Products / Line Items Table */}
        <div className="py-4">
          <table className="w-full text-left text-xs border border-slate-200">
            <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
              <tr>
                <th className="p-2 border-r border-slate-200 text-center w-8">#</th>
                <th className="p-2 border-r border-slate-200">Item & Description</th>
                <th className="p-2 border-r border-slate-200 text-center w-20">HSN/SAC</th>
                <th className="p-2 border-r border-slate-200 text-right w-16">Qty</th>
                <th className="p-2 border-r border-slate-200 text-right w-24">Rate (₹)</th>
                <th className="p-2 border-r border-slate-200 text-right w-24">Taxable</th>
                <th className="p-2 border-r border-slate-200 text-center w-16">GST %</th>
                <th className="p-2 text-right w-24">Total (₹)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {invoice.items.map((item, idx) => (
                <tr key={idx}>
                  <td className="p-2 border-r border-slate-200 text-center font-mono">{idx + 1}</td>
                  <td className="p-2 border-r border-slate-200 font-medium text-slate-900">
                    {item.product_name}
                  </td>
                  <td className="p-2 border-r border-slate-200 text-center font-mono text-[11px]">
                    {item.hsn_sac || '8471'}
                  </td>
                  <td className="p-2 border-r border-slate-200 text-right font-semibold">
                    {item.quantity} {item.unit || 'Pcs'}
                  </td>
                  <td className="p-2 border-r border-slate-200 text-right font-mono">
                    {item.rate.toFixed(2)}
                  </td>
                  <td className="p-2 border-r border-slate-200 text-right font-mono">
                    {item.taxable_amount.toFixed(2)}
                  </td>
                  <td className="p-2 border-r border-slate-200 text-center font-mono">
                    {item.tax_percent}%
                  </td>
                  <td className="p-2 text-right font-mono font-bold text-slate-900">
                    {item.total.toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Calculation Summary & Bank Details */}
        <div className="grid grid-cols-2 gap-6 pt-2 border-t border-slate-200 text-xs">
          {/* Bank & Payment Info */}
          <div className="space-y-3">
            <div>
              <p className="font-bold uppercase tracking-wider text-slate-500 text-[10px]">
                BANK ACCOUNT FOR NEFT / RTGS:
              </p>
              <div className="mt-1 rounded border border-slate-200 bg-slate-50 p-2 font-mono text-[11px] space-y-0.5">
                <p><span className="text-slate-500">Bank:</span> {company.bank_name || 'HDFC Bank Ltd'}</p>
                <p><span className="text-slate-500">A/C No:</span> {company.bank_account_no || '50200012345678'}</p>
                <p><span className="text-slate-500">IFSC:</span> {company.bank_ifsc || 'HDFC0000123'}</p>
                <p><span className="text-slate-500">Branch:</span> {company.bank_branch || 'Sector V Salt Lake'}</p>
                {company.upi_id && <p><span className="text-slate-500">UPI VPA:</span> {company.upi_id}</p>}
              </div>
            </div>

            <div>
              <p className="font-bold uppercase tracking-wider text-slate-500 text-[10px]">
                TERMS & CONDITIONS:
              </p>
              <p className="text-[10px] text-slate-500 mt-0.5 leading-relaxed">
                {invoice.terms_conditions || '1. Goods once sold will not be returned. 2. Interest @ 18% p.a. charged for payments delayed past due date. 3. Subject to local jurisdiction.'}
              </p>
            </div>
          </div>

          {/* Tax Calculation Totals */}
          <div className="space-y-1.5 text-right font-mono">
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">Taxable Subtotal:</span>
              <span className="font-semibold">₹ {invoice.taxable_amount.toFixed(2)}</span>
            </div>

            {!invoice.is_igst ? (
              <>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">CGST Amount:</span>
                  <span>₹ {invoice.cgst.toFixed(2)}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">SGST Amount:</span>
                  <span>₹ {invoice.sgst.toFixed(2)}</span>
                </div>
              </>
            ) : (
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">IGST Amount:</span>
                <span>₹ {invoice.igst.toFixed(2)}</span>
              </div>
            )}

            {invoice.round_off !== 0 && (
              <div className="flex justify-between py-1 border-b border-slate-100 text-slate-500">
                <span>Round Off:</span>
                <span>₹ {invoice.round_off.toFixed(2)}</span>
              </div>
            )}

            <div className="flex justify-between py-2 border-t-2 border-slate-900 text-sm font-extrabold text-slate-900">
              <span className="font-sans">Grand Total:</span>
              <span>₹ {invoice.grand_total.toLocaleString('en-IN')}.00</span>
            </div>

            <div className="pt-2 text-left">
              <p className="text-[10px] uppercase font-bold text-slate-400 font-sans">Amount in words:</p>
              <p className="text-xs font-semibold text-slate-800 font-sans italic">
                {amountInWords(invoice.grand_total)}
              </p>
            </div>
          </div>
        </div>

        {/* Authorized Signatory Footer */}
        <div className="mt-12 flex items-end justify-between border-t border-slate-200 pt-6 text-xs">
          <div className="text-[10px] text-slate-400 font-mono">
            This is an electronically generated GST tax invoice.
          </div>
          <div className="text-center w-52">
            <div className="h-10 border-b border-slate-400 mb-1" />
            <p className="font-bold text-slate-900">For {company.name}</p>
            <p className="text-[10px] text-slate-500">Authorized Signatory</p>
          </div>
        </div>
      </div>
    </div>
  );
};
