import React, { useState } from 'react';
import { Layers, Plus, Search, Download, CheckCircle, FileText, X } from 'lucide-react';
import { db } from '../../lib/db';
import { Quotation } from '../../types/erp';
import { exportToCSV } from '../../lib/exportUtils';

export const QuotationList: React.FC = () => {
  const dbState = db.getState();
  const company = db.getCurrentCompany();

  const [search, setSearch] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  // New Quotation Form
  const [customerId, setCustomerId] = useState(dbState.customers[0]?.id || '');
  const [validUntil, setValidUntil] = useState(
    new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [selectedProductId, setSelectedProductId] = useState(dbState.products[0]?.id || '');
  const [qty, setQty] = useState(1);

  const selectedCustomer = dbState.customers.find((c) => c.id === customerId);

  const handleCreateQuotation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer) return;

    const prod = dbState.products.find((p) => p.id === selectedProductId);
    if (!prod) return;

    const taxable = qty * prod.selling_price;
    const tax = taxable * (prod.tax_rate / 100);
    const grand = Math.round(taxable + tax);

    const quoteNumber = `${company.quote_prefix || 'QTN-'}${Date.now().toString().slice(-4)}`;

    const newQuote: Quotation = {
      id: `qtn-${Date.now()}`,
      company_id: company.id,
      customer_id: selectedCustomer.id,
      customer_name: selectedCustomer.name,
      quotation_number: quoteNumber,
      quotation_date: new Date().toISOString().split('T')[0],
      valid_until: validUntil,
      items: [
        {
          id: `qi-${Date.now()}`,
          product_id: prod.id,
          product_name: prod.name,
          hsn_sac: prod.hsn_sac,
          quantity: qty,
          rate: prod.selling_price,
          discount_percent: 0,
          tax_percent: prod.tax_rate,
          tax_amount: tax,
          total: grand,
        }
      ],
      subtotal: taxable,
      discount_amount: 0,
      taxable_amount: taxable,
      cgst: tax / 2,
      sgst: tax / 2,
      igst: 0,
      round_off: 0,
      grand_total: grand,
      status: 'Sent',
    };

    dbState.quotations.unshift(newQuote);
    db.recordAudit('QUOTATION_CREATED', 'Sales', newQuote.id, `Created quotation ${newQuote.quotation_number} for ₹${grand}`);
    setShowAddModal(false);
  };

  const handleConvertQuoteToInvoice = (quote: Quotation) => {
    const invNumber = `${company.invoice_prefix || 'INV-'}${Date.now().toString().slice(-4)}`;
    db.createInvoice({
      customer_id: quote.customer_id,
      customer_name: quote.customer_name,
      invoice_number: invNumber,
      invoice_date: new Date().toISOString().split('T')[0],
      due_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      is_igst: quote.igst > 0,
      items: quote.items.map((it, idx) => ({
        id: `inv-it-${idx}-${Date.now()}`,
        product_id: it.product_id,
        product_name: it.product_name,
        hsn_sac: it.hsn_sac,
        quantity: it.quantity,
        unit: 'Pcs',
        rate: it.rate,
        discount_percent: it.discount_percent,
        taxable_amount: it.rate * it.quantity,
        tax_percent: it.tax_percent,
        tax_amount: it.tax_amount,
        total: it.total,
      })),
      subtotal: quote.subtotal,
      discount_amount: quote.discount_amount,
      taxable_amount: quote.taxable_amount,
      cgst: quote.cgst,
      sgst: quote.sgst,
      igst: quote.igst,
      round_off: quote.round_off,
      grand_total: quote.grand_total,
      paid_amount: 0,
      balance_amount: quote.grand_total,
      payment_status: 'Unpaid',
    });

    quote.status = 'Converted';
    alert(`Quotation ${quote.quotation_number} converted into official GST Invoice ${invNumber}!`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-2xl">
            Quotations & Estimates
          </h1>
          <p className="text-xs text-slate-500">
            Create pre-sale quotes and convert to GST invoices with one click.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-md hover:bg-indigo-700 transition"
          >
            <Plus className="h-4 w-4" />
            Create Quotation
          </button>
        </div>
      </div>

      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:bg-slate-800 dark:border-slate-700">
            <tr>
              <th className="p-3.5">Quote #</th>
              <th className="p-3.5">Customer</th>
              <th className="p-3.5">Date</th>
              <th className="p-3.5">Valid Until</th>
              <th className="p-3.5 text-right">Estimate Total</th>
              <th className="p-3.5 text-center">Status</th>
              <th className="p-3.5 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {dbState.quotations.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-12 text-center text-xs text-slate-400">
                  No quotations created yet. Click "Create Quotation" to estimate prices for prospective clients.
                </td>
              </tr>
            ) : (
              dbState.quotations.map((q) => (
                <tr key={q.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                  <td className="p-3.5 font-bold font-mono text-indigo-600">{q.quotation_number}</td>
                  <td className="p-3.5 font-semibold text-slate-900 dark:text-white">{q.customer_name}</td>
                  <td className="p-3.5 text-slate-500">{q.quotation_date}</td>
                  <td className="p-3.5 text-slate-500">{q.valid_until}</td>
                  <td className="p-3.5 text-right font-mono font-bold text-slate-900 dark:text-white">
                    ₹{q.grand_total.toLocaleString('en-IN')}
                  </td>
                  <td className="p-3.5 text-center">
                    <span className="rounded-full bg-indigo-100 px-2 py-0.5 text-[10px] font-bold text-indigo-800">
                      {q.status}
                    </span>
                  </td>
                  <td className="p-3.5 text-right">
                    {q.status !== 'Converted' && (
                      <button
                        onClick={() => handleConvertQuoteToInvoice(q)}
                        className="rounded-lg bg-indigo-50 px-2.5 py-1 text-[11px] font-semibold text-indigo-600 hover:bg-indigo-100"
                      >
                        Convert to Invoice
                      </button>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Create Price Quotation</h3>
              <button onClick={() => setShowAddModal(false)} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCreateQuotation} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Customer</label>
                <select
                  value={customerId}
                  onChange={(e) => setCustomerId(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                >
                  {dbState.customers.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Valid Until</label>
                <input
                  type="date"
                  value={validUntil}
                  onChange={(e) => setValidUntil(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Item</label>
                  <select
                    value={selectedProductId}
                    onChange={(e) => setSelectedProductId(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    {dbState.products.map((p) => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Quantity</label>
                  <input
                    type="number"
                    min="1"
                    value={qty}
                    onChange={(e) => setQty(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-indigo-600 px-5 py-2 text-xs font-bold text-white shadow hover:bg-indigo-700"
                >
                  Issue Quotation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
