import React, { useState } from 'react';
import { Building2, Check, ArrowRight, ArrowLeft, Sparkles, ShieldCheck } from 'lucide-react';
import { db } from '../../lib/db';
import { INDIAN_STATES } from '../../lib/gst';

interface OnboardingWizardProps {
  onComplete: () => void;
}

export const OnboardingWizard: React.FC<OnboardingWizardProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);

  // Form states across 8 steps
  const [companyName, setCompanyName] = useState('Apex Technologies Private Limited');
  const [legalName, setLegalName] = useState('Apex Technologies Pvt Ltd');
  const [email, setEmail] = useState('info@apextech.in');
  const [phone, setPhone] = useState('+91 98300 55443');
  const [address, setAddress] = useState('Sector V Salt Lake');
  const [city, setCity] = useState('Kolkata');
  const [state, setState] = useState('West Bengal');
  const [pincode, setPincode] = useState('700091');
  const [gstin, setGstin] = useState('19AAACA9999F1Z2');
  const [pan, setPan] = useState('AAACA9999F');
  const [currency, setCurrency] = useState('INR');
  const [warehouseName, setWarehouseName] = useState('Central Logistics Depot');
  const [warehouseCode, setWarehouseCode] = useState('WH-KOL-01');
  const [adminName, setAdminName] = useState('Ripan Pramanik');
  const [adminEmail, setAdminEmail] = useState('admin@apextech.in');
  const [invPrefix, setInvPrefix] = useState('INV-2627-');

  const handleFinish = () => {
    const stObj = INDIAN_STATES.find(s => s.name === state);
    db.addCompany({
      name: companyName,
      legal_name: legalName,
      email,
      phone,
      address_line1: address,
      city,
      state,
      state_code: stObj ? stObj.code : '19',
      pincode,
      country: 'India',
      gstin: gstin.toUpperCase(),
      pan: pan.toUpperCase(),
      currency,
      currency_symbol: '₹',
      financial_year_start: '2026-04-01',
      financial_year_end: '2027-03-31',
      invoice_prefix: invPrefix,
      quote_prefix: 'QTN-2627-',
      so_prefix: 'SO-2627-',
      po_prefix: 'PO-2627-',
      bill_prefix: 'BILL-2627-',
      bank_name: 'HDFC Bank',
      bank_account_no: '50200099887766',
      bank_ifsc: 'HDFC0000123',
      bank_branch: 'Salt Lake',
    });

    onComplete();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-2xl rounded-3xl border border-slate-800 bg-slate-900 p-8 text-white shadow-2xl">
        {/* Progress Bar */}
        <div className="flex items-center justify-between text-xs text-slate-400 pb-3 border-b border-slate-800">
          <span className="flex items-center gap-1.5 font-bold text-indigo-400">
            <Sparkles className="h-4 w-4" /> Setup Wizard
          </span>
          <span>Step {step} of 8</span>
        </div>

        <div className="mt-2 h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-indigo-500 transition-all duration-300"
            style={{ width: `${(step / 8) * 100}%` }}
          />
        </div>

        {/* Wizard Steps */}
        <div className="mt-8 min-h-[280px]">
          {step === 1 && (
            <div className="space-y-4">
              <h2 className="text-xl font-bold">Step 1: Create Your Enterprise</h2>
              <p className="text-xs text-slate-400">Enter the primary trade and legal names of your company.</p>
              <div>
                <label className="block text-xs font-semibold text-slate-300">Company Trade Name</label>
                <input
                  type="text"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 p-3 text-sm text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300">Legal Registered Name</label>
                <input
                  type="text"
                  value={legalName}
                  onChange={(e) => setLegalName(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 p-3 text-sm text-white"
                />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <h2 className="text-xl font-bold">Step 2: Company Contact & Address</h2>
              <p className="text-xs text-slate-400">Used on official GST printable invoices.</p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300">Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 p-2.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300">Phone</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 p-2.5 text-xs text-white"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300">Street Address</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 p-2.5 text-xs text-white"
                />
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <h2 className="text-xl font-bold">Step 3: Tax & GSTIN Configuration</h2>
              <p className="text-xs text-slate-400">Configure Indian GST compliance and jurisdiction.</p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300">GSTIN Number</label>
                  <input
                    type="text"
                    maxLength={15}
                    value={gstin}
                    onChange={(e) => setGstin(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 p-2.5 text-xs font-mono uppercase text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300">PAN Number</label>
                  <input
                    type="text"
                    maxLength={10}
                    value={pan}
                    onChange={(e) => setPan(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 p-2.5 text-xs font-mono uppercase text-white"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300">Registered State</label>
                <select
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 p-2.5 text-xs text-white"
                >
                  {INDIAN_STATES.map((s) => (
                    <option key={s.code} value={s.name}>{s.name} ({s.code})</option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-4">
              <h2 className="text-xl font-bold">Step 4: Financial Year & Currency</h2>
              <p className="text-xs text-slate-400">Fiscal period for balance sheets and accounts.</p>
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-xl border border-slate-700 bg-slate-800 p-4">
                  <p className="text-xs text-slate-400">Financial Year</p>
                  <p className="mt-1 text-base font-bold text-white">2026 - 2027</p>
                  <p className="text-[11px] text-slate-400 mt-1">April 1, 2026 - March 31, 2027</p>
                </div>
                <div className="rounded-xl border border-slate-700 bg-slate-800 p-4">
                  <p className="text-xs text-slate-400">Base Currency</p>
                  <p className="mt-1 text-base font-bold text-white">Indian Rupee (INR ₹)</p>
                  <p className="text-[11px] text-slate-400 mt-1">Multi-currency supported</p>
                </div>
              </div>
            </div>
          )}

          {step === 5 && (
            <div className="space-y-4">
              <h2 className="text-xl font-bold">Step 5: Primary Warehouse Depot</h2>
              <p className="text-xs text-slate-400">Default dispatch center for product stock movements.</p>
              <div>
                <label className="block text-xs font-semibold text-slate-300">Depot Name</label>
                <input
                  type="text"
                  value={warehouseName}
                  onChange={(e) => setWarehouseName(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 p-3 text-sm text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300">Depot Code</label>
                <input
                  type="text"
                  value={warehouseCode}
                  onChange={(e) => setWarehouseCode(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 p-3 text-sm text-white font-mono uppercase"
                />
              </div>
            </div>
          )}

          {step === 6 && (
            <div className="space-y-4">
              <h2 className="text-xl font-bold">Step 6: Super Administrator Profile</h2>
              <p className="text-xs text-slate-400">Root account with full access across modules.</p>
              <div>
                <label className="block text-xs font-semibold text-slate-300">Admin Full Name</label>
                <input
                  type="text"
                  value={adminName}
                  onChange={(e) => setAdminName(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 p-3 text-sm text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300">Admin Email</label>
                <input
                  type="email"
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 p-3 text-sm text-white"
                />
              </div>
            </div>
          )}

          {step === 7 && (
            <div className="space-y-4">
              <h2 className="text-xl font-bold">Step 7: Tax Invoice Formatting</h2>
              <p className="text-xs text-slate-400">Define the prefix and sequence for issued invoices.</p>
              <div>
                <label className="block text-xs font-semibold text-slate-300">Invoice Number Prefix</label>
                <input
                  type="text"
                  value={invPrefix}
                  onChange={(e) => setInvPrefix(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-800 p-3 text-sm text-white font-mono"
                />
                <p className="mt-1 text-xs text-slate-400">Sample preview: <span className="font-mono text-indigo-400">{invPrefix}001</span></p>
              </div>
            </div>
          )}

          {step === 8 && (
            <div className="space-y-4 text-center py-6">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-500/20 text-emerald-400">
                <Check className="h-8 w-8" />
              </div>
              <h2 className="text-xl font-bold">Setup Ready!</h2>
              <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
                Your business entity <span className="font-bold text-white">{companyName}</span> has been configured with GST compliance, multi-warehouse control, double-entry accounting, and audit logging.
              </p>
            </div>
          )}
        </div>

        {/* Footer Navigation */}
        <div className="mt-8 flex items-center justify-between border-t border-slate-800 pt-4">
          <button
            type="button"
            disabled={step === 1}
            onClick={() => setStep(step - 1)}
            className="flex items-center gap-1 text-xs font-semibold text-slate-400 hover:text-white disabled:opacity-30"
          >
            <ArrowLeft className="h-4 w-4" /> Previous
          </button>

          {step < 8 ? (
            <button
              type="button"
              onClick={() => setStep(step + 1)}
              className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-5 py-2.5 text-xs font-bold text-white hover:bg-indigo-700"
            >
              Continue <ArrowRight className="h-4 w-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleFinish}
              className="flex items-center gap-1.5 rounded-xl bg-emerald-500 px-6 py-2.5 text-xs font-bold text-slate-950 hover:bg-emerald-400"
            >
              Launch Dashboard <ArrowRight className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
