import React, { useState, useEffect } from 'react';
import { 
  Search, 
  X, 
  FileText, 
  Users, 
  Package, 
  Truck, 
  UserCheck, 
  Briefcase, 
  ArrowRight,
  FolderOpen
} from 'lucide-react';
import { db } from '../../lib/db';
import { ERPModule } from './Sidebar';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (module: ERPModule, itemId?: string) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
}) => {
  const [query, setQuery] = useState('');
  const [dbState, setDbState] = useState(db.getState());

  useEffect(() => {
    const unsub = db.subscribe(() => setDbState(db.getState()));
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else setQuery('');
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      unsub();
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const q = query.toLowerCase().trim();

  // Search results
  const matchingInvoices = q
    ? dbState.invoices.filter(
        (i) =>
          i.invoice_number.toLowerCase().includes(q) ||
          i.customer_name.toLowerCase().includes(q)
      ).slice(0, 4)
    : [];

  const matchingCustomers = q
    ? dbState.customers.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          (c.business_name && c.business_name.toLowerCase().includes(q)) ||
          (c.gstin && c.gstin.toLowerCase().includes(q))
      ).slice(0, 4)
    : [];

  const matchingProducts = q
    ? dbState.products.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.sku.toLowerCase().includes(q) ||
          (p.barcode && p.barcode.includes(q))
      ).slice(0, 4)
    : [];

  const matchingSuppliers = q
    ? dbState.suppliers.filter(
        (s) =>
          s.name.toLowerCase().includes(q) ||
          s.company_name.toLowerCase().includes(q) ||
          (s.gstin && s.gstin.toLowerCase().includes(q))
      ).slice(0, 4)
    : [];

  const matchingEmployees = q
    ? dbState.employees.filter(
        (e) =>
          e.name.toLowerCase().includes(q) ||
          e.employee_code.toLowerCase().includes(q) ||
          e.designation.toLowerCase().includes(q)
      ).slice(0, 4)
    : [];

  const totalResults =
    matchingInvoices.length +
    matchingCustomers.length +
    matchingProducts.length +
    matchingSuppliers.length +
    matchingEmployees.length;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 pt-16 sm:pt-24 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
      <div 
        className="w-full max-w-2xl rounded-2xl border border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-900 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="relative flex items-center border-b border-slate-200 px-4 dark:border-slate-800">
          <Search className="h-5 w-5 text-slate-400 shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type to search customers, GST invoices, products, suppliers, staff..."
            className="h-14 w-full bg-transparent px-3 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none dark:text-slate-100"
          />
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Results Body */}
        <div className="max-h-[60vh] overflow-y-auto p-3 space-y-4">
          {!q && (
            <div className="py-8 text-center text-xs text-slate-400">
              <p className="font-medium text-slate-500">Global Enterprise Search</p>
              <p className="mt-1">Quickly locate any business record by code, name, GSTIN or SKU.</p>
            </div>
          )}

          {q && totalResults === 0 && (
            <div className="py-8 text-center text-xs text-slate-400">
              No matching records found for "{query}".
            </div>
          )}

          {/* Invoices */}
          {matchingInvoices.length > 0 && (
            <div>
              <p className="px-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">Invoices</p>
              <div className="mt-1 space-y-1">
                {matchingInvoices.map((inv) => (
                  <div
                    key={inv.id}
                    onClick={() => {
                      onNavigate('invoices', inv.id);
                      onClose();
                    }}
                    className="flex items-center justify-between rounded-xl p-2 text-xs hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer transition"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400">
                        <FileText className="h-4 w-4" />
                      </div>
                      <div>
                        <p className="font-semibold text-slate-900 dark:text-slate-100">{inv.invoice_number}</p>
                        <p className="text-[11px] text-slate-500">{inv.customer_name} • ₹{inv.grand_total.toLocaleString('en-IN')}</p>
                      </div>
                    </div>
                    <ArrowRight className="h-4 w-4 text-slate-400" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Customers */}
          {matchingCustomers.length > 0 && (
            <div>
              <p className="px-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">Customers</p>
              <div className="mt-1 space-y-1">
                {matchingCustomers.map((cust) => (
                  <div
                    key={cust.id}
                    onClick={() => {
                      onNavigate('customers', cust.id);
                      onClose();
                    }}
                    className="flex items-center justify-between rounded-xl p-2 text-xs hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer transition"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400">
                        <Users className="h-4 w-4" />
                      </div>
                      <div>
                        <p className="font-semibold text-slate-900 dark:text-slate-100">{cust.name}</p>
                        <p className="text-[11px] text-slate-500">{cust.gstin || cust.billing_city} • Bal: ₹{cust.current_balance.toLocaleString('en-IN')}</p>
                      </div>
                    </div>
                    <ArrowRight className="h-4 w-4 text-slate-400" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Products */}
          {matchingProducts.length > 0 && (
            <div>
              <p className="px-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">Products & Inventory</p>
              <div className="mt-1 space-y-1">
                {matchingProducts.map((p) => (
                  <div
                    key={p.id}
                    onClick={() => {
                      onNavigate('products', p.id);
                      onClose();
                    }}
                    className="flex items-center justify-between rounded-xl p-2 text-xs hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer transition"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-amber-50 text-amber-600 dark:bg-amber-950 dark:text-amber-400">
                        <Package className="h-4 w-4" />
                      </div>
                      <div>
                        <p className="font-semibold text-slate-900 dark:text-slate-100">{p.name}</p>
                        <p className="text-[11px] text-slate-500 font-mono">SKU: {p.sku} • Stock: {p.current_stock} {p.unit} • ₹{p.selling_price.toLocaleString('en-IN')}</p>
                      </div>
                    </div>
                    <ArrowRight className="h-4 w-4 text-slate-400" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Suppliers */}
          {matchingSuppliers.length > 0 && (
            <div>
              <p className="px-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">Suppliers</p>
              <div className="mt-1 space-y-1">
                {matchingSuppliers.map((s) => (
                  <div
                    key={s.id}
                    onClick={() => {
                      onNavigate('suppliers', s.id);
                      onClose();
                    }}
                    className="flex items-center justify-between rounded-xl p-2 text-xs hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer transition"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-blue-50 text-blue-600 dark:bg-blue-950 dark:text-blue-400">
                        <Truck className="h-4 w-4" />
                      </div>
                      <div>
                        <p className="font-semibold text-slate-900 dark:text-slate-100">{s.name}</p>
                        <p className="text-[11px] text-slate-500">{s.company_name} • GSTIN: {s.gstin || 'N/A'}</p>
                      </div>
                    </div>
                    <ArrowRight className="h-4 w-4 text-slate-400" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Employees */}
          {matchingEmployees.length > 0 && (
            <div>
              <p className="px-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">Employees</p>
              <div className="mt-1 space-y-1">
                {matchingEmployees.map((emp) => (
                  <div
                    key={emp.id}
                    onClick={() => {
                      onNavigate('hr', emp.id);
                      onClose();
                    }}
                    className="flex items-center justify-between rounded-xl p-2 text-xs hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer transition"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-purple-50 text-purple-600 dark:bg-purple-950 dark:text-purple-400">
                        <UserCheck className="h-4 w-4" />
                      </div>
                      <div>
                        <p className="font-semibold text-slate-900 dark:text-slate-100">{emp.name}</p>
                        <p className="text-[11px] text-slate-500">{emp.designation} • {emp.department} ({emp.employee_code})</p>
                      </div>
                    </div>
                    <ArrowRight className="h-4 w-4 text-slate-400" />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="flex items-center justify-between border-t border-slate-200 px-4 py-2 text-[11px] text-slate-400 dark:border-slate-800">
          <span>Navigate with click • Press ESC to close</span>
          <span className="font-mono">ApexERP Enterprise Search</span>
        </div>
      </div>
    </div>
  );
};
