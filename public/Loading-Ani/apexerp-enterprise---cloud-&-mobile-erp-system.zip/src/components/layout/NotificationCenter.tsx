import React from 'react';
import { X, CheckCheck, AlertCircle, AlertTriangle, Info, CheckCircle2 } from 'lucide-react';
import { db } from '../../lib/db';
import { NotificationItem } from '../../types/erp';

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (module: string) => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  isOpen,
  onClose,
  onNavigate,
}) => {
  const dbState = db.getState();
  const notifications = dbState.notifications;

  if (!isOpen) return null;

  const getIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'ALERT':
        return <AlertCircle className="h-4 w-4 text-rose-500" />;
      case 'WARNING':
        return <AlertTriangle className="h-4 w-4 text-amber-500" />;
      case 'SUCCESS':
        return <CheckCircle2 className="h-4 w-4 text-emerald-500" />;
      default:
        return <Info className="h-4 w-4 text-blue-500" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" onClick={onClose} />
      <div className="fixed inset-y-0 right-0 flex max-w-full pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-800">
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">Notification Center</h2>
              <p className="text-xs text-slate-500">Inventory thresholds, approvals & receivables</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => db.markAllNotificationsAsRead()}
                title="Mark all as read"
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-indigo-600 dark:text-slate-400 dark:hover:bg-slate-800"
              >
                <CheckCheck className="h-4 w-4" />
              </button>
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>

          {/* List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {notifications.length === 0 ? (
              <div className="py-16 text-center text-xs text-slate-400">
                No active notifications. All operations are running smoothly!
              </div>
            ) : (
              notifications.map((item) => (
                <div
                  key={item.id}
                  onClick={() => {
                    db.markNotificationAsRead(item.id);
                    if (item.link) {
                      onNavigate(item.link);
                      onClose();
                    }
                  }}
                  className={`p-3 rounded-xl border text-xs cursor-pointer transition ${
                    item.is_read
                      ? 'border-slate-200 bg-slate-50/50 text-slate-600 dark:border-slate-800 dark:bg-slate-900/50 dark:text-slate-400'
                      : 'border-indigo-100 bg-indigo-50/30 text-slate-900 dark:border-indigo-900/50 dark:bg-indigo-950/20 dark:text-slate-100 font-medium'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    <div className="mt-0.5">{getIcon(item.type)}</div>
                    <div className="flex-1">
                      <p className="font-semibold text-slate-900 dark:text-white">{item.title}</p>
                      <p className="mt-0.5 text-slate-600 dark:text-slate-300 text-[11px] leading-relaxed">
                        {item.message}
                      </p>
                      <p className="mt-1 text-[10px] text-slate-400 font-mono">
                        {new Date(item.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
