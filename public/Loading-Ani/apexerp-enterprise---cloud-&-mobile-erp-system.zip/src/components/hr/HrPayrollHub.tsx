import React, { useState } from 'react';
import { 
  Users, 
  Plus, 
  Calendar, 
  CheckCircle, 
  DollarSign, 
  Printer, 
  Clock, 
  Download, 
  X,
  FileText
} from 'lucide-react';
import { db } from '../../lib/db';
import { Employee, AttendanceRecord, PayrollRecord } from '../../types/erp';
import { exportToCSV, printDocument } from '../../lib/exportUtils';

export const HrPayrollHub: React.FC = () => {
  const dbState = db.getState();
  const company = db.getCurrentCompany();

  const [activeTab, setActiveTab] = useState<'EMPLOYEES' | 'ATTENDANCE' | 'PAYROLL'>('EMPLOYEES');
  const [showAddEmployeeModal, setShowAddEmployeeModal] = useState(false);
  const [showPayrollModal, setShowPayrollModal] = useState(false);
  const [activePayslip, setActivePayslip] = useState<PayrollRecord | null>(null);

  // New Employee Form
  const [empName, setEmpName] = useState('');
  const [empEmail, setEmpEmail] = useState('');
  const [empPhone, setEmpPhone] = useState('');
  const [empDept, setEmpDept] = useState('Sales & Accounts');
  const [empDesignation, setEmpDesignation] = useState('');
  const [empBasic, setEmpBasic] = useState(35000);
  const [empHra, setEmpHra] = useState(14000);
  const [empBankAcc, setEmpBankAcc] = useState('');
  const [empIfsc, setEmpIfsc] = useState('');

  // Attendance quick marking
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  // Payroll generation
  const [payrollMonth, setPayrollMonth] = useState('October 2026');
  const [selectedEmpForPayroll, setSelectedEmpForPayroll] = useState(dbState.employees[0]?.id || '');
  const [bonus, setBonus] = useState(0);

  const handleCreateEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!empName.trim() || !empDesignation.trim()) return;

    db.addEmployee({
      employee_code: `EMP-${(dbState.employees.length + 1).toString().padStart(3, '0')}`,
      name: empName.trim(),
      email: empEmail.trim(),
      phone: empPhone.trim(),
      department: empDept,
      designation: empDesignation.trim(),
      joining_date: new Date().toISOString().split('T')[0],
      basic_salary: Number(empBasic),
      hra: Number(empHra),
      special_allowance: 5000,
      pf_opted: true,
      esi_opted: false,
      bank_account_no: empBankAcc.trim(),
      bank_ifsc: empIfsc.trim().toUpperCase(),
      status: 'Active',
    });

    setShowAddEmployeeModal(false);
    setEmpName('');
    setEmpDesignation('');
    setEmpEmail('');
  };

  const handleToggleAttendance = (employee: Employee, status: AttendanceRecord['status']) => {
    db.recordAttendance({
      employee_id: employee.id,
      employee_name: employee.name,
      attendance_date: selectedDate,
      status,
      check_in_time: status === 'Present' ? '09:00' : undefined,
    });
  };

  const handleGeneratePayroll = (e: React.FormEvent) => {
    e.preventDefault();
    const emp = dbState.employees.find((e) => e.id === selectedEmpForPayroll);
    if (!emp) return;

    const gross = emp.basic_salary + emp.hra + emp.special_allowance + Number(bonus);
    // Indian PF Statutory: 12% of basic
    const pfDeduction = emp.pf_opted ? Math.round(emp.basic_salary * 0.12) : 0;
    // Professional tax standard ₹200
    const ptDeduction = 200;
    const net = gross - pfDeduction - ptDeduction;

    const record = db.processPayroll({
      employee_id: emp.id,
      employee_name: emp.name,
      month_year: payrollMonth,
      working_days: 30,
      present_days: 30,
      basic_pay: emp.basic_salary,
      hra: emp.hra,
      allowances: emp.special_allowance,
      bonus: Number(bonus),
      pf_deduction: pfDeduction,
      esi_deduction: 0,
      professional_tax: ptDeduction,
      tds_deduction: 0,
      net_salary: net,
      payment_status: 'Paid',
      paid_date: new Date().toISOString().split('T')[0],
    });

    setShowPayrollModal(false);
    setActivePayslip(record);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-2xl">
            Human Resources & Payroll
          </h1>
          <p className="text-xs text-slate-500">
            Staff roster, daily biometric attendance register, and Indian statutory payroll with PF/PT.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {activeTab === 'EMPLOYEES' && (
            <button
              onClick={() => setShowAddEmployeeModal(true)}
              className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-md hover:bg-indigo-700 transition"
            >
              <Plus className="h-4 w-4" />
              Onboard Employee
            </button>
          )}
          {activeTab === 'PAYROLL' && (
            <button
              onClick={() => setShowPayrollModal(true)}
              className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-md hover:bg-indigo-700 transition"
            >
              <Plus className="h-4 w-4" />
              Generate Payslip
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 dark:border-slate-800">
        <button
          onClick={() => setActiveTab('EMPLOYEES')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition ${
            activeTab === 'EMPLOYEES'
              ? 'bg-indigo-600 text-white shadow'
              : 'bg-white text-slate-600 hover:bg-slate-100 dark:bg-slate-900 dark:text-slate-300'
          }`}
        >
          <Users className="h-4 w-4" />
          <span>Staff Directory ({dbState.employees.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('ATTENDANCE')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition ${
            activeTab === 'ATTENDANCE'
              ? 'bg-indigo-600 text-white shadow'
              : 'bg-white text-slate-600 hover:bg-slate-100 dark:bg-slate-900 dark:text-slate-300'
          }`}
        >
          <Calendar className="h-4 w-4" />
          <span>Daily Attendance Sheet</span>
        </button>

        <button
          onClick={() => setActiveTab('PAYROLL')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition ${
            activeTab === 'PAYROLL'
              ? 'bg-indigo-600 text-white shadow'
              : 'bg-white text-slate-600 hover:bg-slate-100 dark:bg-slate-900 dark:text-slate-300'
          }`}
        >
          <DollarSign className="h-4 w-4" />
          <span>Payroll & Indian Payslips</span>
        </button>
      </div>

      {/* TAB 1: EMPLOYEES */}
      {activeTab === 'EMPLOYEES' && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {dbState.employees.map((emp) => (
            <div
              key={emp.id}
              className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <span className="rounded bg-indigo-50 px-2 py-0.5 text-[10px] font-bold font-mono text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300">
                      {emp.employee_code}
                    </span>
                    <h3 className="mt-2 text-sm font-bold text-slate-900 dark:text-white">
                      {emp.name}
                    </h3>
                    <p className="text-xs text-slate-500 font-medium">{emp.designation}</p>
                  </div>
                  <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-semibold text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                    {emp.status}
                  </span>
                </div>

                <div className="mt-4 space-y-1 text-xs text-slate-600 dark:text-slate-400">
                  <p><span className="text-slate-400">Dept:</span> {emp.department}</p>
                  <p><span className="text-slate-400">Email:</span> {emp.email}</p>
                  <p><span className="text-slate-400">Phone:</span> {emp.phone}</p>
                  {emp.bank_account_no && (
                    <p className="font-mono text-[11px]"><span className="text-slate-400">A/C:</span> {emp.bank_account_no} ({emp.bank_ifsc})</p>
                  )}
                </div>
              </div>

              <div className="mt-5 border-t border-slate-100 pt-3 dark:border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-400">Base Salary</span>
                <span className="font-bold font-mono text-slate-900 dark:text-white">
                  ₹{emp.basic_salary.toLocaleString('en-IN')}/mo
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 2: ATTENDANCE */}
      {activeTab === 'ATTENDANCE' && (
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Daily Attendance Grid</h3>
              <p className="text-xs text-slate-500">Mark daily check-in or biometric synchronization</p>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500 font-medium">Select Date:</span>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="rounded-lg border border-slate-200 p-1.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>
          </div>

          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:bg-slate-800 dark:border-slate-700">
              <tr>
                <th className="p-3">Staff Code</th>
                <th className="p-3">Employee</th>
                <th className="p-3">Department</th>
                <th className="p-3 text-center">Status for {selectedDate}</th>
                <th className="p-3 text-right">Quick Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {dbState.employees.map((emp) => {
                const record = dbState.attendance.find(
                  (a) => a.employee_id === emp.id && a.attendance_date === selectedDate
                );
                const currentStatus = record?.status || 'Present';

                return (
                  <tr key={emp.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                    <td className="p-3 font-mono font-bold text-indigo-600">{emp.employee_code}</td>
                    <td className="p-3 font-semibold text-slate-900 dark:text-white">{emp.name}</td>
                    <td className="p-3 text-slate-500">{emp.department}</td>
                    <td className="p-3 text-center">
                      <span className={`inline-flex rounded-full px-2.5 py-0.5 text-[10px] font-bold ${
                        currentStatus === 'Present'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : currentStatus === 'Absent'
                          ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      }`}>
                        {currentStatus}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleToggleAttendance(emp, 'Present')}
                          className="rounded px-2 py-0.5 text-[10px] font-bold bg-emerald-50 text-emerald-700 hover:bg-emerald-100"
                        >
                          Present
                        </button>
                        <button
                          onClick={() => handleToggleAttendance(emp, 'Absent')}
                          className="rounded px-2 py-0.5 text-[10px] font-bold bg-rose-50 text-rose-700 hover:bg-rose-100"
                        >
                          Absent
                        </button>
                        <button
                          onClick={() => handleToggleAttendance(emp, 'Half Day')}
                          className="rounded px-2 py-0.5 text-[10px] font-bold bg-amber-50 text-amber-700 hover:bg-amber-100"
                        >
                          Half Day
                        </button>
                        <button
                          onClick={() => handleToggleAttendance(emp, 'WFH')}
                          className="rounded px-2 py-0.5 text-[10px] font-bold bg-blue-50 text-blue-700 hover:bg-blue-100"
                        >
                          WFH
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* TAB 3: PAYROLL */}
      {activeTab === 'PAYROLL' && (
        <div className="space-y-4">
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:bg-slate-800 dark:border-slate-700">
                <tr>
                  <th className="p-3.5">Month</th>
                  <th className="p-3.5">Employee</th>
                  <th className="p-3.5 text-right">Basic Pay</th>
                  <th className="p-3.5 text-right">HRA</th>
                  <th className="p-3.5 text-right">PF Deduction</th>
                  <th className="p-3.5 text-right">Net Salary</th>
                  <th className="p-3.5 text-center">Status</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {dbState.payroll.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-xs text-slate-400">
                      No payroll records processed yet. Click "Generate Payslip" to disburse statutory salary.
                    </td>
                  </tr>
                ) : (
                  dbState.payroll.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="p-3.5 font-bold font-mono text-indigo-600">{p.month_year}</td>
                      <td className="p-3.5 font-semibold text-slate-900 dark:text-white">{p.employee_name}</td>
                      <td className="p-3.5 text-right font-mono">₹{p.basic_pay.toLocaleString('en-IN')}</td>
                      <td className="p-3.5 text-right font-mono">₹{p.hra.toLocaleString('en-IN')}</td>
                      <td className="p-3.5 text-right font-mono text-rose-600">-₹{p.pf_deduction.toLocaleString('en-IN')}</td>
                      <td className="p-3.5 text-right font-mono font-bold text-sm text-emerald-600">
                        ₹{p.net_salary.toLocaleString('en-IN')}
                      </td>
                      <td className="p-3.5 text-center">
                        <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-800">
                          {p.payment_status}
                        </span>
                      </td>
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => setActivePayslip(p)}
                          className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:underline ml-auto"
                        >
                          <FileText className="h-3.5 w-3.5" /> View Payslip
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Onboard Employee Modal */}
      {showAddEmployeeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Onboard New Employee</h3>
              <button onClick={() => setShowAddEmployeeModal(false)} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCreateEmployee} className="mt-4 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={empName}
                    onChange={(e) => setEmpName(e.target.value)}
                    placeholder="Debashis Mukherjee"
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Designation *</label>
                  <input
                    type="text"
                    required
                    value={empDesignation}
                    onChange={(e) => setEmpDesignation(e.target.value)}
                    placeholder="Sales Executive"
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Department</label>
                  <select
                    value={empDept}
                    onChange={(e) => setEmpDept(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    <option value="Sales & Accounts">Sales & Accounts</option>
                    <option value="Logistics & Warehouse">Logistics & Warehouse</option>
                    <option value="IT & Engineering">IT & Engineering</option>
                    <option value="Executive Management">Executive Management</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Phone</label>
                  <input
                    type="tel"
                    value={empPhone}
                    onChange={(e) => setEmpPhone(e.target.value)}
                    placeholder="+91 98300 00112"
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Basic Monthly Pay (₹)</label>
                  <input
                    type="number"
                    value={empBasic}
                    onChange={(e) => setEmpBasic(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">HRA (₹)</label>
                  <input
                    type="number"
                    value={empHra}
                    onChange={(e) => setEmpHra(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddEmployeeModal(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-indigo-600 px-5 py-2 text-xs font-bold text-white shadow hover:bg-indigo-700"
                >
                  Save Employee
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Generate Payroll Modal */}
      {showPayrollModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Generate Monthly Payslip</h3>
              <button onClick={() => setShowPayrollModal(false)} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleGeneratePayroll} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Select Employee *</label>
                <select
                  value={selectedEmpForPayroll}
                  onChange={(e) => setSelectedEmpForPayroll(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                >
                  {dbState.employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} ({emp.designation}) - Base: ₹{emp.basic_salary}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Month / Year *</label>
                <input
                  type="text"
                  value={payrollMonth}
                  onChange={(e) => setPayrollMonth(e.target.value)}
                  placeholder="October 2026"
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Performance Bonus (₹)</label>
                <input
                  type="number"
                  min="0"
                  value={bonus}
                  onChange={(e) => setBonus(Number(e.target.value))}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowPayrollModal(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-indigo-600 px-5 py-2 text-xs font-bold text-white shadow hover:bg-indigo-700"
                >
                  Compute & Disburse
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Printable Payslip Modal */}
      {activePayslip && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="w-full max-w-2xl rounded-2xl border border-slate-200 bg-white p-8 shadow-2xl dark:border-slate-800 dark:bg-slate-900 my-8">
            <div className="flex items-center justify-between no-print border-b border-slate-200 pb-4 dark:border-slate-800">
              <button
                onClick={() => setActivePayslip(null)}
                className="text-xs font-semibold text-slate-500 hover:underline"
              >
                Close View
              </button>
              <button
                onClick={printDocument}
                className="flex items-center gap-1 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-bold text-white"
              >
                <Printer className="h-4 w-4" /> Print Payslip
              </button>
            </div>

            <div className="mt-6 text-slate-800 dark:text-slate-200">
              <div className="text-center border-b-2 border-slate-900 pb-3">
                <h2 className="text-base font-black uppercase text-slate-900 dark:text-white">{company.name}</h2>
                <p className="text-xs text-slate-500">PAYSLIP FOR {activePayslip.month_year.toUpperCase()}</p>
              </div>

              <div className="grid grid-cols-2 gap-4 py-4 text-xs">
                <div>
                  <p><span className="text-slate-400">Employee Name:</span> <strong className="text-slate-900 dark:text-white">{activePayslip.employee_name}</strong></p>
                  <p><span className="text-slate-400">Working Days:</span> {activePayslip.working_days}</p>
                </div>
                <div className="text-right">
                  <p><span className="text-slate-400">Status:</span> <strong>Paid</strong></p>
                  <p><span className="text-slate-400">Pay Date:</span> {activePayslip.paid_date}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6 border-y border-slate-200 py-4 text-xs font-mono">
                <div>
                  <p className="font-sans font-bold text-slate-500 uppercase text-[10px] pb-1">Earnings (₹)</p>
                  <div className="flex justify-between py-1"><span>Basic Pay:</span> <span>₹{activePayslip.basic_pay.toLocaleString('en-IN')}</span></div>
                  <div className="flex justify-between py-1"><span>HRA:</span> <span>₹{activePayslip.hra.toLocaleString('en-IN')}</span></div>
                  <div className="flex justify-between py-1"><span>Allowances:</span> <span>₹{activePayslip.allowances.toLocaleString('en-IN')}</span></div>
                  {activePayslip.bonus > 0 && <div className="flex justify-between py-1"><span>Bonus:</span> <span>₹{activePayslip.bonus.toLocaleString('en-IN')}</span></div>}
                </div>
                <div>
                  <p className="font-sans font-bold text-slate-500 uppercase text-[10px] pb-1">Deductions (₹)</p>
                  <div className="flex justify-between py-1 text-rose-600"><span>Provident Fund (12%):</span> <span>₹{activePayslip.pf_deduction.toLocaleString('en-IN')}</span></div>
                  <div className="flex justify-between py-1 text-rose-600"><span>Professional Tax (PT):</span> <span>₹{activePayslip.professional_tax.toLocaleString('en-IN')}</span></div>
                </div>
              </div>

              <div className="mt-4 flex justify-between items-center bg-slate-50 p-3 rounded-xl font-bold dark:bg-slate-800">
                <span className="text-sm">NET TAKE-HOME SALARY:</span>
                <span className="text-lg font-mono text-emerald-600">₹{activePayslip.net_salary.toLocaleString('en-IN')}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
