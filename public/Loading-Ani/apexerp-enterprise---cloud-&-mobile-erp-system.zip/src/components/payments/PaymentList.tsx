import React, { useState } from 'react';
import { 
  CreditCard, 
  Plus, 
  Search, 
  Download, 
  ArrowDownLeft, 
  ArrowUpRight, 
  CheckCircle2, 
  X 
} from 'lucide-react';
import { db } from '../../lib/db';
import { Payment } from '../../types/erp';
import { exportToCSV } from '../../lib/exportUtils';

export const PaymentList: React.FC = () => {
  const dbState = db.getState();
  const company = db.getCurrentCompany();

  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<'ALL' | 'RECEIVED' | 'PAID'>('ALL');
  const [showAddModal, setShowAddModal] = useState(false);

  // New Payment Form
  const [paymentType, setPaymentType] = useState<'RECEIVED' | 'PAID'>('RECEIVED');
  const [partyType, setPartyType] = useState<'Customer' | 'Supplier'>('Customer');
  const [partyId, setPartyId] = useState(dbState.customers[0]?.id || '');
  const [amount, setAmount] = useState(10000);
  const [paymentMode, setPaymentMode] = useState<'Bank Transfer' | 'UPI' | 'Cash' | 'Cheque'>('Bank Transfer');
  const [refNo, setRefNo] = useState('');
  const [paymentDate, setPaymentDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');

  const filtered = dbState.payments.filter((p) => {
    const matchesSearch =
      p.payment_number.toLowerCase().includes(search.toLowerCase()) ||
      p.party_name.toLowerCase().includes(search.toLowerCase()) ||
      (p.reference_no && p.reference_no.toLowerCase().includes(search.toLowerCase()));
    const matchesType = filterType === 'ALL' || p.payment_type === filterType;
    return matchesSearch && matchesType;
  });

  const handleExport = () => {
    const rows = filtered.map((p) => ({
      Payment_No: p.payment_number,
      Type: p.payment_type,
      Party_Type: p.party_type,
      Party_Name: p.party_name,
      Date: p.payment_date,
      Amount: p.amount,
      Mode: p.payment_mode,
      Reference: p.reference_no || '',
    }));
    exportToCSV(`Payments_${company.name.replace(/\s+/g, '_')}`, rows);
  };

  const handleCreatePayment = (e: React.FormEvent) => {
    e.preventDefault();
    let partyName = '';
    if (partyType === 'Customer') {
      const cust = dbState.customers.find((c) => c.id === partyId);
      if (!cust) return;
      partyName = cust.name;
    } else {
      const supp = dbState.suppliers.find((s) => s.id === partyId);
      if (!supp) return;
      partyName = supp.name;
    }

    const payNumber = `PAY-${Date.now().toString().slice(-5)}`;

    db.recordPayment({
      payment_number: payNumber,
      payment_type: paymentType,
      party_type: partyType,
      party_id: partyId,
      party_name: partyName,
      payment_date: paymentDate,
      amount: Number(amount),
      payment_mode: paymentMode,
      reference_no: refNo.trim() || undefined,
      notes: notes.trim() || undefined,
    });

    setShowAddModal(false);
    setRefNo('');
    setNotes('');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-2xl">
            Treasury & Payment Transactions
          </h1>
          <p className="text-xs text-slate-500">
            Real-time tracking of customer receipts (Accounts Receivable) and vendor payouts (Accounts Payable).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300"
          >
            <Download className="h-4 w-4" />
            Export CSV
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-md hover:bg-indigo-700 transition"
          >
            <Plus className="h-4 w-4" />
            Record Payment
          </button>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between rounded-xl border border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search payment #, customer/vendor, ref..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 py-1.5 text-xs text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-white"
          />
        </div>

        <div className="flex items-center gap-2">
          {(['ALL', 'RECEIVED', 'PAID'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setFilterType(t)}
              className={`rounded-lg px-3 py-1 text-xs font-semibold transition ${
                filterType === t
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
              }`}
            >
              {t === 'ALL' ? 'All Payments' : t === 'RECEIVED' ? 'Receipts (In)' : 'Payouts (Out)'}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-100 bg-slate-50/75 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:border-slate-800 dark:bg-slate-800/40">
              <tr>
                <th className="p-3.5">Payment #</th>
                <th className="p-3.5">Date</th>
                <th className="p-3.5 text-center">Type</th>
                <th className="p-3.5">Beneficiary / Party</th>
                <th className="p-3.5">Payment Mode</th>
                <th className="p-3.5">Reference / UTR</th>
                <th className="p-3.5 text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-xs text-slate-400">
                    No payment transactions recorded yet.
                  </td>
                </tr>
              ) : (
                filtered.map((pay) => {
                  const isReceived = pay.payment_type === 'RECEIVED';
                  return (
                    <tr key={pay.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="p-3.5 font-bold font-mono text-indigo-600 dark:text-indigo-400">
                        {pay.payment_number}
                      </td>
                      <td className="p-3.5 text-slate-500 font-mono">{pay.payment_date}</td>
                      <td className="p-3.5 text-center">
                        <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[10px] font-bold ${
                          isReceived
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                        }`}>
                          {isReceived ? <ArrowDownLeft className="h-3 w-3" /> : <ArrowUpRight className="h-3 w-3" />}
                          {isReceived ? 'Receipt' : 'Payout'}
                        </span>
                      </td>
                      <td className="p-3.5">
                        <p className="font-semibold text-slate-900 dark:text-slate-100">{pay.party_name}</p>
                        <p className="text-[10px] text-slate-400">{pay.party_type}</p>
                      </td>
                      <td className="p-3.5 text-slate-600 dark:text-slate-300 font-medium">
                        {pay.payment_mode}
                      </td>
                      <td className="p-3.5 text-slate-500 font-mono text-[11px]">
                        {pay.reference_no || '—'}
                      </td>
                      <td className={`p-3.5 text-right font-mono font-bold text-sm ${isReceived ? 'text-emerald-600' : 'text-slate-900 dark:text-white'}`}>
                        {isReceived ? '+' : '-'}₹{pay.amount.toLocaleString('en-IN')}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Record Payment Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Record Treasury Transaction
              </h3>
              <button onClick={() => setShowAddModal(false)} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePayment} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Transaction Direction</label>
                <div className="mt-1 flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setPaymentType('RECEIVED');
                      setPartyType('Customer');
                      setPartyId(dbState.customers[0]?.id || '');
                    }}
                    className={`flex-1 rounded-xl py-2 text-xs font-bold transition ${
                      paymentType === 'RECEIVED'
                        ? 'bg-emerald-600 text-white shadow'
                        : 'border border-slate-200 text-slate-600 dark:border-slate-700 dark:text-slate-300'
                    }`}
                  >
                    Incoming Receipt (Customer)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setPaymentType('PAID');
                      setPartyType('Supplier');
                      setPartyId(dbState.suppliers[0]?.id || '');
                    }}
                    className={`flex-1 rounded-xl py-2 text-xs font-bold transition ${
                      paymentType === 'PAID'
                        ? 'bg-rose-600 text-white shadow'
                        : 'border border-slate-200 text-slate-600 dark:border-slate-700 dark:text-slate-300'
                    }`}
                  >
                    Outgoing Payout (Vendor)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  {partyType} *
                </label>
                <select
                  value={partyId}
                  onChange={(e) => setPartyId(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                >
                  {partyType === 'Customer'
                    ? dbState.customers.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name} (Due: ₹{c.current_balance})
                        </option>
                      ))
                    : dbState.suppliers.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name} (Payable: ₹{s.current_balance})
                        </option>
                      ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Amount (₹) *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono font-bold text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Date *</label>
                  <input
                    type="date"
                    required
                    value={paymentDate}
                    onChange={(e) => setPaymentDate(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Payment Mode</label>
                  <select
                    value={paymentMode}
                    onChange={(e) => setPaymentMode(e.target.value as any)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    <option value="Bank Transfer">Bank Transfer (NEFT/RTGS)</option>
                    <option value="UPI">UPI Instant</option>
                    <option value="Cash">Cash Counter</option>
                    <option value="Cheque">Cheque Deposit</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Ref / Transaction UTR</label>
                  <input
                    type="text"
                    value={refNo}
                    onChange={(e) => setRefNo(e.target.value)}
                    placeholder="e.g. HDFC202610034491"
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Notes / Remarks</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Optional internal remarks"
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-indigo-600 px-5 py-2 text-xs font-bold text-white shadow hover:bg-indigo-700"
                >
                  Post Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
