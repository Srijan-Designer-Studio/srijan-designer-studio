import React, { useState } from 'react';
import { Receipt, Plus, Search, Download, X } from 'lucide-react';
import { db } from '../../lib/db';
import { Expense } from '../../types/erp';
import { exportToCSV } from '../../lib/exportUtils';

export const ExpenseList: React.FC = () => {
  const dbState = db.getState();
  const company = db.getCurrentCompany();

  const [search, setSearch] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  // New Expense form
  const [categoryName, setCategoryName] = useState('Rent & Utilities');
  const [amount, setAmount] = useState(5000);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [vendor, setVendor] = useState('');
  const [paymentMode, setPaymentMode] = useState('Bank Transfer');
  const [description, setDescription] = useState('');

  const filtered = dbState.expenses.filter((e) => {
    return (
      e.expense_number.toLowerCase().includes(search.toLowerCase()) ||
      e.category_name.toLowerCase().includes(search.toLowerCase()) ||
      e.description.toLowerCase().includes(search.toLowerCase()) ||
      (e.vendor && e.vendor.toLowerCase().includes(search.toLowerCase()))
    );
  });

  const totalExpenseAmount = dbState.expenses.reduce((acc, e) => acc + e.amount, 0);

  const handleExport = () => {
    const rows = filtered.map((e) => ({
      Expense_No: e.expense_number,
      Date: e.expense_date,
      Category: e.category_name,
      Vendor: e.vendor || '',
      Amount: e.amount,
      Mode: e.payment_mode,
      Description: e.description,
      Status: e.status,
    }));
    exportToCSV(`Expenses_${company.name.replace(/\s+/g, '_')}`, rows);
  };

  const handleCreateExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim() || amount <= 0) {
      alert('Description and valid amount are required');
      return;
    }

    const expNo = `EXP-${Date.now().toString().slice(-4)}`;
    db.addExpense({
      expense_number: expNo,
      category_name: categoryName,
      expense_date: date,
      amount: Number(amount),
      payment_mode: paymentMode,
      vendor: vendor.trim() || undefined,
      description: description.trim(),
      status: 'Approved',
    });

    setShowAddModal(false);
    setDescription('');
    setVendor('');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-2xl">
            Operating Expense Management
          </h1>
          <p className="text-xs text-slate-500">
            Track operational overheads, utility bills, maintenance, and administrative disbursements.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300"
          >
            <Download className="h-4 w-4" />
            Export CSV
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow-md hover:bg-indigo-700 transition"
          >
            <Plus className="h-4 w-4" />
            Record Expense
          </button>
        </div>
      </div>

      {/* Summary Banner */}
      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900 flex items-center justify-between">
        <div>
          <p className="text-xs text-slate-500">Total Recorded Overheads</p>
          <p className="text-xl font-bold text-slate-900 dark:text-white">
            ₹{totalExpenseAmount.toLocaleString('en-IN')}
          </p>
        </div>
        <div className="relative max-w-xs w-full">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search expenses..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 py-1.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
          />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-100 bg-slate-50/75 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:border-slate-800 dark:bg-slate-800/40">
              <tr>
                <th className="p-3.5">Expense #</th>
                <th className="p-3.5">Date</th>
                <th className="p-3.5">Category</th>
                <th className="p-3.5">Description</th>
                <th className="p-3.5">Vendor / Payee</th>
                <th className="p-3.5">Payment Mode</th>
                <th className="p-3.5 text-right">Amount</th>
                <th className="p-3.5 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filtered.map((exp) => (
                <tr key={exp.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                  <td className="p-3.5 font-bold font-mono text-indigo-600 dark:text-indigo-400">
                    {exp.expense_number}
                  </td>
                  <td className="p-3.5 text-slate-500 font-mono">{exp.expense_date}</td>
                  <td className="p-3.5 font-semibold text-slate-900 dark:text-white">
                    {exp.category_name}
                  </td>
                  <td className="p-3.5 text-slate-600 dark:text-slate-300 max-w-xs truncate">
                    {exp.description}
                  </td>
                  <td className="p-3.5 text-slate-500">{exp.vendor || '—'}</td>
                  <td className="p-3.5 text-slate-600 dark:text-slate-300">{exp.payment_mode}</td>
                  <td className="p-3.5 text-right font-mono font-bold text-slate-900 dark:text-white">
                    ₹{exp.amount.toLocaleString('en-IN')}
                  </td>
                  <td className="p-3.5 text-center">
                    <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                      {exp.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Expense Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Record Operating Expense</h3>
              <button onClick={() => setShowAddModal(false)} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCreateExpense} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Category *</label>
                <select
                  value={categoryName}
                  onChange={(e) => setCategoryName(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                >
                  <option value="Rent & Utilities">Rent & Building Maintenance</option>
                  <option value="Electricity & Power">Electricity & Power</option>
                  <option value="High-Speed Internet & Cloud">High-Speed Internet & Cloud</option>
                  <option value="Office Supplies & Stationery">Office Supplies & Stationery</option>
                  <option value="Travel & Logistics">Travel, Freight & Logistics</option>
                  <option value="Advertising & Marketing">Advertising & Marketing</option>
                  <option value="Legal & Audit Compliance">Legal & Audit Compliance</option>
                  <option value="Miscellaneous Overhead">Miscellaneous Overhead</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Amount (₹) *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono font-bold text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Expense Date *</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Vendor / Payee</label>
                  <input
                    type="text"
                    value={vendor}
                    onChange={(e) => setVendor(e.target.value)}
                    placeholder="e.g. WBSEDCL / Tech Park"
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Payment Mode</label>
                  <select
                    value={paymentMode}
                    onChange={(e) => setPaymentMode(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    <option value="Bank Transfer">Bank Transfer (NEFT/RTGS)</option>
                    <option value="UPI">UPI Instant</option>
                    <option value="Cash">Cash / Petty Cash</option>
                    <option value="Corporate Card">Corporate Card</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Description *</label>
                <textarea
                  rows={2}
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Detail regarding purpose of disbursement"
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-indigo-600 px-5 py-2 text-xs font-bold text-white shadow hover:bg-indigo-700"
                >
                  Post Expense
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
