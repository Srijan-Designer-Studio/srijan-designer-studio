import React, { useState } from 'react';
import { 
  Building2, 
  Database, 
  ShieldCheck, 
  Save, 
  RotateCcw, 
  CheckCircle2, 
  AlertTriangle,
  Server
} from 'lucide-react';
import { db } from '../../lib/db';
import { INDIAN_STATES } from '../../lib/gst';
import { testSupabaseConnection, isSupabaseConfigured } from '../../lib/supabase';

export const SystemSettings: React.FC = () => {
  const dbState = db.getState();
  const company = db.getCurrentCompany();

  const [activeTab, setActiveTab] = useState<'COMPANY' | 'BANK' | 'SUPABASE' | 'ROLES' | 'DATA'>('COMPANY');

  // Company Form
  const [name, setName] = useState(company.name);
  const [legalName, setLegalName] = useState(company.legal_name || '');
  const [email, setEmail] = useState(company.email);
  const [phone, setPhone] = useState(company.phone);
  const [gstin, setGstin] = useState(company.gstin || '');
  const [pan, setPan] = useState(company.pan || '');
  const [cin, setCin] = useState(company.cin || '');
  const [address1, setAddress1] = useState(company.address_line1);
  const [address2, setAddress2] = useState(company.address_line2 || '');
  const [city, setCity] = useState(company.city);
  const [state, setState] = useState(company.state);
  const [pincode, setPincode] = useState(company.pincode);
  const [invPrefix, setInvPrefix] = useState(company.invoice_prefix);

  // Bank Form
  const [bankName, setBankName] = useState(company.bank_name || '');
  const [bankAccNo, setBankAccNo] = useState(company.bank_account_no || '');
  const [bankIfsc, setBankIfsc] = useState(company.bank_ifsc || '');
  const [bankBranch, setBankBranch] = useState(company.bank_branch || '');
  const [upiId, setUpiId] = useState(company.upi_id || '');

  // Supabase test form
  const [supabaseUrl, setSupabaseUrl] = useState(import.meta.env.VITE_SUPABASE_URL || '');
  const [supabaseKey, setSupabaseKey] = useState(import.meta.env.VITE_SUPABASE_ANON_KEY || '');
  const [testingConnection, setTestingConnection] = useState(false);
  const [connectionResult, setConnectionResult] = useState<{ success: boolean; message: string } | null>(null);

  const handleSaveCompany = (e: React.FormEvent) => {
    e.preventDefault();
    const stObj = INDIAN_STATES.find(s => s.name === state);
    db.updateCompany({
      ...company,
      name,
      legal_name: legalName,
      email,
      phone,
      gstin: gstin.toUpperCase(),
      pan: pan.toUpperCase(),
      cin: cin.toUpperCase(),
      address_line1: address1,
      address_line2: address2,
      city,
      state,
      state_code: stObj ? stObj.code : company.state_code,
      pincode,
      invoice_prefix: invPrefix,
      bank_name: bankName,
      bank_account_no: bankAccNo,
      bank_ifsc: bankIfsc.toUpperCase(),
      bank_branch: bankBranch,
      upi_id: upiId,
    });
    alert('Company profile & statutory details updated successfully!');
  };

  const handleTestSupabase = async () => {
    setTestingConnection(true);
    setConnectionResult(null);
    const res = await testSupabaseConnection(supabaseUrl, supabaseKey);
    setConnectionResult(res);
    setTestingConnection(false);
  };

  const handleResetData = () => {
    if (window.confirm('Are you sure you want to reset demo data? All local invoices, stock adjustments, and logs will return to pristine demo setup.')) {
      db.resetToFreshDatabase();
      window.location.reload();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-2xl">
            System & Business Configuration
          </h1>
          <p className="text-xs text-slate-500">
            Multi-company governance, GST tax configuration, banking details, and live Supabase sync.
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-2 dark:border-slate-800">
        {[
          { id: 'COMPANY', label: 'Company Profile & GSTIN' },
          { id: 'BANK', label: 'Banking & UPI Details' },
          { id: 'SUPABASE', label: 'Supabase PostgreSQL Config' },
          { id: 'ROLES', label: 'RBAC Roles & Permissions' },
          { id: 'DATA', label: 'Data Management & Reset' },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as any)}
            className={`rounded-xl px-4 py-2 text-xs font-bold transition ${
              activeTab === t.id
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-white text-slate-600 hover:bg-slate-100 dark:bg-slate-900 dark:text-slate-300'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* TAB 1: COMPANY PROFILE */}
      {activeTab === 'COMPANY' && (
        <form onSubmit={handleSaveCompany} className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 pb-2 dark:border-slate-800">
            Statutory Company Information
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Company Trade Name *</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Legal Registered Name</label>
              <input
                type="text"
                value={legalName}
                onChange={(e) => setLegalName(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">GSTIN (15 Digits) *</label>
              <input
                type="text"
                required
                maxLength={15}
                value={gstin}
                onChange={(e) => setGstin(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono uppercase text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Company PAN *</label>
              <input
                type="text"
                required
                maxLength={10}
                value={pan}
                onChange={(e) => setPan(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono uppercase text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">CIN (Corporate ID)</label>
              <input
                type="text"
                value={cin}
                onChange={(e) => setCin(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono uppercase text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Primary Email *</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Phone Number *</label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Address Line 1 *</label>
            <input
              type="text"
              required
              value={address1}
              onChange={(e) => setAddress1(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">City *</label>
              <input
                type="text"
                required
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">State *</label>
              <select
                value={state}
                onChange={(e) => setState(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              >
                {INDIAN_STATES.map((s) => (
                  <option key={s.code} value={s.name}>{s.name} ({s.code})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">PIN Code *</label>
              <input
                type="text"
                required
                value={pincode}
                onChange={(e) => setPincode(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="submit"
              className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-5 py-2.5 text-xs font-bold text-white shadow-md hover:bg-indigo-700 transition"
            >
              <Save className="h-4 w-4" /> Save Profile
            </button>
          </div>
        </form>
      )}

      {/* TAB 2: BANK DETAILS */}
      {activeTab === 'BANK' && (
        <form onSubmit={handleSaveCompany} className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 pb-2 dark:border-slate-800">
            Bank Accounts & UPI for Invoices
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Bank Name</label>
              <input
                type="text"
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
                placeholder="e.g. HDFC Bank Ltd"
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Account Number</label>
              <input
                type="text"
                value={bankAccNo}
                onChange={(e) => setBankAccNo(e.target.value)}
                placeholder="e.g. 50200012345678"
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">IFSC Code</label>
              <input
                type="text"
                value={bankIfsc}
                onChange={(e) => setBankIfsc(e.target.value)}
                placeholder="e.g. HDFC0000123"
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono uppercase text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">Branch Name</label>
              <input
                type="text"
                value={bankBranch}
                onChange={(e) => setBankBranch(e.target.value)}
                placeholder="Salt Lake Sector V"
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">UPI Virtual Payment Address</label>
              <input
                type="text"
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                placeholder="apexglobal@hdfcbank"
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="submit"
              className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-5 py-2.5 text-xs font-bold text-white shadow-md hover:bg-indigo-700 transition"
            >
              <Save className="h-4 w-4" /> Save Bank Details
            </button>
          </div>
        </form>
      )}

      {/* TAB 3: SUPABASE CONFIG */}
      {activeTab === 'SUPABASE' && (
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 space-y-4">
          <div className="flex items-start justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Supabase PostgreSQL Database Connection
              </h3>
              <p className="text-xs text-slate-500">
                Connect your real Supabase project URL and API anon key for persistent cloud synchronization.
              </p>
            </div>
            <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ${
              isSupabaseConfigured
                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
            }`}>
              <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
              {isSupabaseConfigured ? 'Supabase Live Connected' : 'Running on Apex Database Engine'}
            </span>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Supabase Project URL (VITE_SUPABASE_URL)
              </label>
              <input
                type="text"
                value={supabaseUrl}
                onChange={(e) => setSupabaseUrl(e.target.value)}
                placeholder="https://your-project.supabase.co"
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Supabase Anon Public API Key (VITE_SUPABASE_ANON_KEY)
              </label>
              <textarea
                rows={2}
                value={supabaseKey}
                onChange={(e) => setSupabaseKey(e.target.value)}
                placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50 p-2.5 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </div>

            {connectionResult && (
              <div className={`p-3 rounded-xl text-xs font-medium flex items-center gap-2 ${
                connectionResult.success
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300'
                  : 'bg-rose-50 text-rose-800 border border-rose-200 dark:bg-rose-950/40 dark:text-rose-300'
              }`}>
                {connectionResult.success ? <CheckCircle2 className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
                <span>{connectionResult.message}</span>
              </div>
            )}

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                disabled={testingConnection}
                onClick={handleTestSupabase}
                className="flex items-center gap-1.5 rounded-xl border border-indigo-600 bg-indigo-50 px-4 py-2 text-xs font-bold text-indigo-700 hover:bg-indigo-100 dark:bg-indigo-950 dark:text-indigo-300 transition"
              >
                <Server className="h-4 w-4" />
                {testingConnection ? 'Testing Connection...' : 'Test Supabase Connection'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: RBAC ROLES */}
      {activeTab === 'ROLES' && (
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 pb-2 dark:border-slate-800">
            Role-Based Access Control (RBAC Matrix)
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-[11px] font-bold uppercase text-slate-400 border-b border-slate-200 dark:bg-slate-800">
                <tr>
                  <th className="p-3">Role</th>
                  <th className="p-3 text-center">Sales & Invoices</th>
                  <th className="p-3 text-center">Purchases</th>
                  <th className="p-3 text-center">Inventory</th>
                  <th className="p-3 text-center">Accounting & P&L</th>
                  <th className="p-3 text-center">HR & Payroll</th>
                  <th className="p-3 text-center">Settings</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {[
                  { role: 'Super Admin', s: 'Full', p: 'Full', i: 'Full', a: 'Full', h: 'Full', cfg: 'Full' },
                  { role: 'Company Admin', s: 'Full', p: 'Full', i: 'Full', a: 'Full', h: 'Full', cfg: 'Full' },
                  { role: 'Accountant', s: 'Read/Write', p: 'Read/Write', i: 'Read', a: 'Full', h: 'Payroll Only', cfg: 'None' },
                  { role: 'Sales Executive', s: 'Create/Read', p: 'None', i: 'Read', a: 'None', h: 'None', cfg: 'None' },
                  { role: 'Purchase Manager', s: 'None', p: 'Full', i: 'Stock In', a: 'None', h: 'None', cfg: 'None' },
                  { role: 'Inventory Manager', s: 'Read', p: 'Receive', i: 'Full', a: 'None', h: 'None', cfg: 'None' },
                ].map((r, idx) => (
                  <tr key={idx}>
                    <td className="p-3 font-bold text-slate-900 dark:text-white">{r.role}</td>
                    <td className="p-3 text-center font-mono">{r.s}</td>
                    <td className="p-3 text-center font-mono">{r.p}</td>
                    <td className="p-3 text-center font-mono">{r.i}</td>
                    <td className="p-3 text-center font-mono">{r.a}</td>
                    <td className="p-3 text-center font-mono">{r.h}</td>
                    <td className="p-3 text-center font-mono">{r.cfg}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: DATA RESET */}
      {activeTab === 'DATA' && (
        <div className="rounded-2xl border border-rose-200 bg-rose-50/30 p-6 shadow-sm dark:border-rose-900/50 dark:bg-rose-950/20 space-y-4">
          <div>
            <h3 className="text-sm font-bold text-rose-800 dark:text-rose-400">
              Database Reset & Data Governance
            </h3>
            <p className="text-xs text-rose-600/80 dark:text-rose-400/80 mt-1">
              Reset your ERP instance back to clean starter data or clear all transactional records before production launch.
            </p>
          </div>

          <div className="pt-2">
            <button
              onClick={handleResetData}
              className="flex items-center gap-1.5 rounded-xl bg-rose-600 px-4 py-2.5 text-xs font-bold text-white shadow hover:bg-rose-700 transition"
            >
              <RotateCcw className="h-4 w-4" />
              Reset to Fresh Initial ERP Database
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
