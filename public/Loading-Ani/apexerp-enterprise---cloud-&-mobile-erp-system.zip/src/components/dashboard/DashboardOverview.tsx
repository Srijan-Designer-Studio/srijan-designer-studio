import React from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  CreditCard, 
  Package, 
  AlertTriangle, 
  ArrowUpRight, 
  ArrowDownRight,
  Clock,
  Building2,
  Users,
  CheckCircle,
  FileText
} from 'lucide-react';
import { db } from '../../lib/db';
import { ERPModule } from '../layout/Sidebar';

interface DashboardOverviewProps {
  onNavigate: (module: ERPModule) => void;
  onNewInvoice: () => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({ onNavigate, onNewInvoice }) => {
  const dbState = db.getState();
  const company = db.getCurrentCompany();

  // Metrics computation from real database state
  const totalSales = dbState.invoices.reduce((acc, i) => acc + i.grand_total, 0);
  const totalPurchases = dbState.purchaseBills.reduce((acc, b) => acc + b.grand_total, 0);
  const totalExpenses = dbState.expenses.reduce((acc, e) => acc + e.amount, 0);
  const totalReceivables = dbState.invoices.reduce((acc, i) => acc + i.balance_amount, 0);
  const totalPayables = dbState.purchaseBills.reduce((acc, b) => acc + b.balance_amount, 0);
  const netProfit = totalSales - totalPurchases - totalExpenses;

  const inventoryValue = dbState.products.reduce((acc, p) => acc + (p.current_stock * p.purchase_price), 0);
  const lowStockCount = dbState.products.filter(p => p.current_stock <= p.min_stock_alert).length;

  const bankAccount = dbState.accounts.find(a => a.id === 'acc-bank-01')?.current_balance || 485200;
  const cashAccount = dbState.accounts.find(a => a.id === 'acc-cash-01')?.current_balance || 24500;

  const currency = company.currency_symbol || '₹';

  return (
    <div className="space-y-6">
      {/* Top Banner / Welcome */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between rounded-2xl bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 p-6 text-white shadow-lg">
        <div>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-indigo-500/20 px-3 py-1 text-xs font-medium text-indigo-200 backdrop-blur-md">
            <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
            Live Enterprise Financial Ledger Active
          </span>
          <h1 className="mt-2 text-xl font-bold tracking-tight sm:text-2xl">
            {company.name}
          </h1>
          <p className="mt-1 text-xs text-indigo-200">
            GSTIN: <span className="font-mono font-semibold">{company.gstin || 'Not registered'}</span> • State: {company.state} (Code {company.state_code})
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('reports')}
            className="rounded-xl border border-indigo-400/30 bg-white/10 px-4 py-2 text-xs font-semibold text-white backdrop-blur-md hover:bg-white/20 transition"
          >
            Financial Reports
          </button>
          <button
            onClick={onNewInvoice}
            className="flex items-center gap-1.5 rounded-xl bg-white px-4 py-2 text-xs font-bold text-indigo-900 shadow-md hover:bg-indigo-50 transition"
          >
            <FileText className="h-4 w-4" />
            Create GST Invoice
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Total Sales */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Total Billed Sales</span>
            <div className="rounded-xl bg-emerald-50 p-2 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400">
              <TrendingUp className="h-5 w-5" />
            </div>
          </div>
          <p className="mt-3 text-2xl font-bold text-slate-900 dark:text-white">
            {currency} {totalSales.toLocaleString('en-IN')}
          </p>
          <div className="mt-2 flex items-center text-[11px] text-emerald-600 font-medium">
            <ArrowUpRight className="h-3.5 w-3.5 mr-0.5" />
            <span>{dbState.invoices.length} invoices generated</span>
          </div>
        </div>

        {/* Net Profit */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Net Operating Margin</span>
            <div className={`rounded-xl p-2 ${netProfit >= 0 ? 'bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400' : 'bg-rose-50 text-rose-600'}`}>
              <DollarSign className="h-5 w-5" />
            </div>
          </div>
          <p className="mt-3 text-2xl font-bold text-slate-900 dark:text-white">
            {currency} {netProfit.toLocaleString('en-IN')}
          </p>
          <p className="mt-2 text-[11px] text-slate-500">
            Sales less Bills & Expenses
          </p>
        </div>

        {/* Outstanding Receivables */}
        <div 
          onClick={() => onNavigate('customers')} 
          className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900 cursor-pointer hover:border-indigo-300 transition"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Accounts Receivable (Due)</span>
            <div className="rounded-xl bg-amber-50 p-2 text-amber-600 dark:bg-amber-950 dark:text-amber-400">
              <Clock className="h-5 w-5" />
            </div>
          </div>
          <p className="mt-3 text-2xl font-bold text-amber-600 dark:text-amber-400">
            {currency} {totalReceivables.toLocaleString('en-IN')}
          </p>
          <p className="mt-2 text-[11px] text-slate-500">
            Pending collection from customers
          </p>
        </div>

        {/* Outstanding Payables */}
        <div 
          onClick={() => onNavigate('suppliers')}
          className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900 cursor-pointer hover:border-indigo-300 transition"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Accounts Payable (Bills)</span>
            <div className="rounded-xl bg-rose-50 p-2 text-rose-600 dark:bg-rose-950 dark:text-rose-400">
              <CreditCard className="h-5 w-5" />
            </div>
          </div>
          <p className="mt-3 text-2xl font-bold text-rose-600 dark:text-rose-400">
            {currency} {totalPayables.toLocaleString('en-IN')}
          </p>
          <p className="mt-2 text-[11px] text-slate-500">
            Pending payouts to suppliers
          </p>
        </div>
      </div>

      {/* Secondary Metrics Bar: Liquidity & Stock */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-3.5 dark:border-slate-800 dark:bg-slate-900">
          <p className="text-[11px] font-medium text-slate-500">Main Bank Liquidity</p>
          <p className="mt-1 text-base font-bold text-slate-800 dark:text-slate-100">
            {currency} {bankAccount.toLocaleString('en-IN')}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-3.5 dark:border-slate-800 dark:bg-slate-900">
          <p className="text-[11px] font-medium text-slate-500">Total Inventory Valuation</p>
          <p className="mt-1 text-base font-bold text-slate-800 dark:text-slate-100">
            {currency} {inventoryValue.toLocaleString('en-IN')}
          </p>
        </div>
        <div 
          onClick={() => onNavigate('products')}
          className="rounded-xl border border-slate-200 bg-white p-3.5 dark:border-slate-800 dark:bg-slate-900 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50"
        >
          <p className="text-[11px] font-medium text-slate-500">Low Stock Alert</p>
          <p className={`mt-1 text-base font-bold ${lowStockCount > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
            {lowStockCount} {lowStockCount === 1 ? 'Item' : 'Items'} Critical
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-3.5 dark:border-slate-800 dark:bg-slate-900">
          <p className="text-[11px] font-medium text-slate-500">Active Warehouses</p>
          <p className="mt-1 text-base font-bold text-indigo-600 dark:text-indigo-400">
            {dbState.warehouses.length} Logistics Depots
          </p>
        </div>
      </div>

      {/* Main Breakdown Section: Recent Invoices & Top Inventory */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Recent Invoices Table (2 cols) */}
        <div className="lg:col-span-2 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">Recent Tax Invoices</h2>
              <p className="text-xs text-slate-500">Real-time status of dispatched orders and receivables</p>
            </div>
            <button
              onClick={() => onNavigate('invoices')}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 dark:text-indigo-400"
            >
              View All Invoices →
            </button>
          </div>

          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-[11px] font-semibold text-slate-400 uppercase tracking-wider dark:border-slate-800">
                  <th className="pb-3">Invoice #</th>
                  <th className="pb-3">Customer</th>
                  <th className="pb-3">Date</th>
                  <th className="pb-3 text-right">Amount</th>
                  <th className="pb-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {dbState.invoices.slice(0, 5).map((inv) => (
                  <tr key={inv.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                    <td className="py-3 font-semibold text-indigo-600 dark:text-indigo-400 font-mono">
                      {inv.invoice_number}
                    </td>
                    <td className="py-3 text-slate-800 dark:text-slate-200">
                      <p className="font-medium">{inv.customer_name}</p>
                      <p className="text-[10px] text-slate-400 font-mono">{inv.customer_gstin || 'B2C Retail'}</p>
                    </td>
                    <td className="py-3 text-slate-500">{inv.invoice_date}</td>
                    <td className="py-3 text-right font-bold text-slate-900 dark:text-white">
                      {currency} {inv.grand_total.toLocaleString('en-IN')}
                    </td>
                    <td className="py-3 text-center">
                      <span className={`inline-flex rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                        inv.payment_status === 'Paid'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-400'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-400'
                      }`}>
                        {inv.payment_status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Critical Inventory & Low Stock Card (1 col) */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900 flex flex-col">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">Stock Status</h2>
              <p className="text-xs text-slate-500">Warehouse inventory monitors</p>
            </div>
            <button
              onClick={() => onNavigate('products')}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 dark:text-indigo-400"
            >
              Inventory →
            </button>
          </div>

          <div className="mt-4 flex-1 space-y-3">
            {dbState.products.slice(0, 5).map((p) => {
              const isLow = p.current_stock <= p.min_stock_alert;
              return (
                <div key={p.id} className="flex items-center justify-between p-2.5 rounded-xl border border-slate-100 bg-slate-50/50 dark:border-slate-800 dark:bg-slate-800/40">
                  <div className="space-y-0.5">
                    <p className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate max-w-[160px]">
                      {p.name}
                    </p>
                    <p className="text-[10px] font-mono text-slate-400">
                      SKU: {p.sku} • HSN: {p.hsn_sac}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className={`text-xs font-bold ${isLow ? 'text-rose-600' : 'text-slate-800 dark:text-slate-200'}`}>
                      {p.current_stock} {p.unit}
                    </span>
                    {isLow && (
                      <p className="text-[9px] font-medium text-rose-500 flex items-center gap-0.5 justify-end">
                        <AlertTriangle className="h-2.5 w-2.5" /> Below Min ({p.min_stock_alert})
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={() => onNavigate('warehouses')}
              className="w-full text-center text-xs font-medium text-slate-500 hover:text-indigo-600 transition"
            >
              Manage Multi-Warehouse Stock Transfers
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
