import React, { useState } from 'react';
import { ShieldAlert, Search, Download, CheckCircle2 } from 'lucide-react';
import { db } from '../../lib/db';
import { exportToCSV } from '../../lib/exportUtils';

export const AuditLogViewer: React.FC = () => {
  const dbState = db.getState();
  const company = db.getCurrentCompany();

  const [search, setSearch] = useState('');
  const [filterModule, setFilterModule] = useState<string>('ALL');

  const filtered = dbState.auditLogs.filter((log) => {
    const matchesSearch =
      log.action.toLowerCase().includes(search.toLowerCase()) ||
      log.details.toLowerCase().includes(search.toLowerCase()) ||
      log.user_email.toLowerCase().includes(search.toLowerCase());
    const matchesModule = filterModule === 'ALL' || log.module.toUpperCase() === filterModule;
    return matchesSearch && matchesModule;
  });

  const handleExport = () => {
    const rows = filtered.map((l) => ({
      Timestamp: l.created_at,
      User: l.user_email,
      Action: l.action,
      Module: l.module,
      Record_ID: l.record_id || '',
      Details: l.details,
    }));
    exportToCSV(`Audit_Log_${company.name.replace(/\s+/g, '_')}`, rows);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-2xl">
            Immutable Audit Trail & Compliance Log
          </h1>
          <p className="text-xs text-slate-500">
            Cryptographically sealed and tamper-evident event log of all financial, inventory, and administrative mutations.
          </p>
        </div>

        <button
          onClick={handleExport}
          className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300"
        >
          <Download className="h-4 w-4" />
          Export Audit Trail
        </button>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between rounded-xl border border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search action, user, or details..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 py-1.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
          />
        </div>

        <div className="flex items-center gap-2">
          {['ALL', 'SALES', 'PURCHASES', 'INVENTORY', 'PAYMENTS', 'SETTINGS'].map((mod) => (
            <button
              key={mod}
              onClick={() => setFilterModule(mod)}
              className={`rounded-lg px-2.5 py-1 text-xs font-semibold transition ${
                filterModule === mod
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
              }`}
            >
              {mod}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:bg-slate-800 dark:border-slate-700">
            <tr>
              <th className="p-3.5">Timestamp</th>
              <th className="p-3.5">User</th>
              <th className="p-3.5">Module</th>
              <th className="p-3.5">Action Event</th>
              <th className="p-3.5">Description & Record State</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {filtered.map((log) => (
              <tr key={log.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                <td className="p-3.5 text-slate-500 font-mono text-[11px]">
                  {new Date(log.created_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'medium' })}
                </td>
                <td className="p-3.5 font-medium text-slate-900 dark:text-white">
                  {log.user_email}
                </td>
                <td className="p-3.5">
                  <span className="rounded bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                    {log.module}
                  </span>
                </td>
                <td className="p-3.5 font-mono font-bold text-indigo-600 dark:text-indigo-400">
                  {log.action}
                </td>
                <td className="p-3.5 text-slate-600 dark:text-slate-300">
                  {log.details}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
