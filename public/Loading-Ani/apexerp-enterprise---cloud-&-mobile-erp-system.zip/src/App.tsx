import React, { useState, useEffect } from 'react';
import { 
  Sidebar, 
  ERPModule 
} from './components/layout/Sidebar';
import { Topbar } from './components/layout/Topbar';
import { GlobalSearchModal } from './components/layout/GlobalSearchModal';
import { NotificationCenter } from './components/layout/NotificationCenter';
import { DashboardOverview } from './components/dashboard/DashboardOverview';
import { InvoiceList } from './components/sales/InvoiceList';
import { InvoiceCreateModal } from './components/sales/InvoiceCreateModal';
import { QuotationList } from './components/sales/QuotationList';
import { CustomerList } from './components/customers/CustomerList';
import { ProductList } from './components/inventory/ProductList';
import { WarehouseList } from './components/inventory/WarehouseList';
import { PurchaseBillList } from './components/purchases/PurchaseBillList';
import { SupplierList } from './components/suppliers/SupplierList';
import { PaymentList } from './components/payments/PaymentList';
import { ExpenseList } from './components/expenses/ExpenseList';
import { AccountingHub } from './components/accounting/AccountingHub';
import { HrPayrollHub } from './components/hr/HrPayrollHub';
import { AssetList } from './components/assets/AssetList';
import { DocumentManager } from './components/documents/DocumentManager';
import { ReportsCenter } from './components/reports/ReportsCenter';
import { AuditLogViewer } from './components/audit/AuditLogViewer';
import { SystemSettings } from './components/settings/SystemSettings';
import { OnboardingWizard } from './components/company/OnboardingWizard';
import { db } from './lib/db';
import { Customer, Invoice, PurchaseBill } from './types/erp';
import { 
  LayoutDashboard, 
  FileText, 
  Package, 
  CreditCard, 
  Menu,
  Sparkles
} from 'lucide-react';

export default function App() {
  const [activeModule, setActiveModule] = useState<ERPModule>('dashboard');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isNewInvoiceOpen, setIsNewInvoiceOpen] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);

  // Sync state changes from db
  const [dbState, setDbState] = useState(db.getState());
  useEffect(() => {
    const unsub = db.subscribe(() => setDbState(db.getState()));
    return () => {
      unsub();
    };
  }, []);

  const handleScanResult = (code: string) => {
    // If user scans a barcode, navigate to products and search
    setActiveModule('products');
  };

  const handleSelectCustomerForInvoice = (cust: Customer) => {
    setIsNewInvoiceOpen(true);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-100 font-sans text-slate-900 antialiased dark:bg-slate-950 dark:text-slate-100">
      {/* 1. Left Nav Sidebar (Desktop & Tablet Drawer) */}
      <Sidebar
        activeModule={activeModule}
        setActiveModule={setActiveModule}
        isCollapsed={isSidebarCollapsed}
        setIsCollapsed={setIsSidebarCollapsed}
        mobileOpen={isMobileMenuOpen}
        setMobileOpen={setIsMobileMenuOpen}
      />

      {/* 2. Main Content Frame */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Topbar */}
        <Topbar
          onOpenSearch={() => setIsSearchOpen(true)}
          onOpenNotifications={() => setIsNotificationsOpen(true)}
          onNewInvoice={() => setIsNewInvoiceOpen(true)}
          onScanResult={handleScanResult}
          activeModule={activeModule}
          setActiveModule={(m) => setActiveModule(m as ERPModule)}
        />

        {/* Scrollable Viewport */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 pb-20 lg:pb-8">
          {activeModule === 'dashboard' && (
            <DashboardOverview
              onNavigate={(m) => setActiveModule(m)}
              onNewInvoice={() => setIsNewInvoiceOpen(true)}
            />
          )}

          {activeModule === 'invoices' && (
            <InvoiceList
              onOpenCreate={() => setIsNewInvoiceOpen(true)}
              onRecordPaymentForInvoice={(inv) => {
                setActiveModule('payments');
              }}
            />
          )}

          {activeModule === 'quotations' && <QuotationList />}

          {activeModule === 'customers' && (
            <CustomerList
              onSelectCustomerForInvoice={handleSelectCustomerForInvoice}
            />
          )}

          {activeModule === 'products' && <ProductList />}

          {activeModule === 'warehouses' && <WarehouseList />}

          {activeModule === 'purchases' && (
            <PurchaseBillList
              onRecordPaymentForBill={(bill) => {
                setActiveModule('payments');
              }}
            />
          )}

          {activeModule === 'suppliers' && <SupplierList />}

          {activeModule === 'payments' && <PaymentList />}

          {activeModule === 'expenses' && <ExpenseList />}

          {activeModule === 'accounting' && <AccountingHub />}

          {activeModule === 'hr' && <HrPayrollHub />}

          {activeModule === 'assets' && <AssetList />}

          {activeModule === 'documents' && <DocumentManager />}

          {activeModule === 'reports' && <ReportsCenter />}

          {activeModule === 'audit' && <AuditLogViewer />}

          {activeModule === 'settings' && <SystemSettings />}
        </main>

        {/* Mobile / Android APK Navigation Bar */}
        <div className="fixed bottom-0 left-0 right-0 z-30 flex h-14 items-center justify-around border-t border-slate-200 bg-white/95 px-2 backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/95 lg:hidden">
          <button
            onClick={() => setActiveModule('dashboard')}
            className={`flex flex-col items-center gap-0.5 text-[10px] font-medium ${
              activeModule === 'dashboard' ? 'text-indigo-600 dark:text-indigo-400 font-bold' : 'text-slate-500'
            }`}
          >
            <LayoutDashboard className="h-4 w-4" />
            <span>Home</span>
          </button>

          <button
            onClick={() => setActiveModule('invoices')}
            className={`flex flex-col items-center gap-0.5 text-[10px] font-medium ${
              activeModule === 'invoices' ? 'text-indigo-600 dark:text-indigo-400 font-bold' : 'text-slate-500'
            }`}
          >
            <FileText className="h-4 w-4" />
            <span>Sales</span>
          </button>

          <button
            onClick={() => setIsNewInvoiceOpen(true)}
            className="flex -mt-5 h-11 w-11 items-center justify-center rounded-full bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 active:scale-95"
          >
            <span className="text-xl font-bold">+</span>
          </button>

          <button
            onClick={() => setActiveModule('products')}
            className={`flex flex-col items-center gap-0.5 text-[10px] font-medium ${
              activeModule === 'products' ? 'text-indigo-600 dark:text-indigo-400 font-bold' : 'text-slate-500'
            }`}
          >
            <Package className="h-4 w-4" />
            <span>Stock</span>
          </button>

          <button
            onClick={() => setIsMobileMenuOpen(true)}
            className="flex flex-col items-center gap-0.5 text-[10px] font-medium text-slate-500"
          >
            <Menu className="h-4 w-4" />
            <span>More</span>
          </button>
        </div>
      </div>

      {/* Global Search Modal (Ctrl + K) */}
      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onNavigate={(mod) => setActiveModule(mod)}
      />

      {/* Notification Center */}
      <NotificationCenter
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        onNavigate={(mod) => setActiveModule(mod as ERPModule)}
      />

      {/* New Invoice Creation Modal */}
      <InvoiceCreateModal
        isOpen={isNewInvoiceOpen}
        onClose={() => setIsNewInvoiceOpen(false)}
        onSuccess={(inv) => {
          setActiveModule('invoices');
        }}
      />

      {/* First-time Onboarding Wizard (if triggered) */}
      {showOnboarding && (
        <OnboardingWizard onComplete={() => setShowOnboarding(false)} />
      )}
    </div>
  );
}
