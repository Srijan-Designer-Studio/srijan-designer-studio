/**
 * ApexERP Enterprise - Core Type Definitions
 * Fully typed schema mapping for PostgreSQL / Supabase
 */

export type RoleName = 
  | 'Super Admin'
  | 'Company Admin'
  | 'Manager'
  | 'Accountant'
  | 'Sales Executive'
  | 'Purchase Manager'
  | 'Inventory Manager'
  | 'Employee'
  | 'Viewer';

export interface Company {
  id: string;
  name: string;
  legal_name?: string;
  logo_url?: string;
  email: string;
  phone: string;
  website?: string;
  address_line1: string;
  address_line2?: string;
  city: string;
  state: string;
  state_code: string;
  pincode: string;
  country: string;
  gstin?: string;
  pan?: string;
  cin?: string;
  currency: string;
  currency_symbol: string;
  financial_year_start: string;
  financial_year_end: string;
  invoice_prefix: string;
  quote_prefix: string;
  so_prefix: string;
  po_prefix: string;
  bill_prefix: string;
  bank_name?: string;
  bank_account_no?: string;
  bank_ifsc?: string;
  bank_branch?: string;
  upi_id?: string;
  created_at?: string;
}

export interface AppUser {
  id: string;
  company_id: string;
  name: string;
  email: string;
  phone?: string;
  role_name: RoleName;
  status: 'Active' | 'Inactive';
  avatar_url?: string;
}

export interface Warehouse {
  id: string;
  company_id: string;
  name: string;
  code: string;
  address?: string;
  city?: string;
  state?: string;
  manager_name?: string;
  contact_phone?: string;
  is_primary: boolean;
  is_active: boolean;
}

export interface ProductCategory {
  id: string;
  company_id: string;
  name: string;
  code?: string;
  description?: string;
}

export interface Product {
  id: string;
  company_id: string;
  category_id?: string;
  category_name?: string;
  sku: string;
  name: string;
  brand?: string;
  unit: string;
  hsn_sac: string;
  barcode?: string;
  purchase_price: number;
  selling_price: number;
  mrp?: number;
  tax_rate: number; // 0, 5, 12, 18, 28
  is_tax_inclusive: boolean;
  min_stock_alert: number;
  max_stock: number;
  current_stock: number;
  image_url?: string;
  description?: string;
  status: 'Active' | 'Discontinued';
}

export interface StockMovement {
  id: string;
  company_id: string;
  product_id: string;
  product_name: string;
  warehouse_id: string;
  warehouse_name: string;
  movement_type: 'IN' | 'OUT' | 'TRANSFER' | 'ADJUSTMENT' | 'DAMAGE' | 'RETURN';
  quantity: number;
  reference_type: string;
  reference_id: string;
  notes?: string;
  created_at: string;
}

export interface Customer {
  id: string;
  company_id: string;
  customer_code: string;
  name: string;
  business_name?: string;
  email?: string;
  phone: string;
  gstin?: string;
  pan?: string;
  customer_type: 'B2B' | 'B2C';
  billing_address: string;
  billing_city: string;
  billing_state: string;
  billing_pincode: string;
  credit_limit: number;
  credit_days: number;
  opening_balance: number;
  current_balance: number;
  notes?: string;
  created_at?: string;
}

export interface Supplier {
  id: string;
  company_id: string;
  supplier_code: string;
  name: string;
  company_name: string;
  email?: string;
  phone: string;
  gstin?: string;
  pan?: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  bank_name?: string;
  bank_account_no?: string;
  bank_ifsc?: string;
  credit_terms: string;
  opening_balance: number;
  current_balance: number;
  notes?: string;
}

export interface QuotationItem {
  id: string;
  product_id?: string;
  product_name: string;
  hsn_sac: string;
  quantity: number;
  rate: number;
  discount_percent: number;
  tax_percent: number;
  tax_amount: number;
  total: number;
}

export interface Quotation {
  id: string;
  company_id: string;
  customer_id: string;
  customer_name: string;
  quotation_number: string;
  quotation_date: string;
  valid_until: string;
  items: QuotationItem[];
  subtotal: number;
  discount_amount: number;
  taxable_amount: number;
  cgst: number;
  sgst: number;
  igst: number;
  round_off: number;
  grand_total: number;
  status: 'Draft' | 'Sent' | 'Accepted' | 'Converted' | 'Expired';
  terms_conditions?: string;
}

export interface InvoiceItem {
  id: string;
  product_id?: string;
  product_name: string;
  hsn_sac: string;
  quantity: number;
  unit: string;
  rate: number;
  discount_percent: number;
  taxable_amount: number;
  tax_percent: number;
  tax_amount: number;
  total: number;
}

export interface Invoice {
  id: string;
  company_id: string;
  customer_id: string;
  customer_name: string;
  customer_gstin?: string;
  customer_phone?: string;
  customer_address?: string;
  customer_state?: string;
  sales_order_id?: string;
  warehouse_id?: string;
  invoice_number: string;
  invoice_date: string;
  due_date: string;
  is_igst: boolean;
  items: InvoiceItem[];
  subtotal: number;
  discount_amount: number;
  taxable_amount: number;
  cgst: number;
  sgst: number;
  igst: number;
  round_off: number;
  grand_total: number;
  paid_amount: number;
  balance_amount: number;
  payment_status: 'Unpaid' | 'Partially Paid' | 'Paid' | 'Overdue';
  payment_mode?: string;
  e_invoice_irn?: string;
  e_way_bill_no?: string;
  notes?: string;
  terms_conditions?: string;
  created_at?: string;
}

export interface PurchaseOrderItem {
  id: string;
  product_id?: string;
  product_name: string;
  hsn_sac: string;
  quantity: number;
  rate: number;
  tax_percent: number;
  tax_amount: number;
  total: number;
}

export interface PurchaseOrder {
  id: string;
  company_id: string;
  supplier_id: string;
  supplier_name: string;
  po_number: string;
  po_date: string;
  expected_delivery?: string;
  items: PurchaseOrderItem[];
  grand_total: number;
  status: 'Draft' | 'Ordered' | 'Partially Received' | 'Received' | 'Cancelled';
}

export interface PurchaseBillItem {
  id: string;
  product_id?: string;
  product_name: string;
  hsn_sac: string;
  quantity: number;
  rate: number;
  taxable_amount: number;
  tax_percent: number;
  tax_amount: number;
  total: number;
}

export interface PurchaseBill {
  id: string;
  company_id: string;
  supplier_id: string;
  supplier_name: string;
  supplier_gstin?: string;
  supplier_invoice_no?: string;
  bill_number: string;
  bill_date: string;
  due_date: string;
  is_igst: boolean;
  warehouse_id?: string;
  items: PurchaseBillItem[];
  taxable_amount: number;
  cgst: number;
  sgst: number;
  igst: number;
  round_off: number;
  grand_total: number;
  paid_amount: number;
  balance_amount: number;
  payment_status: 'Unpaid' | 'Partially Paid' | 'Paid';
  created_at?: string;
}

export interface Payment {
  id: string;
  company_id: string;
  payment_number: string;
  payment_type: 'RECEIVED' | 'PAID';
  party_type: 'Customer' | 'Supplier';
  party_id: string;
  party_name: string;
  invoice_id?: string;
  purchase_bill_id?: string;
  payment_date: string;
  amount: number;
  payment_mode: 'Cash' | 'Bank Transfer' | 'UPI' | 'Cheque' | 'Card';
  reference_no?: string;
  bank_account?: string;
  notes?: string;
  created_at?: string;
}

export interface Expense {
  id: string;
  company_id: string;
  category_id?: string;
  category_name: string;
  expense_number: string;
  expense_date: string;
  amount: number;
  payment_mode: string;
  vendor?: string;
  description: string;
  status: 'Approved' | 'Pending' | 'Rejected';
  receipt_url?: string;
}

export interface ChartOfAccount {
  id: string;
  company_id: string;
  account_code: string;
  account_name: string;
  account_type: 'Asset' | 'Liability' | 'Equity' | 'Revenue' | 'Expense';
  sub_type: string;
  current_balance: number;
  is_active: boolean;
}

export interface JournalEntryLine {
  account_id: string;
  account_name: string;
  debit: number;
  credit: number;
  narration?: string;
}

export interface JournalEntry {
  id: string;
  company_id: string;
  entry_number: string;
  entry_date: string;
  reference_type: string;
  reference_id?: string;
  description: string;
  lines: JournalEntryLine[];
  total_debit: number;
  total_credit: number;
  created_at?: string;
}

export interface Employee {
  id: string;
  company_id: string;
  employee_code: string;
  name: string;
  email: string;
  phone: string;
  department: string;
  designation: string;
  joining_date: string;
  pan?: string;
  aadhar?: string;
  bank_account_no?: string;
  bank_ifsc?: string;
  basic_salary: number;
  hra: number;
  special_allowance: number;
  pf_opted: boolean;
  esi_opted: boolean;
  status: 'Active' | 'On Leave' | 'Resigned' | 'Terminated';
}

export interface AttendanceRecord {
  id: string;
  company_id: string;
  employee_id: string;
  employee_name: string;
  attendance_date: string;
  status: 'Present' | 'Absent' | 'Half Day' | 'Leave' | 'Holiday' | 'WFH';
  check_in_time?: string;
  check_out_time?: string;
  notes?: string;
}

export interface PayrollRecord {
  id: string;
  company_id: string;
  employee_id: string;
  employee_name: string;
  month_year: string;
  working_days: number;
  present_days: number;
  basic_pay: number;
  hra: number;
  allowances: number;
  bonus: number;
  pf_deduction: number;
  esi_deduction: number;
  professional_tax: number;
  tds_deduction: number;
  net_salary: number;
  payment_status: 'Draft' | 'Approved' | 'Paid';
  paid_date?: string;
  created_at?: string;
}

export interface FixedAsset {
  id: string;
  company_id: string;
  asset_code: string;
  name: string;
  category: 'Computers' | 'Vehicles' | 'Furniture' | 'Machinery' | 'Office Equipment';
  purchase_date: string;
  purchase_cost: number;
  assigned_employee_name?: string;
  location?: string;
  warranty_expiry?: string;
  depreciation_rate: number;
  current_value: number;
  status: 'In Use' | 'Under Repair' | 'Scrapped' | 'Sold';
}

export interface ErpDocument {
  id: string;
  company_id: string;
  title: string;
  file_name: string;
  file_url: string;
  file_type: string;
  file_size_kb: number;
  category: string;
  reference_type?: string;
  reference_id?: string;
  uploaded_by?: string;
  created_at: string;
}

export interface NotificationItem {
  id: string;
  company_id: string;
  title: string;
  message: string;
  type: 'INFO' | 'WARNING' | 'ALERT' | 'SUCCESS';
  link?: string;
  is_read: boolean;
  created_at: string;
}

export interface AuditLog {
  id: string;
  company_id: string;
  user_email: string;
  action: string;
  module: string;
  record_id?: string;
  details: string;
  created_at: string;
}
