/**
 * ApexERP - Enterprise Core Database & Transaction Engine
 * Manages Multi-Company Data, Supabase Sync, Atomic Financial/Inventory Operations,
 * Offline Storage, and Double-Entry Accounting Ledger.
 */

import {
  Company,
  AppUser,
  Warehouse,
  ProductCategory,
  Product,
  StockMovement,
  Customer,
  Supplier,
  Quotation,
  Invoice,
  PurchaseOrder,
  PurchaseBill,
  Payment,
  Expense,
  ChartOfAccount,
  JournalEntry,
  Employee,
  AttendanceRecord,
  PayrollRecord,
  FixedAsset,
  ErpDocument,
  NotificationItem,
  AuditLog,
} from '../types/erp';
import { generateAutomatedJournalEntry } from './accountingEngine';
import { supabase, isSupabaseConfigured } from './supabase';

const STORAGE_KEY = 'apex_erp_enterprise_db_v1';

export interface ERPDatabaseState {
  companies: Company[];
  currentCompanyId: string;
  currentUser: AppUser;
  warehouses: Warehouse[];
  categories: ProductCategory[];
  products: Product[];
  stockMovements: StockMovement[];
  customers: Customer[];
  suppliers: Supplier[];
  quotations: Quotation[];
  invoices: Invoice[];
  purchaseOrders: PurchaseOrder[];
  purchaseBills: PurchaseBill[];
  payments: Payment[];
  expenses: Expense[];
  accounts: ChartOfAccount[];
  journalEntries: JournalEntry[];
  employees: Employee[];
  attendance: AttendanceRecord[];
  payroll: PayrollRecord[];
  assets: FixedAsset[];
  documents: ErpDocument[];
  notifications: NotificationItem[];
  auditLogs: AuditLog[];
}

const INITIAL_COMPANY: Company = {
  id: 'comp-01',
  name: 'Apex Global Enterprises Pvt Ltd',
  legal_name: 'Apex Global Enterprises Private Limited',
  email: 'finance@apexglobal.in',
  phone: '+91 98300 12345',
  website: 'https://apexglobal.in',
  address_line1: 'Sector V, Salt Lake Electronics Complex',
  address_line2: 'Block EP & GP, Tech Hub 4th Floor',
  city: 'Kolkata',
  state: 'West Bengal',
  state_code: '19',
  pincode: '700091',
  country: 'India',
  gstin: '19AAACA1234F1Z8',
  pan: 'AAACA1234F',
  cin: 'U72200WB2020PTC234567',
  currency: 'INR',
  currency_symbol: '₹',
  financial_year_start: '2026-04-01',
  financial_year_end: '2027-03-31',
  invoice_prefix: 'INV-2627-',
  quote_prefix: 'QTN-2627-',
  so_prefix: 'SO-2627-',
  po_prefix: 'PO-2627-',
  bill_prefix: 'BILL-2627-',
  bank_name: 'HDFC Bank',
  bank_account_no: '50200012345678',
  bank_ifsc: 'HDFC0000123',
  bank_branch: 'Salt Lake Sector V',
  upi_id: 'apexglobal@hdfcbank',
};

const INITIAL_USER: AppUser = {
  id: 'user-01',
  company_id: 'comp-01',
  name: 'Ripan Pramanik',
  email: 'admin@apexerp.com',
  phone: '+91 98000 11223',
  role_name: 'Super Admin',
  status: 'Active',
};

const INITIAL_WAREHOUSES: Warehouse[] = [
  {
    id: 'wh-01',
    company_id: 'comp-01',
    name: 'Central Tech Depot (Kolkata)',
    code: 'WH-KOL-01',
    address: 'Salt Lake Sector V Logistics Wing',
    city: 'Kolkata',
    state: 'West Bengal',
    manager_name: 'Subhash Roy',
    contact_phone: '+91 98311 22334',
    is_primary: true,
    is_active: true,
  },
  {
    id: 'wh-02',
    company_id: 'comp-01',
    name: 'Western Hub (Mumbai)',
    code: 'WH-MUM-02',
    address: 'MIDC Industrial Area, Andheri East',
    city: 'Mumbai',
    state: 'Maharashtra',
    manager_name: 'Amit Joshi',
    contact_phone: '+91 98200 44556',
    is_primary: false,
    is_active: true,
  },
];

const INITIAL_CATEGORIES: ProductCategory[] = [
  { id: 'cat-01', company_id: 'comp-01', name: 'Computer Hardware', code: 'HW', description: 'Servers, Laptops, Desktops' },
  { id: 'cat-02', company_id: 'comp-01', name: 'Networking Equipment', code: 'NET', description: 'Routers, Switches, Fiber cables' },
  { id: 'cat-03', company_id: 'comp-01', name: 'Enterprise Software', code: 'SFT', description: 'Licenses, Cloud solutions' },
  { id: 'cat-04', company_id: 'comp-01', name: 'Office Peripherals', code: 'ACC', description: 'Printers, Scanners, UPS' },
];

const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-01',
    company_id: 'comp-01',
    category_id: 'cat-01',
    category_name: 'Computer Hardware',
    sku: 'DELL-OPT-7090',
    name: 'Dell OptiPlex 7090 Micro Desktop',
    brand: 'Dell',
    unit: 'Pcs',
    hsn_sac: '8471',
    barcode: '8901030928412',
    purchase_price: 52000,
    selling_price: 68500,
    mrp: 74999,
    tax_rate: 18,
    is_tax_inclusive: false,
    min_stock_alert: 5,
    max_stock: 50,
    current_stock: 24,
    description: 'Intel Core i7 11th Gen, 16GB DDR4, 512GB NVMe SSD, Win 11 Pro',
    status: 'Active',
  },
  {
    id: 'prod-02',
    company_id: 'comp-01',
    category_id: 'cat-02',
    category_name: 'Networking Equipment',
    sku: 'CISCO-CAT-C1000',
    name: 'Cisco Catalyst 1000 24-Port Gigabit Switch',
    brand: 'Cisco',
    unit: 'Pcs',
    hsn_sac: '8517',
    barcode: '8901030928429',
    purchase_price: 38000,
    selling_price: 49500,
    mrp: 55000,
    tax_rate: 18,
    is_tax_inclusive: false,
    min_stock_alert: 3,
    max_stock: 25,
    current_stock: 12,
    description: 'Managed 24 Port Gigabit Ethernet Switch with 4x 1G SFP uplinks',
    status: 'Active',
  },
  {
    id: 'prod-03',
    company_id: 'comp-01',
    category_id: 'cat-04',
    category_name: 'Office Peripherals',
    sku: 'HP-LSR-MFP436',
    name: 'HP LaserJet MFP Multi-Function Laser Printer',
    brand: 'HP',
    unit: 'Pcs',
    hsn_sac: '8443',
    barcode: '8901030928436',
    purchase_price: 28500,
    selling_price: 36900,
    mrp: 41000,
    tax_rate: 18,
    is_tax_inclusive: false,
    min_stock_alert: 2,
    max_stock: 15,
    current_stock: 4,
    description: 'A3 Multifunction Laser Printer (Print, Scan, Copy) with network LAN',
    status: 'Active',
  },
  {
    id: 'prod-04',
    company_id: 'comp-01',
    category_id: 'cat-04',
    category_name: 'Office Peripherals',
    sku: 'APC-UPS-1KVA',
    name: 'APC Smart-UPS 1000VA LCD 230V',
    brand: 'APC Schneider',
    unit: 'Pcs',
    hsn_sac: '8504',
    barcode: '8901030928443',
    purchase_price: 19500,
    selling_price: 24800,
    mrp: 27900,
    tax_rate: 18,
    is_tax_inclusive: false,
    min_stock_alert: 6,
    max_stock: 30,
    current_stock: 2, // Low stock triggers notification
    description: 'Intelligent and efficient network power protection from entry level',
    status: 'Active',
  },
];

const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: 'cust-01',
    company_id: 'comp-01',
    customer_code: 'CUST-001',
    name: 'Tata Consultancy Systems Corp',
    business_name: 'TCS Infotech Ltd',
    email: 'vendor.procure@tcs-corp.in',
    phone: '+91 98301 99887',
    gstin: '19AABCT1332L1ZF',
    pan: 'AABCT1332L',
    customer_type: 'B2B',
    billing_address: 'TCS Gitobitan, Salt Lake Sector V',
    billing_city: 'Kolkata',
    billing_state: 'West Bengal',
    billing_pincode: '700091',
    credit_limit: 500000,
    credit_days: 30,
    opening_balance: 0,
    current_balance: 68500,
  },
  {
    id: 'cust-02',
    company_id: 'comp-01',
    customer_code: 'CUST-002',
    name: 'Reliance Digital Services',
    business_name: 'Reliance Retail Ventures Ltd',
    email: 'accounts@relianceretail.com',
    phone: '+91 98222 33445',
    gstin: '27AABCR0001P1Z0', // Inter-state Maharashtra
    pan: 'AABCR0001P',
    customer_type: 'B2B',
    billing_address: 'Maker Chambers IV, Nariman Point',
    billing_city: 'Mumbai',
    billing_state: 'Maharashtra',
    billing_pincode: '400021',
    credit_limit: 1000000,
    credit_days: 45,
    opening_balance: 0,
    current_balance: 147500,
  },
];

const INITIAL_SUPPLIERS: Supplier[] = [
  {
    id: 'supp-01',
    company_id: 'comp-01',
    supplier_code: 'SUPP-001',
    name: 'Redington India Distributors',
    company_name: 'Redington India Ltd',
    email: 'orders@redington.in',
    phone: '+91 44 4224 3353',
    gstin: '33AABCR1234D1ZU',
    pan: 'AABCR1234D',
    address: 'SPL Guindy House, Mount Road',
    city: 'Chennai',
    state: 'Tamil Nadu',
    pincode: '600032',
    bank_name: 'ICICI Bank Ltd',
    bank_account_no: '000405012345',
    bank_ifsc: 'ICIC0000004',
    credit_terms: 'Net 30',
    opening_balance: 0,
    current_balance: 82000,
  },
  {
    id: 'supp-02',
    company_id: 'comp-01',
    supplier_code: 'SUPP-002',
    name: 'Ingram Micro Tech Wholesale',
    company_name: 'Ingram Micro India Pvt Ltd',
    email: 'procurement@ingrammicro.co.in',
    phone: '+91 22 6788 1200',
    gstin: '27AABCI5678E1ZW',
    pan: 'AABCI5678E',
    address: 'Godrej Coliseum, Somaiya Hospital Road, Sion',
    city: 'Mumbai',
    state: 'Maharashtra',
    pincode: '400022',
    bank_name: 'Citibank N.A.',
    bank_account_no: '0340050012',
    bank_ifsc: 'CITI0000002',
    credit_terms: 'Net 45',
    opening_balance: 0,
    current_balance: 45000,
  },
];

const INITIAL_CHART_OF_ACCOUNTS: ChartOfAccount[] = [
  { id: 'acc-bank-01', company_id: 'comp-01', account_code: '1010', account_name: 'Main Business Bank Account (HDFC)', account_type: 'Asset', sub_type: 'Bank', current_balance: 485200, is_active: true },
  { id: 'acc-cash-01', company_id: 'comp-01', account_code: '1020', account_name: 'Petty Cash', account_type: 'Asset', sub_type: 'Cash', current_balance: 24500, is_active: true },
  { id: 'acc-ar-01', company_id: 'comp-01', account_code: '1100', account_name: 'Accounts Receivable (Debtors)', account_type: 'Asset', sub_type: 'Current Asset', current_balance: 216000, is_active: true },
  { id: 'acc-inv-01', company_id: 'comp-01', account_code: '1200', account_name: 'Inventory / Purchase Stock', account_type: 'Asset', sub_type: 'Inventory', current_balance: 1850000, is_active: true },
  { id: 'acc-tax-input', company_id: 'comp-01', account_code: '1310', account_name: 'GST Input Tax Credit (ITC)', account_type: 'Asset', sub_type: 'Tax Credit', current_balance: 42800, is_active: true },
  { id: 'acc-ap-01', company_id: 'comp-01', account_code: '2100', account_name: 'Accounts Payable (Creditors)', account_type: 'Liability', sub_type: 'Current Liability', current_balance: 127000, is_active: true },
  { id: 'acc-tax-output', company_id: 'comp-01', account_code: '2210', account_name: 'GST Output Tax Payable', account_type: 'Liability', sub_type: 'Tax Liability', current_balance: 38880, is_active: true },
  { id: 'acc-eq-capital', company_id: 'comp-01', account_code: '3010', account_name: 'Owner Capital / Equity', account_type: 'Equity', sub_type: 'Equity', current_balance: 2000000, is_active: true },
  { id: 'acc-rev-01', company_id: 'comp-01', account_code: '4010', account_name: 'Sales Revenue', account_type: 'Revenue', sub_type: 'Operating Revenue', current_balance: 842000, is_active: true },
  { id: 'acc-exp-sal', company_id: 'comp-01', account_code: '5010', account_name: 'Salaries & Wages Expense', account_type: 'Expense', sub_type: 'Operating Expense', current_balance: 215000, is_active: true },
  { id: 'acc-exp-rent', company_id: 'comp-01', account_code: '5020', account_name: 'Office Rent & Maintenance', account_type: 'Expense', sub_type: 'Administrative Expense', current_balance: 65000, is_active: true },
  { id: 'acc-exp-gen', company_id: 'comp-01', account_code: '5030', account_name: 'General Operational Expenses', account_type: 'Expense', sub_type: 'General Expense', current_balance: 32400, is_active: true },
];

const INITIAL_EMPLOYEES: Employee[] = [
  {
    id: 'emp-01',
    company_id: 'comp-01',
    employee_code: 'EMP-001',
    name: 'Ananya Sengupta',
    email: 'ananya.s@apexglobal.in',
    phone: '+91 98305 66778',
    department: 'Sales & Accounts',
    designation: 'Senior Account Manager',
    joining_date: '2023-01-15',
    pan: 'BCVPS1234K',
    bank_account_no: '918020012345',
    bank_ifsc: 'UTIB0000005',
    basic_salary: 45000,
    hra: 18000,
    special_allowance: 7000,
    pf_opted: true,
    esi_opted: false,
    status: 'Active',
  },
  {
    id: 'emp-02',
    company_id: 'comp-01',
    employee_code: 'EMP-002',
    name: 'Rajesh Sharma',
    email: 'rajesh.sharma@apexglobal.in',
    phone: '+91 98308 99112',
    department: 'Logistics & Warehouse',
    designation: 'Inventory Coordinator',
    joining_date: '2023-08-01',
    pan: 'AYZPS4567M',
    bank_account_no: '001201509876',
    bank_ifsc: 'SBIN0001234',
    basic_salary: 28000,
    hra: 11200,
    special_allowance: 4800,
    pf_opted: true,
    esi_opted: false,
    status: 'Active',
  },
];

const INITIAL_INVOICES: Invoice[] = [
  {
    id: 'inv-01',
    company_id: 'comp-01',
    customer_id: 'cust-01',
    customer_name: 'Tata Consultancy Systems Corp',
    customer_gstin: '19AABCT1332L1ZF',
    customer_phone: '+91 98301 99887',
    customer_address: 'TCS Gitobitan, Salt Lake Sector V, Kolkata, WB 700091',
    customer_state: 'West Bengal',
    invoice_number: 'INV-2627-001',
    invoice_date: '2026-10-01',
    due_date: '2026-10-31',
    is_igst: false,
    items: [
      {
        id: 'item-01',
        product_id: 'prod-01',
        product_name: 'Dell OptiPlex 7090 Micro Desktop',
        hsn_sac: '8471',
        quantity: 1,
        unit: 'Pcs',
        rate: 68500,
        discount_percent: 0,
        taxable_amount: 68500,
        tax_percent: 18,
        tax_amount: 12330,
        total: 80830,
      }
    ],
    subtotal: 68500,
    discount_amount: 0,
    taxable_amount: 68500,
    cgst: 6165,
    sgst: 6165,
    igst: 0,
    round_off: 0,
    grand_total: 80830,
    paid_amount: 0,
    balance_amount: 80830,
    payment_status: 'Unpaid',
    notes: 'Payment due within 30 days. Thank you for your business.',
    terms_conditions: 'Standard manufacturer warranty applicable. Subject to Kolkata jurisdiction.',
    created_at: new Date('2026-10-01').toISOString(),
  }
];

class ERPDatabaseManager {
  private state: ERPDatabaseState;
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.state = this.loadState();
  }

  private loadState(): ERPDatabaseState {
    if (typeof window === 'undefined') {
      return this.getDefaultState();
    }
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn('Failed to parse stored ERP database state, initializing clean slate:', e);
    }
    return this.getDefaultState();
  }

  private getDefaultState(): ERPDatabaseState {
    return {
      companies: [INITIAL_COMPANY],
      currentCompanyId: 'comp-01',
      currentUser: INITIAL_USER,
      warehouses: INITIAL_WAREHOUSES,
      categories: INITIAL_CATEGORIES,
      products: INITIAL_PRODUCTS,
      stockMovements: [],
      customers: INITIAL_CUSTOMERS,
      suppliers: INITIAL_SUPPLIERS,
      quotations: [],
      invoices: INITIAL_INVOICES,
      purchaseOrders: [],
      purchaseBills: [],
      payments: [],
      expenses: [
        {
          id: 'exp-01',
          company_id: 'comp-01',
          category_name: 'Rent & Utilities',
          expense_number: 'EXP-001',
          expense_date: '2026-10-02',
          amount: 35000,
          payment_mode: 'Bank Transfer',
          vendor: 'Tech Park Realty Ltd',
          description: 'Office floor maintenance and high-speed internet lease',
          status: 'Approved',
        }
      ],
      accounts: INITIAL_CHART_OF_ACCOUNTS,
      journalEntries: [],
      employees: INITIAL_EMPLOYEES,
      attendance: [
        {
          id: 'att-01',
          company_id: 'comp-01',
          employee_id: 'emp-01',
          employee_name: 'Ananya Sengupta',
          attendance_date: '2026-10-03',
          status: 'Present',
          check_in_time: '09:15',
          notes: 'On-time biometric login',
        },
        {
          id: 'att-02',
          company_id: 'comp-01',
          employee_id: 'emp-02',
          employee_name: 'Rajesh Sharma',
          attendance_date: '2026-10-03',
          status: 'Present',
          check_in_time: '08:50',
          notes: 'Warehouse opening shift',
        }
      ],
      payroll: [],
      assets: [
        {
          id: 'ast-01',
          company_id: 'comp-01',
          asset_code: 'AST-KOL-001',
          name: 'Dell PowerEdge R750 Server',
          category: 'Computers',
          purchase_date: '2025-05-10',
          purchase_cost: 380000,
          assigned_employee_name: 'Subhash Roy',
          location: 'Server Room Rack 01',
          warranty_expiry: '2028-05-10',
          depreciation_rate: 15,
          current_value: 323000,
          status: 'In Use',
        }
      ],
      documents: [
        {
          id: 'doc-01',
          company_id: 'comp-01',
          title: 'Certificate of Incorporation & GST Certificate',
          file_name: 'Apex_GST_Registration.pdf',
          file_url: '#',
          file_type: 'application/pdf',
          file_size_kb: 450,
          category: 'Compliance',
          uploaded_by: 'Admin',
          created_at: new Date('2026-04-01').toISOString(),
        }
      ],
      notifications: [
        {
          id: 'notif-01',
          company_id: 'comp-01',
          title: 'Low Stock Alert: APC Smart-UPS',
          message: 'Product APC-UPS-1KVA has reached 2 units. Minimum alert threshold is 6.',
          type: 'WARNING',
          link: 'inventory',
          is_read: false,
          created_at: new Date().toISOString(),
        }
      ],
      auditLogs: [
        {
          id: 'aud-01',
          company_id: 'comp-01',
          user_email: 'admin@apexerp.com',
          action: 'SYSTEM_INITIALIZED',
          module: 'Settings',
          details: 'Company Apex Global Enterprises Pvt Ltd created with GSTIN 19AAACA1234F1Z8',
          created_at: new Date().toISOString(),
        }
      ],
    };
  }

  private saveState() {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
      } catch (e) {
        console.error('Failed to persist ERP state:', e);
      }
    }
    this.notify();
  }

  public subscribe(listener: () => void) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }

  // --- GETTERS ---
  public getState(): ERPDatabaseState {
    return this.state;
  }

  public getCurrentCompany(): Company {
    return this.state.companies.find((c) => c.id === this.state.currentCompanyId) || this.state.companies[0];
  }

  public switchCompany(companyId: string) {
    if (this.state.companies.some((c) => c.id === companyId)) {
      this.state.currentCompanyId = companyId;
      this.saveState();
    }
  }

  public addCompany(company: Omit<Company, 'id'>): Company {
    const newCompany: Company = {
      ...company,
      id: `comp-${Date.now()}`,
      created_at: new Date().toISOString(),
    };
    this.state.companies.push(newCompany);
    this.state.currentCompanyId = newCompany.id;
    this.recordAudit('COMPANY_CREATED', 'Company', newCompany.id, `Created company ${newCompany.name}`);
    this.saveState();
    return newCompany;
  }

  public updateCompany(updated: Company) {
    this.state.companies = this.state.companies.map((c) => (c.id === updated.id ? updated : c));
    this.recordAudit('COMPANY_UPDATED', 'Company', updated.id, `Updated company profile ${updated.name}`);
    this.saveState();
  }

  // --- AUDIT LOGGING ---
  public recordAudit(action: string, module: string, record_id: string, details: string) {
    const log: AuditLog = {
      id: `aud-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      company_id: this.state.currentCompanyId,
      user_email: this.state.currentUser.email,
      action,
      module,
      record_id,
      details,
      created_at: new Date().toISOString(),
    };
    this.state.auditLogs.unshift(log);
  }

  // --- NOTIFICATIONS ---
  public addNotification(title: string, message: string, type: 'INFO' | 'WARNING' | 'ALERT' | 'SUCCESS', link?: string) {
    const notif: NotificationItem = {
      id: `notif-${Date.now()}`,
      company_id: this.state.currentCompanyId,
      title,
      message,
      type,
      link,
      is_read: false,
      created_at: new Date().toISOString(),
    };
    this.state.notifications.unshift(notif);
    this.saveState();
  }

  public markNotificationAsRead(id: string) {
    this.state.notifications = this.state.notifications.map((n) => (n.id === id ? { ...n, is_read: true } : n));
    this.saveState();
  }

  public markAllNotificationsAsRead() {
    this.state.notifications = this.state.notifications.map((n) => ({ ...n, is_read: true }));
    this.saveState();
  }

  // --- CUSTOMERS ---
  public addCustomer(data: Omit<Customer, 'id' | 'company_id'>): Customer {
    const cust: Customer = {
      ...data,
      id: `cust-${Date.now()}`,
      company_id: this.state.currentCompanyId,
      created_at: new Date().toISOString(),
    };
    this.state.customers.push(cust);
    this.recordAudit('CUSTOMER_CREATED', 'Customer', cust.id, `Added customer ${cust.name}`);
    this.saveState();

    if (isSupabaseConfigured && supabase) {
      supabase.from('customers').insert([cust]).then(({ error }) => {
        if (error) console.error('Supabase customer sync error:', error);
      });
    }
    return cust;
  }

  public updateCustomer(cust: Customer) {
    this.state.customers = this.state.customers.map((c) => (c.id === cust.id ? cust : c));
    this.recordAudit('CUSTOMER_UPDATED', 'Customer', cust.id, `Updated customer ${cust.name}`);
    this.saveState();
  }

  // --- SUPPLIERS ---
  public addSupplier(data: Omit<Supplier, 'id' | 'company_id'>): Supplier {
    const supp: Supplier = {
      ...data,
      id: `supp-${Date.now()}`,
      company_id: this.state.currentCompanyId,
    };
    this.state.suppliers.push(supp);
    this.recordAudit('SUPPLIER_CREATED', 'Supplier', supp.id, `Added supplier ${supp.name}`);
    this.saveState();
    return supp;
  }

  public updateSupplier(supp: Supplier) {
    this.state.suppliers = this.state.suppliers.map((s) => (s.id === supp.id ? supp : s));
    this.recordAudit('SUPPLIER_UPDATED', 'Supplier', supp.id, `Updated supplier ${supp.name}`);
    this.saveState();
  }

  // --- PRODUCTS & INVENTORY ---
  public addProduct(data: Omit<Product, 'id' | 'company_id'>): Product {
    const prod: Product = {
      ...data,
      id: `prod-${Date.now()}`,
      company_id: this.state.currentCompanyId,
    };
    this.state.products.push(prod);
    this.recordAudit('PRODUCT_CREATED', 'Product', prod.id, `Added product ${prod.name} (${prod.sku})`);
    this.saveState();
    return prod;
  }

  public updateProduct(prod: Product) {
    this.state.products = this.state.products.map((p) => (p.id === prod.id ? prod : p));
    this.recordAudit('PRODUCT_UPDATED', 'Product', prod.id, `Updated product ${prod.name}`);
    this.saveState();
  }

  public adjustProductStock(productId: string, quantityDelta: number, reason: string, warehouseId?: string) {
    const prod = this.state.products.find((p) => p.id === productId);
    if (!prod) return;

    const oldStock = prod.current_stock;
    prod.current_stock = Math.max(0, prod.current_stock + quantityDelta);

    const warehouse = this.state.warehouses.find((w) => w.id === warehouseId) || this.state.warehouses[0];

    const movement: StockMovement = {
      id: `mov-${Date.now()}`,
      company_id: this.state.currentCompanyId,
      product_id: prod.id,
      product_name: prod.name,
      warehouse_id: warehouse.id,
      warehouse_name: warehouse.name,
      movement_type: quantityDelta >= 0 ? 'IN' : 'OUT',
      quantity: Math.abs(quantityDelta),
      reference_type: 'MANUAL_ADJUSTMENT',
      reference_id: `ADJ-${Date.now()}`,
      notes: reason,
      created_at: new Date().toISOString(),
    };
    this.state.stockMovements.unshift(movement);

    if (prod.current_stock <= prod.min_stock_alert) {
      this.addNotification(
        `Low Stock: ${prod.name}`,
        `Stock is currently ${prod.current_stock} ${prod.unit}. Min alert is ${prod.min_stock_alert}.`,
        'WARNING',
        'inventory'
      );
    }

    this.recordAudit('STOCK_ADJUSTED', 'Inventory', prod.id, `Adjusted stock from ${oldStock} to ${prod.current_stock} (${reason})`);
    this.saveState();
  }

  // --- WAREHOUSES ---
  public addWarehouse(data: Omit<Warehouse, 'id' | 'company_id'>): Warehouse {
    const wh: Warehouse = {
      ...data,
      id: `wh-${Date.now()}`,
      company_id: this.state.currentCompanyId,
    };
    this.state.warehouses.push(wh);
    this.recordAudit('WAREHOUSE_CREATED', 'Warehouse', wh.id, `Created warehouse ${wh.name}`);
    this.saveState();
    return wh;
  }

  // --- ATOMIC SALES INVOICE CREATION ---
  /**
   * ATOMIC TRANSACTION:
   * 1. Save Invoice
   * 2. Decrement Inventory & Create Stock Movement for each item
   * 3. Update Customer Outstanding Balance
   * 4. Generate Balanced Double-Entry Accounting Journal Entry
   * 5. Record Immutable Audit Log
   */
  public createInvoice(invoiceData: Omit<Invoice, 'id' | 'company_id' | 'created_at'>): Invoice {
    const company = this.getCurrentCompany();
    const newInvoice: Invoice = {
      ...invoiceData,
      id: `inv-${Date.now()}`,
      company_id: company.id,
      created_at: new Date().toISOString(),
    };

    // 1. Save Invoice
    this.state.invoices.unshift(newInvoice);

    // 2. Decrement Inventory & Log Movements
    newInvoice.items.forEach((item) => {
      if (item.product_id) {
        const prod = this.state.products.find((p) => p.id === item.product_id);
        if (prod) {
          prod.current_stock = Math.max(0, prod.current_stock - item.quantity);
          this.state.stockMovements.unshift({
            id: `mov-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
            company_id: company.id,
            product_id: prod.id,
            product_name: prod.name,
            warehouse_id: newInvoice.warehouse_id || this.state.warehouses[0]?.id || 'wh-01',
            warehouse_name: this.state.warehouses[0]?.name || 'Primary Warehouse',
            movement_type: 'OUT',
            quantity: item.quantity,
            reference_type: 'INVOICE',
            reference_id: newInvoice.invoice_number,
            notes: `Dispatched for Invoice ${newInvoice.invoice_number}`,
            created_at: new Date().toISOString(),
          });

          if (prod.current_stock <= prod.min_stock_alert) {
            this.addNotification(
              `Low Stock Alert: ${prod.name}`,
              `Stock is at ${prod.current_stock} ${prod.unit} after invoice ${newInvoice.invoice_number}`,
              'ALERT',
              'inventory'
            );
          }
        }
      }
    });

    // 3. Update Customer Outstanding Balance
    const customer = this.state.customers.find((c) => c.id === newInvoice.customer_id);
    if (customer) {
      customer.current_balance += newInvoice.balance_amount;
    }

    // 4. Generate Automated Journal Entry
    const totalTax = (newInvoice.cgst || 0) + (newInvoice.sgst || 0) + (newInvoice.igst || 0);
    const je = generateAutomatedJournalEntry({
      companyId: company.id,
      entryType: 'INVOICE',
      referenceId: newInvoice.id,
      referenceNumber: newInvoice.invoice_number,
      date: newInvoice.invoice_date,
      description: `Sales Invoice to ${newInvoice.customer_name}`,
      amount: newInvoice.grand_total,
      taxableAmount: newInvoice.taxable_amount,
      taxAmount: totalTax,
    });
    this.state.journalEntries.unshift(je);

    // 5. Update Chart of Accounts balances
    const arAcc = this.state.accounts.find((a) => a.id === 'acc-ar-01');
    if (arAcc) arAcc.current_balance += newInvoice.grand_total;

    const revAcc = this.state.accounts.find((a) => a.id === 'acc-rev-01');
    if (revAcc) revAcc.current_balance += newInvoice.taxable_amount;

    const taxAcc = this.state.accounts.find((a) => a.id === 'acc-tax-output');
    if (taxAcc) taxAcc.current_balance += totalTax;

    // 6. Audit Log
    this.recordAudit(
      'INVOICE_CREATED',
      'Sales',
      newInvoice.id,
      `Generated Invoice ${newInvoice.invoice_number} for ₹${newInvoice.grand_total.toLocaleString('en-IN')}`
    );

    this.saveState();
    return newInvoice;
  }

  // --- ATOMIC PURCHASE BILL CREATION ---
  /**
   * ATOMIC TRANSACTION:
   * 1. Save Bill
   * 2. Increment Inventory & Log Movements
   * 3. Update Supplier Outstanding Payable
   * 4. Create Balanced Double Entry Journal Entry
   * 5. Record Audit Log
   */
  public createPurchaseBill(billData: Omit<PurchaseBill, 'id' | 'company_id' | 'created_at'>): PurchaseBill {
    const company = this.getCurrentCompany();
    const newBill: PurchaseBill = {
      ...billData,
      id: `bill-${Date.now()}`,
      company_id: company.id,
      created_at: new Date().toISOString(),
    };

    // 1. Save Bill
    this.state.purchaseBills.unshift(newBill);

    // 2. Increment Stock & Movements
    newBill.items.forEach((item) => {
      if (item.product_id) {
        const prod = this.state.products.find((p) => p.id === item.product_id);
        if (prod) {
          prod.current_stock += item.quantity;
          this.state.stockMovements.unshift({
            id: `mov-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
            company_id: company.id,
            product_id: prod.id,
            product_name: prod.name,
            warehouse_id: newBill.warehouse_id || this.state.warehouses[0]?.id || 'wh-01',
            warehouse_name: this.state.warehouses[0]?.name || 'Primary Warehouse',
            movement_type: 'IN',
            quantity: item.quantity,
            reference_type: 'PURCHASE_BILL',
            reference_id: newBill.bill_number,
            notes: `Stock Received from Purchase Bill ${newBill.bill_number}`,
            created_at: new Date().toISOString(),
          });
        }
      }
    });

    // 3. Update Supplier Outstanding
    const supp = this.state.suppliers.find((s) => s.id === newBill.supplier_id);
    if (supp) {
      supp.current_balance += newBill.balance_amount;
    }

    // 4. Generate Journal Entry
    const totalTax = (newBill.cgst || 0) + (newBill.sgst || 0) + (newBill.igst || 0);
    const je = generateAutomatedJournalEntry({
      companyId: company.id,
      entryType: 'PURCHASE_BILL',
      referenceId: newBill.id,
      referenceNumber: newBill.bill_number,
      date: newBill.bill_date,
      description: `Purchase Bill from ${newBill.supplier_name}`,
      amount: newBill.grand_total,
      taxableAmount: newBill.taxable_amount,
      taxAmount: totalTax,
    });
    this.state.journalEntries.unshift(je);

    // 5. Update Chart of Accounts
    const apAcc = this.state.accounts.find((a) => a.id === 'acc-ap-01');
    if (apAcc) apAcc.current_balance += newBill.grand_total;

    const itcAcc = this.state.accounts.find((a) => a.id === 'acc-tax-input');
    if (itcAcc) itcAcc.current_balance += totalTax;

    this.recordAudit(
      'PURCHASE_BILL_CREATED',
      'Purchases',
      newBill.id,
      `Recorded Purchase Bill ${newBill.bill_number} for ₹${newBill.grand_total.toLocaleString('en-IN')}`
    );

    this.saveState();
    return newBill;
  }

  // --- ATOMIC PAYMENTS ---
  public recordPayment(paymentData: Omit<Payment, 'id' | 'company_id' | 'created_at'>): Payment {
    const company = this.getCurrentCompany();
    const newPayment: Payment = {
      ...paymentData,
      id: `pay-${Date.now()}`,
      company_id: company.id,
      created_at: new Date().toISOString(),
    };

    this.state.payments.unshift(newPayment);

    // If customer payment
    if (newPayment.payment_type === 'RECEIVED' && newPayment.party_type === 'Customer') {
      const cust = this.state.customers.find((c) => c.id === newPayment.party_id);
      if (cust) {
        cust.current_balance = Math.max(0, cust.current_balance - newPayment.amount);
      }
      if (newPayment.invoice_id) {
        const inv = this.state.invoices.find((i) => i.id === newPayment.invoice_id);
        if (inv) {
          inv.paid_amount += newPayment.amount;
          inv.balance_amount = Math.max(0, inv.grand_total - inv.paid_amount);
          inv.payment_status = inv.balance_amount === 0 ? 'Paid' : 'Partially Paid';
        }
      }

      // Accounting
      const je = generateAutomatedJournalEntry({
        companyId: company.id,
        entryType: 'PAYMENT_RECEIVED',
        referenceId: newPayment.id,
        referenceNumber: newPayment.payment_number,
        date: newPayment.payment_date,
        description: `Customer Receipt from ${newPayment.party_name}`,
        amount: newPayment.amount,
      });
      this.state.journalEntries.unshift(je);

      const bankAcc = this.state.accounts.find((a) => a.id === 'acc-bank-01');
      if (bankAcc) bankAcc.current_balance += newPayment.amount;
      const arAcc = this.state.accounts.find((a) => a.id === 'acc-ar-01');
      if (arAcc) arAcc.current_balance = Math.max(0, arAcc.current_balance - newPayment.amount);
    }

    // If supplier payout
    if (newPayment.payment_type === 'PAID' && newPayment.party_type === 'Supplier') {
      const supp = this.state.suppliers.find((s) => s.id === newPayment.party_id);
      if (supp) {
        supp.current_balance = Math.max(0, supp.current_balance - newPayment.amount);
      }
      if (newPayment.purchase_bill_id) {
        const bill = this.state.purchaseBills.find((b) => b.id === newPayment.purchase_bill_id);
        if (bill) {
          bill.paid_amount += newPayment.amount;
          bill.balance_amount = Math.max(0, bill.grand_total - bill.paid_amount);
          bill.payment_status = bill.balance_amount === 0 ? 'Paid' : 'Partially Paid';
        }
      }

      // Accounting
      const je = generateAutomatedJournalEntry({
        companyId: company.id,
        entryType: 'PAYMENT_PAID',
        referenceId: newPayment.id,
        referenceNumber: newPayment.payment_number,
        date: newPayment.payment_date,
        description: `Supplier Payout to ${newPayment.party_name}`,
        amount: newPayment.amount,
      });
      this.state.journalEntries.unshift(je);

      const bankAcc = this.state.accounts.find((a) => a.id === 'acc-bank-01');
      if (bankAcc) bankAcc.current_balance = Math.max(0, bankAcc.current_balance - newPayment.amount);
      const apAcc = this.state.accounts.find((a) => a.id === 'acc-ap-01');
      if (apAcc) apAcc.current_balance = Math.max(0, apAcc.current_balance - newPayment.amount);
    }

    this.recordAudit(
      'PAYMENT_RECORDED',
      'Payments',
      newPayment.id,
      `Recorded ${newPayment.payment_type} of ₹${newPayment.amount.toLocaleString('en-IN')} for ${newPayment.party_name}`
    );

    this.saveState();
    return newPayment;
  }

  // --- EXPENSES ---
  public addExpense(expenseData: Omit<Expense, 'id' | 'company_id'>): Expense {
    const company = this.getCurrentCompany();
    const newExp: Expense = {
      ...expenseData,
      id: `exp-${Date.now()}`,
      company_id: company.id,
    };
    this.state.expenses.unshift(newExp);

    if (newExp.status === 'Approved') {
      const je = generateAutomatedJournalEntry({
        companyId: company.id,
        entryType: 'EXPENSE',
        referenceId: newExp.id,
        referenceNumber: newExp.expense_number,
        date: newExp.expense_date,
        description: `Expense: ${newExp.description} (${newExp.category_name})`,
        amount: newExp.amount,
      });
      this.state.journalEntries.unshift(je);

      const bankAcc = this.state.accounts.find((a) => a.id === 'acc-bank-01');
      if (bankAcc) bankAcc.current_balance = Math.max(0, bankAcc.current_balance - newExp.amount);
    }

    this.recordAudit('EXPENSE_CREATED', 'Expenses', newExp.id, `Logged expense ₹${newExp.amount} for ${newExp.category_name}`);
    this.saveState();
    return newExp;
  }

  // --- EMPLOYEES & PAYROLL ---
  public addEmployee(data: Omit<Employee, 'id' | 'company_id'>): Employee {
    const emp: Employee = {
      ...data,
      id: `emp-${Date.now()}`,
      company_id: this.state.currentCompanyId,
    };
    this.state.employees.push(emp);
    this.recordAudit('EMPLOYEE_ADDED', 'HR', emp.id, `Onboarded employee ${emp.name} (${emp.employee_code})`);
    this.saveState();
    return emp;
  }

  public recordAttendance(record: Omit<AttendanceRecord, 'id' | 'company_id'>) {
    const existingIndex = this.state.attendance.findIndex(
      (a) => a.employee_id === record.employee_id && a.attendance_date === record.attendance_date
    );
    if (existingIndex >= 0) {
      this.state.attendance[existingIndex] = {
        ...this.state.attendance[existingIndex],
        ...record,
      };
    } else {
      this.state.attendance.unshift({
        ...record,
        id: `att-${Date.now()}`,
        company_id: this.state.currentCompanyId,
      });
    }
    this.saveState();
  }

  public processPayroll(payrollData: Omit<PayrollRecord, 'id' | 'company_id' | 'created_at'>): PayrollRecord {
    const company = this.getCurrentCompany();
    const record: PayrollRecord = {
      ...payrollData,
      id: `pr-${Date.now()}`,
      company_id: company.id,
      created_at: new Date().toISOString(),
    };
    this.state.payroll.unshift(record);

    if (record.payment_status === 'Paid') {
      const je = generateAutomatedJournalEntry({
        companyId: company.id,
        entryType: 'PAYROLL',
        referenceId: record.id,
        referenceNumber: `PR-${record.month_year.replace(/\s+/g, '')}`,
        date: new Date().toISOString().split('T')[0],
        description: `Salary disbursement for ${record.employee_name} (${record.month_year})`,
        amount: record.net_salary,
      });
      this.state.journalEntries.unshift(je);
    }

    this.recordAudit('PAYROLL_PROCESSED', 'HR', record.id, `Generated payroll for ${record.employee_name} Net: ₹${record.net_salary}`);
    this.saveState();
    return record;
  }

  // --- ASSETS ---
  public addAsset(data: Omit<FixedAsset, 'id' | 'company_id'>): FixedAsset {
    const asset: FixedAsset = {
      ...data,
      id: `ast-${Date.now()}`,
      company_id: this.state.currentCompanyId,
    };
    this.state.assets.push(asset);
    this.recordAudit('ASSET_ADDED', 'Assets', asset.id, `Registered asset ${asset.name} (${asset.asset_code})`);
    this.saveState();
    return asset;
  }

  // --- RESET DEMO DATA ---
  public resetToFreshDatabase() {
    this.state = this.getDefaultState();
    this.saveState();
  }
}

export const db = new ERPDatabaseManager();
