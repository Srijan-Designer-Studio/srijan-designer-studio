/**
 * ApexERP - Supabase Client Bridge
 * Connects to live Supabase PostgreSQL backend when credentials exist,
 * with graceful fallback to local enterprise database engine.
 */

import { createClient, SupabaseClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const isSupabaseConfigured = Boolean(
  supabaseUrl && 
  supabaseUrl.startsWith('http') && 
  !supabaseUrl.includes('your-project') &&
  supabaseAnonKey && 
  supabaseAnonKey.length > 20
);

export let supabase: SupabaseClient | null = null;

if (isSupabaseConfigured) {
  try {
    supabase = createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    });
  } catch (err) {
    console.error('Failed to initialize Supabase client:', err);
    supabase = null;
  }
}

export async function testSupabaseConnection(url?: string, key?: string): Promise<{ success: boolean; message: string }> {
  const targetUrl = url || supabaseUrl;
  const targetKey = key || supabaseAnonKey;

  if (!targetUrl || !targetKey) {
    return { success: false, message: 'Supabase URL or Anon Key is missing.' };
  }

  try {
    const testClient = createClient(targetUrl, targetKey);
    const { error } = await testClient.from('companies').select('id').limit(1);
    if (error && error.code !== 'PGRST116') {
      return { success: false, message: error.message };
    }
    return { success: true, message: 'Successfully connected to Supabase PostgreSQL instance!' };
  } catch (error: any) {
    return { success: false, message: error?.message || 'Network error connecting to Supabase.' };
  }
}
