/**
 * ApexERP - Double Entry Accounting Engine
 * Enforces fundamental accounting equation: Assets = Liabilities + Equity
 * Automatically generates balanced journal entries for all operational events.
 */

import { JournalEntry, JournalEntryLine } from '../types/erp';

export interface AccountingTransactionInput {
  companyId: string;
  entryType: 'INVOICE' | 'PAYMENT_RECEIVED' | 'PURCHASE_BILL' | 'PAYMENT_PAID' | 'EXPENSE' | 'PAYROLL';
  referenceId: string;
  referenceNumber: string;
  date: string;
  description: string;
  amount: number;
  taxableAmount?: number;
  taxAmount?: number;
  accountMapping?: {
    bankOrCashAccountId?: string;
    expenseAccountId?: string;
  };
}

export function generateAutomatedJournalEntry(input: AccountingTransactionInput): JournalEntry {
  const lines: JournalEntryLine[] = [];
  const entryNumber = `JE-${Date.now().toString().slice(-6)}`;

  switch (input.entryType) {
    case 'INVOICE': {
      // Dr. Accounts Receivable (Asset)
      lines.push({
        account_id: 'acc-ar-01',
        account_name: 'Accounts Receivable (Debtors)',
        debit: input.amount,
        credit: 0,
        narration: `Sales Invoice ${input.referenceNumber}`,
      });
      // Cr. Sales Revenue (Revenue)
      const salesRev = input.taxableAmount || (input.amount - (input.taxAmount || 0));
      lines.push({
        account_id: 'acc-rev-01',
        account_name: 'Sales Revenue',
        debit: 0,
        credit: Number(salesRev.toFixed(2)),
        narration: `Revenue from Invoice ${input.referenceNumber}`,
      });
      // Cr. GST Output Tax Payable (Liability)
      if (input.taxAmount && input.taxAmount > 0) {
        lines.push({
          account_id: 'acc-tax-output',
          account_name: 'GST Output Tax Payable',
          debit: 0,
          credit: Number(input.taxAmount.toFixed(2)),
          narration: `GST collected on Invoice ${input.referenceNumber}`,
        });
      }
      break;
    }

    case 'PAYMENT_RECEIVED': {
      // Dr. Bank / Cash (Asset)
      lines.push({
        account_id: input.accountMapping?.bankOrCashAccountId || 'acc-bank-01',
        account_name: 'Main Business Bank Account',
        debit: input.amount,
        credit: 0,
        narration: `Payment received ref ${input.referenceNumber}`,
      });
      // Cr. Accounts Receivable (Asset)
      lines.push({
        account_id: 'acc-ar-01',
        account_name: 'Accounts Receivable (Debtors)',
        debit: 0,
        credit: input.amount,
        narration: `Cleared receivable via ${input.referenceNumber}`,
      });
      break;
    }

    case 'PURCHASE_BILL': {
      // Dr. Inventory / Purchase Expense
      const purchaseAmount = input.taxableAmount || (input.amount - (input.taxAmount || 0));
      lines.push({
        account_id: 'acc-inv-01',
        account_name: 'Inventory / Purchase Account',
        debit: Number(purchaseAmount.toFixed(2)),
        credit: 0,
        narration: `Purchase from bill ${input.referenceNumber}`,
      });
      // Dr. GST Input Tax Credit (Asset)
      if (input.taxAmount && input.taxAmount > 0) {
        lines.push({
          account_id: 'acc-tax-input',
          account_name: 'GST Input Tax Credit (ITC)',
          debit: Number(input.taxAmount.toFixed(2)),
          credit: 0,
          narration: `ITC claimed on bill ${input.referenceNumber}`,
        });
      }
      // Cr. Accounts Payable (Liability)
      lines.push({
        account_id: 'acc-ap-01',
        account_name: 'Accounts Payable (Creditors)',
        debit: 0,
        credit: input.amount,
        narration: `Payable liability for bill ${input.referenceNumber}`,
      });
      break;
    }

    case 'PAYMENT_PAID': {
      // Dr. Accounts Payable (Liability)
      lines.push({
        account_id: 'acc-ap-01',
        account_name: 'Accounts Payable (Creditors)',
        debit: input.amount,
        credit: 0,
        narration: `Supplier payout ref ${input.referenceNumber}`,
      });
      // Cr. Bank / Cash (Asset)
      lines.push({
        account_id: input.accountMapping?.bankOrCashAccountId || 'acc-bank-01',
        account_name: 'Main Business Bank Account',
        debit: 0,
        credit: input.amount,
        narration: `Disbursement for ${input.referenceNumber}`,
      });
      break;
    }

    case 'EXPENSE': {
      // Dr. Expense Account
      lines.push({
        account_id: input.accountMapping?.expenseAccountId || 'acc-exp-gen',
        account_name: 'General Operational Expenses',
        debit: input.amount,
        credit: 0,
        narration: input.description,
      });
      // Cr. Bank / Cash (Asset)
      lines.push({
        account_id: input.accountMapping?.bankOrCashAccountId || 'acc-bank-01',
        account_name: 'Main Business Bank Account',
        debit: 0,
        credit: input.amount,
        narration: `Expense payout ref ${input.referenceNumber}`,
      });
      break;
    }

    case 'PAYROLL': {
      // Dr. Salary & Wage Expense
      lines.push({
        account_id: 'acc-exp-sal',
        account_name: 'Salaries & Wages Expense',
        debit: input.amount,
        credit: 0,
        narration: `Payroll disbursement ${input.referenceNumber}`,
      });
      // Cr. Bank / Cash (Asset)
      lines.push({
        account_id: input.accountMapping?.bankOrCashAccountId || 'acc-bank-01',
        account_name: 'Main Business Bank Account',
        debit: 0,
        credit: input.amount,
        narration: `Salary payout ${input.referenceNumber}`,
      });
      break;
    }
  }

  const totalDebit = lines.reduce((acc, curr) => acc + curr.debit, 0);
  const totalCredit = lines.reduce((acc, curr) => acc + curr.credit, 0);

  return {
    id: `je-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    company_id: input.companyId,
    entry_number: entryNumber,
    entry_date: input.date,
    reference_type: input.entryType,
    reference_id: input.referenceId,
    description: input.description,
    lines,
    total_debit: Number(totalDebit.toFixed(2)),
    total_credit: Number(totalCredit.toFixed(2)),
    created_at: new Date().toISOString(),
  };
}
