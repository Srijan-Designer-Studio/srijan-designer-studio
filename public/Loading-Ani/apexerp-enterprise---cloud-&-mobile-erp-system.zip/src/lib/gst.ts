/**
 * ApexERP - India GST & Tax Calculation Engine
 * Complies with GST Act 2017 (CGST, SGST, IGST calculations)
 */

export interface TaxCalculationResult {
  taxableAmount: number;
  cgst: number;
  sgst: number;
  igst: number;
  totalTax: number;
  subtotal: number;
  roundOff: number;
  grandTotal: number;
  isInterState: boolean;
}

/**
 * Calculates GST based on source state (Company) and destination state (Customer/Supplier)
 */
export function calculateGstBreakdown({
  amount,
  taxRatePercent,
  isTaxInclusive = false,
  companyStateCode,
  partyStateCode,
  discountPercent = 0,
}: {
  amount: number;
  taxRatePercent: number;
  isTaxInclusive?: boolean;
  companyStateCode?: string;
  partyStateCode?: string;
  discountPercent?: number;
}): TaxCalculationResult {
  const isInterState = 
    Boolean(companyStateCode && partyStateCode && companyStateCode.trim().toLowerCase() !== partyStateCode.trim().toLowerCase());

  let basePrice = amount;
  if (discountPercent > 0) {
    basePrice = basePrice - (basePrice * (discountPercent / 100));
  }

  let taxable = basePrice;
  let totalTax = 0;

  if (isTaxInclusive) {
    // Reverse calculation: Taxable = Total / (1 + Rate / 100)
    taxable = basePrice / (1 + (taxRatePercent / 100));
    totalTax = basePrice - taxable;
  } else {
    taxable = basePrice;
    totalTax = taxable * (taxRatePercent / 100);
  }

  let cgst = 0;
  let sgst = 0;
  let igst = 0;

  if (isInterState) {
    igst = totalTax;
  } else {
    cgst = totalTax / 2;
    sgst = totalTax / 2;
  }

  const rawGrandTotal = taxable + totalTax;
  const roundedGrandTotal = Math.round(rawGrandTotal);
  const roundOff = Number((roundedGrandTotal - rawGrandTotal).toFixed(2));

  return {
    taxableAmount: Number(taxable.toFixed(2)),
    cgst: Number(cgst.toFixed(2)),
    sgst: Number(sgst.toFixed(2)),
    igst: Number(igst.toFixed(2)),
    totalTax: Number(totalTax.toFixed(2)),
    subtotal: Number(basePrice.toFixed(2)),
    roundOff,
    grandTotal: roundedGrandTotal,
    isInterState,
  };
}

/**
 * Converts Indian Rupee amounts into words (e.g. ₹ 15,250 -> "Rupees Fifteen Thousand Two Hundred Fifty Only")
 */
export function amountInWords(num: number): string {
  const a = [
    '', 'One ', 'Two ', 'Three ', 'Four ', 'Five ', 'Six ', 'Seven ', 'Eight ', 'Nine ', 'Ten ',
    'Eleven ', 'Twelve ', 'Thirteen ', 'Fourteen ', 'Fifteen ', 'Sixteen ', 'Seventeen ', 'Eighteen ', 'Nineteen '
  ];
  const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  if ((num = Math.floor(num)) === 0) return 'Rupees Zero Only';

  const n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
  if (!n) return '';

  let str = '';
  str += Number(n[1]) !== 0 ? (a[Number(n[1])] || b[Number(n[1][0])] + ' ' + a[Number(n[1][1])]) + 'Crore ' : '';
  str += Number(n[2]) !== 0 ? (a[Number(n[2])] || b[Number(n[2][0])] + ' ' + a[Number(n[2][1])]) + 'Lakh ' : '';
  str += Number(n[3]) !== 0 ? (a[Number(n[3])] || b[Number(n[3][0])] + ' ' + a[Number(n[3][1])]) + 'Thousand ' : '';
  str += Number(n[4]) !== 0 ? (a[Number(n[4])] || b[Number(n[4][0])] + ' ' + a[Number(n[4][1])]) + 'Hundred ' : '';
  str += Number(n[5]) !== 0 ? ((str !== '') ? 'and ' : '') + (a[Number(n[5])] || b[Number(n[5][0])] + ' ' + a[Number(n[5][1])]) : '';

  return `Rupees ${str.trim()} Only`;
}

/**
 * Standard Indian State Code mapping for GST identification
 */
export const INDIAN_STATES = [
  { code: '01', name: 'Jammu & Kashmir' },
  { code: '02', name: 'Himachal Pradesh' },
  { code: '03', name: 'Punjab' },
  { code: '04', name: 'Chandigarh' },
  { code: '05', name: 'Uttarakhand' },
  { code: '06', name: 'Haryana' },
  { code: '07', name: 'Delhi' },
  { code: '08', name: 'Rajasthan' },
  { code: '09', name: 'Uttar Pradesh' },
  { code: '10', name: 'Bihar' },
  { code: '19', name: 'West Bengal' },
  { code: '21', name: 'Odisha' },
  { code: '24', name: 'Gujarat' },
  { code: '27', name: 'Maharashtra' },
  { code: '29', name: 'Karnataka' },
  { code: '32', name: 'Kerala' },
  { code: '33', name: 'Tamil Nadu' },
  { code: '36', name: 'Telangana' },
  { code: '37', name: 'Andhra Pradesh' },
];
