/**
 * ApexERP - Capacitor Android & Native Bridge
 * Bridges web ERP with Capacitor Android runtime (Camera, Barcode, PDF, Offline Sync)
 */

export interface BarcodeScanResult {
  hasContent: boolean;
  content: string;
  format?: string;
}

export const isNativeCapacitor = Boolean(
  typeof window !== 'undefined' && (window as any).Capacitor?.isNativePlatform?.()
);

/**
 * Trigger camera / barcode scanner
 * Uses Native Capacitor BarcodeScanner if available, or HTML5 Web Video Stream fallback
 */
export async function scanBarcodeOrQr(): Promise<BarcodeScanResult> {
  if (typeof window === 'undefined') {
    return { hasContent: false, content: '' };
  }

  // Check if Capacitor BarcodeScanner plugin exists
  const capacitor = (window as any).Capacitor;
  if (capacitor?.Plugins?.BarcodeScanner) {
    try {
      const status = await capacitor.Plugins.BarcodeScanner.checkPermission({ force: true });
      if (status.granted) {
        document.body.classList.add('barcode-scanner-active');
        const result = await capacitor.Plugins.BarcodeScanner.startScan();
        document.body.classList.remove('barcode-scanner-active');
        if (result.hasContent) {
          return { hasContent: true, content: result.content, format: result.format };
        }
      }
    } catch (err) {
      console.warn('Native barcode scan failed, falling back:', err);
    }
  }

  // Web camera / mock prompt fallback for interactive testing in browser
  return new Promise((resolve) => {
    const code = window.prompt('Scan Barcode / QR (or enter/simulate scanned product SKU/Barcode):', '8901030928412');
    if (code) {
      resolve({ hasContent: true, content: code.trim() });
    } else {
      resolve({ hasContent: false, content: '' });
    }
  });
}

/**
 * Android Haptic Feedback
 */
export function triggerHaptic(type: 'light' | 'medium' | 'heavy' = 'light') {
  if (typeof window !== 'undefined' && (window as any).Capacitor?.Plugins?.Haptics) {
    try {
      (window as any).Capacitor.Plugins.Haptics.impact({ style: type.toUpperCase() });
    } catch (e) {
      // Ignore
    }
  }
}
