-- ==============================================================================
-- APEX ERP ENTERPRISE - COMPREHENSIVE POSTGRESQL SCHEMA WITH RLS
-- Multi-Company, Multi-Warehouse, GST-Compliant Double Entry Accounting & ERP
-- ==============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. COMPANIES
CREATE TABLE IF NOT EXISTS companies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    legal_name VARCHAR(255),
    logo_url TEXT,
    email VARCHAR(255),
    phone VARCHAR(50),
    website VARCHAR(255),
    address_line1 TEXT,
    address_line2 TEXT,
    city VARCHAR(100),
    state VARCHAR(100) NOT NULL,
    state_code VARCHAR(10),
    pincode VARCHAR(20),
    country VARCHAR(100) DEFAULT 'India',
    gstin VARCHAR(50),
    pan VARCHAR(50),
    cin VARCHAR(50),
    currency VARCHAR(10) DEFAULT 'INR',
    currency_symbol VARCHAR(10) DEFAULT '₹',
    financial_year_start DATE DEFAULT '2026-04-01',
    financial_year_end DATE DEFAULT '2027-03-31',
    invoice_prefix VARCHAR(20) DEFAULT 'INV-',
    quote_prefix VARCHAR(20) DEFAULT 'QTN-',
    so_prefix VARCHAR(20) DEFAULT 'SO-',
    po_prefix VARCHAR(20) DEFAULT 'PO-',
    bill_prefix VARCHAR(20) DEFAULT 'BILL-',
    bank_name VARCHAR(150),
    bank_account_no VARCHAR(100),
    bank_ifsc VARCHAR(50),
    bank_branch VARCHAR(150),
    upi_id VARCHAR(100),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. USERS & ROLES
CREATE TABLE IF NOT EXISTS roles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    permissions JSONB NOT NULL DEFAULT '{}'::jsonb,
    is_system BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS app_users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    auth_user_id UUID, -- References auth.users(id) in Supabase
    company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
    role_id UUID REFERENCES roles(id),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(50),
    avatar_url TEXT,
    role_name VARCHAR(100) DEFAULT 'Employee',
    status VARCHAR(50) DEFAULT 'Active',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. AUDIT LOGS
CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
    user_id UUID REFERENCES app_users(id) ON DELETE SET NULL,
    user_email VARCHAR(255),
    action VARCHAR(100) NOT NULL,
    module VARCHAR(100) NOT NULL,
    record_id VARCHAR(100),
    old_data JSONB,
    new_data JSONB,
    ip_address VARCHAR(50),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. WAREHOUSES
CREATE TABLE IF NOT EXISTS warehouses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) NOT NULL,
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(100),
    manager_name VARCHAR(255),
    contact_phone VARCHAR(50),
    is_primary BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. PRODUCT CATEGORIES & UNITS
CREATE TABLE IF NOT EXISTS product_categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name VARCHAR(150) NOT NULL,
    code VARCHAR(50),
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS units (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name VARCHAR(50) NOT NULL, -- e.g. "Pcs", "Kg", "Box", "Meter"
    short_code VARCHAR(20) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. PRODUCTS & INVENTORY
CREATE TABLE IF NOT EXISTS products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    category_id UUID REFERENCES product_categories(id) ON DELETE SET NULL,
    sku VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    brand VARCHAR(150),
    unit VARCHAR(50) DEFAULT 'Pcs',
    hsn_sac VARCHAR(50),
    barcode VARCHAR(100),
    purchase_price NUMERIC(15,2) DEFAULT 0.00,
    selling_price NUMERIC(15,2) DEFAULT 0.00,
    mrp NUMERIC(15,2) DEFAULT 0.00,
    tax_rate NUMERIC(5,2) DEFAULT 18.00, -- GST %: 0, 5, 12, 18, 28
    is_tax_inclusive BOOLEAN DEFAULT false,
    min_stock_alert INTEGER DEFAULT 10,
    max_stock INTEGER DEFAULT 1000,
    current_stock INTEGER DEFAULT 0,
    image_url TEXT,
    description TEXT,
    status VARCHAR(50) DEFAULT 'Active',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS warehouse_stocks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    warehouse_id UUID NOT NULL REFERENCES warehouses(id) ON DELETE CASCADE,
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    quantity INTEGER DEFAULT 0,
    rack_location VARCHAR(50),
    batch_no VARCHAR(50),
    expiry_date DATE,
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(warehouse_id, product_id, batch_no)
);

CREATE TABLE IF NOT EXISTS stock_movements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    warehouse_id UUID NOT NULL REFERENCES warehouses(id) ON DELETE CASCADE,
    movement_type VARCHAR(50) NOT NULL, -- 'IN', 'OUT', 'TRANSFER', 'ADJUSTMENT', 'DAMAGE', 'RETURN'
    quantity INTEGER NOT NULL,
    reference_type VARCHAR(50), -- 'INVOICE', 'PURCHASE_BILL', 'MANUAL_ADJUSTMENT', 'TRANSFER'
    reference_id VARCHAR(100),
    notes TEXT,
    created_by UUID REFERENCES app_users(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. CUSTOMERS & SUPPLIERS
CREATE TABLE IF NOT EXISTS customers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    customer_code VARCHAR(50),
    name VARCHAR(255) NOT NULL,
    business_name VARCHAR(255),
    email VARCHAR(255),
    phone VARCHAR(50),
    gstin VARCHAR(50),
    pan VARCHAR(50),
    customer_type VARCHAR(50) DEFAULT 'B2B', -- 'B2B', 'B2C'
    billing_address TEXT,
    billing_city VARCHAR(100),
    billing_state VARCHAR(100),
    billing_pincode VARCHAR(20),
    shipping_address TEXT,
    shipping_city VARCHAR(100),
    shipping_state VARCHAR(100),
    shipping_pincode VARCHAR(20),
    credit_limit NUMERIC(15,2) DEFAULT 50000.00,
    credit_days INTEGER DEFAULT 30,
    opening_balance NUMERIC(15,2) DEFAULT 0.00,
    current_balance NUMERIC(15,2) DEFAULT 0.00,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS suppliers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    supplier_code VARCHAR(50),
    name VARCHAR(255) NOT NULL,
    company_name VARCHAR(255),
    email VARCHAR(255),
    phone VARCHAR(50),
    gstin VARCHAR(50),
    pan VARCHAR(50),
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(100),
    pincode VARCHAR(20),
    bank_name VARCHAR(150),
    bank_account_no VARCHAR(100),
    bank_ifsc VARCHAR(50),
    credit_terms VARCHAR(100) DEFAULT 'Net 30',
    opening_balance NUMERIC(15,2) DEFAULT 0.00,
    current_balance NUMERIC(15,2) DEFAULT 0.00,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. SALES PIPELINE (QUOTATIONS, SALES ORDERS, INVOICES)
CREATE TABLE IF NOT EXISTS quotations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
    quotation_number VARCHAR(100) NOT NULL,
    quotation_date DATE NOT NULL,
    valid_until DATE,
    subtotal NUMERIC(15,2) DEFAULT 0.00,
    discount_amount NUMERIC(15,2) DEFAULT 0.00,
    taxable_amount NUMERIC(15,2) DEFAULT 0.00,
    cgst NUMERIC(15,2) DEFAULT 0.00,
    sgst NUMERIC(15,2) DEFAULT 0.00,
    igst NUMERIC(15,2) DEFAULT 0.00,
    round_off NUMERIC(15,2) DEFAULT 0.00,
    grand_total NUMERIC(15,2) DEFAULT 0.00,
    status VARCHAR(50) DEFAULT 'Draft', -- 'Draft', 'Sent', 'Accepted', 'Converted', 'Expired'
    terms_conditions TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS quotation_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    quotation_id UUID NOT NULL REFERENCES quotations(id) ON DELETE CASCADE,
    product_id UUID REFERENCES products(id) ON DELETE SET NULL,
    product_name VARCHAR(255) NOT NULL,
    hsn_sac VARCHAR(50),
    quantity INTEGER NOT NULL,
    rate NUMERIC(15,2) NOT NULL,
    discount_percent NUMERIC(5,2) DEFAULT 0.00,
    tax_percent NUMERIC(5,2) DEFAULT 18.00,
    tax_amount NUMERIC(15,2) DEFAULT 0.00,
    total NUMERIC(15,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS sales_orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
    quotation_id UUID REFERENCES quotations(id) ON DELETE SET NULL,
    order_number VARCHAR(100) NOT NULL,
    order_date DATE NOT NULL,
    expected_delivery DATE,
    grand_total NUMERIC(15,2) DEFAULT 0.00,
    status VARCHAR(50) DEFAULT 'Confirmed', -- 'Confirmed', 'Processing', 'Delivered', 'Invoiced', 'Cancelled'
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS sales_order_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sales_order_id UUID NOT NULL REFERENCES sales_orders(id) ON DELETE CASCADE,
    product_id UUID REFERENCES products(id) ON DELETE SET NULL,
    product_name VARCHAR(255) NOT NULL,
    hsn_sac VARCHAR(50),
    quantity INTEGER NOT NULL,
    rate NUMERIC(15,2) NOT NULL,
    discount_percent NUMERIC(5,2) DEFAULT 0.00,
    tax_percent NUMERIC(5,2) DEFAULT 18.00,
    tax_amount NUMERIC(15,2) DEFAULT 0.00,
    total NUMERIC(15,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS invoices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
    sales_order_id UUID REFERENCES sales_orders(id) ON DELETE SET NULL,
    warehouse_id UUID REFERENCES warehouses(id) ON DELETE SET NULL,
    invoice_number VARCHAR(100) NOT NULL,
    invoice_date DATE NOT NULL,
    due_date DATE NOT NULL,
    is_igst BOOLEAN DEFAULT false,
    subtotal NUMERIC(15,2) DEFAULT 0.00,
    discount_amount NUMERIC(15,2) DEFAULT 0.00,
    taxable_amount NUMERIC(15,2) DEFAULT 0.00,
    cgst NUMERIC(15,2) DEFAULT 0.00,
    sgst NUMERIC(15,2) DEFAULT 0.00,
    igst NUMERIC(15,2) DEFAULT 0.00,
    round_off NUMERIC(15,2) DEFAULT 0.00,
    grand_total NUMERIC(15,2) DEFAULT 0.00,
    paid_amount NUMERIC(15,2) DEFAULT 0.00,
    balance_amount NUMERIC(15,2) DEFAULT 0.00,
    payment_status VARCHAR(50) DEFAULT 'Unpaid', -- 'Unpaid', 'Partially Paid', 'Paid', 'Overdue'
    payment_mode VARCHAR(50), -- 'Bank Transfer', 'UPI', 'Cash', 'Cheque', 'Card'
    e_invoice_irn VARCHAR(100),
    e_way_bill_no VARCHAR(100),
    notes TEXT,
    terms_conditions TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS invoice_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_id UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    product_id UUID REFERENCES products(id) ON DELETE SET NULL,
    product_name VARCHAR(255) NOT NULL,
    hsn_sac VARCHAR(50),
    quantity INTEGER NOT NULL,
    unit VARCHAR(50) DEFAULT 'Pcs',
    rate NUMERIC(15,2) NOT NULL,
    discount_percent NUMERIC(5,2) DEFAULT 0.00,
    taxable_amount NUMERIC(15,2) NOT NULL,
    tax_percent NUMERIC(5,2) DEFAULT 18.00,
    tax_amount NUMERIC(15,2) DEFAULT 0.00,
    total NUMERIC(15,2) NOT NULL
);

-- 9. PURCHASES PIPELINE (PURCHASE ORDERS, BILLS)
CREATE TABLE IF NOT EXISTS purchase_orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    supplier_id UUID NOT NULL REFERENCES suppliers(id) ON DELETE RESTRICT,
    po_number VARCHAR(100) NOT NULL,
    po_date DATE NOT NULL,
    expected_delivery DATE,
    grand_total NUMERIC(15,2) DEFAULT 0.00,
    status VARCHAR(50) DEFAULT 'Ordered', -- 'Draft', 'Ordered', 'Partially Received', 'Received', 'Cancelled'
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS purchase_order_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    purchase_order_id UUID NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
    product_id UUID REFERENCES products(id) ON DELETE SET NULL,
    product_name VARCHAR(255) NOT NULL,
    hsn_sac VARCHAR(50),
    quantity INTEGER NOT NULL,
    rate NUMERIC(15,2) NOT NULL,
    tax_percent NUMERIC(5,2) DEFAULT 18.00,
    tax_amount NUMERIC(15,2) DEFAULT 0.00,
    total NUMERIC(15,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS purchase_bills (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    supplier_id UUID NOT NULL REFERENCES suppliers(id) ON DELETE RESTRICT,
    purchase_order_id UUID REFERENCES purchase_orders(id) ON DELETE SET NULL,
    warehouse_id UUID REFERENCES warehouses(id) ON DELETE SET NULL,
    bill_number VARCHAR(100) NOT NULL,
    supplier_invoice_no VARCHAR(100),
    bill_date DATE NOT NULL,
    due_date DATE NOT NULL,
    is_igst BOOLEAN DEFAULT false,
    taxable_amount NUMERIC(15,2) DEFAULT 0.00,
    cgst NUMERIC(15,2) DEFAULT 0.00,
    sgst NUMERIC(15,2) DEFAULT 0.00,
    igst NUMERIC(15,2) DEFAULT 0.00,
    round_off NUMERIC(15,2) DEFAULT 0.00,
    grand_total NUMERIC(15,2) DEFAULT 0.00,
    paid_amount NUMERIC(15,2) DEFAULT 0.00,
    balance_amount NUMERIC(15,2) DEFAULT 0.00,
    payment_status VARCHAR(50) DEFAULT 'Unpaid',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS purchase_bill_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    purchase_bill_id UUID NOT NULL REFERENCES purchase_bills(id) ON DELETE CASCADE,
    product_id UUID REFERENCES products(id) ON DELETE SET NULL,
    product_name VARCHAR(255) NOT NULL,
    hsn_sac VARCHAR(50),
    quantity INTEGER NOT NULL,
    rate NUMERIC(15,2) NOT NULL,
    taxable_amount NUMERIC(15,2) NOT NULL,
    tax_percent NUMERIC(5,2) DEFAULT 18.00,
    tax_amount NUMERIC(15,2) DEFAULT 0.00,
    total NUMERIC(15,2) NOT NULL
);

-- 10. PAYMENTS (CUSTOMER RECEIPT & SUPPLIER PAYOUT)
CREATE TABLE IF NOT EXISTS payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    payment_number VARCHAR(100) NOT NULL,
    payment_type VARCHAR(50) NOT NULL, -- 'RECEIVED' (Customer), 'PAID' (Supplier)
    party_type VARCHAR(50) NOT NULL, -- 'Customer', 'Supplier'
    party_id UUID NOT NULL,
    party_name VARCHAR(255) NOT NULL,
    invoice_id UUID REFERENCES invoices(id) ON DELETE SET NULL,
    purchase_bill_id UUID REFERENCES purchase_bills(id) ON DELETE SET NULL,
    payment_date DATE NOT NULL,
    amount NUMERIC(15,2) NOT NULL,
    payment_mode VARCHAR(50) NOT NULL, -- 'Cash', 'Bank Transfer', 'UPI', 'Cheque', 'Card'
    reference_no VARCHAR(100), -- Transaction ID, Cheque No, UTR
    bank_account VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. EXPENSES
CREATE TABLE IF NOT EXISTS expense_categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS expenses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    category_id UUID REFERENCES expense_categories(id) ON DELETE SET NULL,
    category_name VARCHAR(150),
    expense_number VARCHAR(100) NOT NULL,
    expense_date DATE NOT NULL,
    amount NUMERIC(15,2) NOT NULL,
    payment_mode VARCHAR(50) DEFAULT 'Bank Transfer',
    vendor VARCHAR(255),
    description TEXT,
    receipt_url TEXT,
    status VARCHAR(50) DEFAULT 'Approved', -- 'Pending', 'Approved', 'Rejected'
    created_by UUID REFERENCES app_users(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 12. DOUBLE-ENTRY ACCOUNTING (CHART OF ACCOUNTS & GENERAL LEDGER)
CREATE TABLE IF NOT EXISTS chart_of_accounts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    account_code VARCHAR(50) NOT NULL,
    account_name VARCHAR(255) NOT NULL,
    account_type VARCHAR(50) NOT NULL, -- 'Asset', 'Liability', 'Equity', 'Revenue', 'Expense'
    sub_type VARCHAR(100), -- 'Current Asset', 'Fixed Asset', 'Accounts Receivable', etc.
    opening_balance NUMERIC(15,2) DEFAULT 0.00,
    current_balance NUMERIC(15,2) DEFAULT 0.00,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS journal_entries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    entry_number VARCHAR(100) NOT NULL,
    entry_date DATE NOT NULL,
    reference_type VARCHAR(50), -- 'INVOICE', 'PAYMENT', 'PURCHASE_BILL', 'EXPENSE', 'MANUAL', 'PAYROLL'
    reference_id VARCHAR(100),
    description TEXT,
    total_debit NUMERIC(15,2) NOT NULL,
    total_credit NUMERIC(15,2) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS journal_entry_lines (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    journal_entry_id UUID NOT NULL REFERENCES journal_entries(id) ON DELETE CASCADE,
    account_id UUID NOT NULL REFERENCES chart_of_accounts(id) ON DELETE RESTRICT,
    account_name VARCHAR(255) NOT NULL,
    debit NUMERIC(15,2) DEFAULT 0.00,
    credit NUMERIC(15,2) DEFAULT 0.00,
    narration TEXT
);

-- 13. HR, EMPLOYEES, ATTENDANCE & PAYROLL
CREATE TABLE IF NOT EXISTS departments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name VARCHAR(150) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS employees (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    department_id UUID REFERENCES departments(id) ON DELETE SET NULL,
    employee_code VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(50),
    designation VARCHAR(150),
    joining_date DATE NOT NULL,
    pan VARCHAR(50),
    aadhar VARCHAR(50),
    bank_account_no VARCHAR(100),
    bank_ifsc VARCHAR(50),
    basic_salary NUMERIC(15,2) DEFAULT 0.00,
    hra NUMERIC(15,2) DEFAULT 0.00,
    special_allowance NUMERIC(15,2) DEFAULT 0.00,
    pf_opted BOOLEAN DEFAULT true,
    esi_opted BOOLEAN DEFAULT false,
    status VARCHAR(50) DEFAULT 'Active', -- 'Active', 'On Leave', 'Resigned', 'Terminated'
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS attendance_records (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    attendance_date DATE NOT NULL,
    status VARCHAR(50) NOT NULL, -- 'Present', 'Absent', 'Half Day', 'Leave', 'Holiday', 'WFH'
    check_in_time TIME,
    check_out_time TIME,
    notes TEXT,
    UNIQUE(employee_id, attendance_date)
);

CREATE TABLE IF NOT EXISTS leave_requests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    leave_type VARCHAR(50) NOT NULL, -- 'Casual Leave', 'Sick Leave', 'Earned Leave'
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    days_count INTEGER NOT NULL,
    reason TEXT,
    status VARCHAR(50) DEFAULT 'Pending', -- 'Pending', 'Approved', 'Rejected'
    approved_by UUID REFERENCES app_users(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payroll_records (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE RESTRICT,
    employee_name VARCHAR(255) NOT NULL,
    month_year VARCHAR(20) NOT NULL, -- e.g. "October 2026"
    working_days INTEGER DEFAULT 30,
    present_days NUMERIC(4,1) DEFAULT 30.0,
    basic_pay NUMERIC(15,2) NOT NULL,
    hra NUMERIC(15,2) DEFAULT 0.00,
    allowances NUMERIC(15,2) DEFAULT 0.00,
    bonus NUMERIC(15,2) DEFAULT 0.00,
    pf_deduction NUMERIC(15,2) DEFAULT 0.00,
    esi_deduction NUMERIC(15,2) DEFAULT 0.00,
    professional_tax NUMERIC(15,2) DEFAULT 200.00,
    tds_deduction NUMERIC(15,2) DEFAULT 0.00,
    net_salary NUMERIC(15,2) NOT NULL,
    payment_status VARCHAR(50) DEFAULT 'Draft', -- 'Draft', 'Approved', 'Paid'
    paid_date DATE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 14. FIXED ASSETS
CREATE TABLE IF NOT EXISTS fixed_assets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    asset_code VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL, -- 'Computers', 'Vehicles', 'Furniture', 'Machinery'
    purchase_date DATE NOT NULL,
    purchase_cost NUMERIC(15,2) NOT NULL,
    assigned_employee_id UUID REFERENCES employees(id) ON DELETE SET NULL,
    assigned_employee_name VARCHAR(255),
    location VARCHAR(150),
    warranty_expiry DATE,
    depreciation_rate NUMERIC(5,2) DEFAULT 10.00,
    current_value NUMERIC(15,2),
    status VARCHAR(50) DEFAULT 'In Use', -- 'In Use', 'Under Repair', 'Scrapped', 'Sold'
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 15. DOCUMENTS
CREATE TABLE IF NOT EXISTS erp_documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_url TEXT NOT NULL,
    file_type VARCHAR(100),
    file_size_kb INTEGER,
    category VARCHAR(100), -- 'Customer Document', 'Invoice Copy', 'Compliance', 'Contract'
    reference_type VARCHAR(50),
    reference_id VARCHAR(100),
    uploaded_by VARCHAR(255),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 16. NOTIFICATIONS
CREATE TABLE IF NOT EXISTS notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50) DEFAULT 'INFO', -- 'INFO', 'WARNING', 'ALERT', 'SUCCESS'
    link VARCHAR(255),
    is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- Multi-Tenant Isolation by company_id
-- ==============================================================================

ALTER TABLE companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE warehouses ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE warehouse_stocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE stock_movements ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE quotations ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchase_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchase_bills ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE chart_of_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE journal_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE payroll_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE fixed_assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE erp_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Helper function to get current company of authenticated user
CREATE OR REPLACE FUNCTION get_current_company_id()
RETURNS UUID AS $$
    SELECT company_id FROM app_users WHERE auth_user_id = auth.uid() LIMIT 1;
$$ LANGUAGE sql SECURITY DEFINER;

-- Generic Company Tenant Isolation Policy:
-- Allow operations if the company_id matches the user's company
CREATE POLICY company_isolation_policy ON customers FOR ALL
    USING (company_id = get_current_company_id() OR auth.role() = 'service_role');

CREATE POLICY invoice_isolation_policy ON invoices FOR ALL
    USING (company_id = get_current_company_id() OR auth.role() = 'service_role');

CREATE POLICY product_isolation_policy ON products FOR ALL
    USING (company_id = get_current_company_id() OR auth.role() = 'service_role');
