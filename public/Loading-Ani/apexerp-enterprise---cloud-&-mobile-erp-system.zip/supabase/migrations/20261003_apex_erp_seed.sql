-- ==============================================================================
-- APEX ERP ENTERPRISE - PRODUCTION SEED DATA SCRIPT
-- Run in Supabase SQL Editor to populate initial demo data
-- ==============================================================================

-- 1. Insert Initial Company
INSERT INTO companies (
    id, name, legal_name, email, phone, website,
    address_line1, address_line2, city, state, state_code, pincode, country,
    gstin, pan, cin, currency, currency_symbol,
    bank_name, bank_account_no, bank_ifsc, bank_branch, upi_id
) VALUES (
    'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
    'Apex Global Enterprises Pvt Ltd',
    'Apex Global Enterprises Private Limited',
    'finance@apexglobal.in',
    '+91 98300 12345',
    'https://apexglobal.in',
    'Sector V, Salt Lake Electronics Complex',
    'Block EP & GP, Tech Hub 4th Floor',
    'Kolkata', 'West Bengal', '19', '700091', 'India',
    '19AAACA1234F1Z8', 'AAACA1234F', 'U72200WB2020PTC234567',
    'INR', '₹',
    'HDFC Bank', '50200012345678', 'HDFC0000123', 'Salt Lake Sector V', 'apexglobal@hdfcbank'
) ON CONFLICT (id) DO NOTHING;

-- 2. Insert Warehouses
INSERT INTO warehouses (
    id, company_id, name, code, address, city, state, manager_name, contact_phone, is_primary, is_active
) VALUES 
(
    'b0eebc99-9c0b-4ef8-bb6d-6bb9bd380b22',
    'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
    'Central Tech Depot (Kolkata)', 'WH-KOL-01',
    'Salt Lake Sector V Logistics Wing', 'Kolkata', 'West Bengal',
    'Subhash Roy', '+91 98311 22334', true, true
),
(
    'c0eebc99-9c0b-4ef8-bb6d-6bb9bd380c33',
    'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
    'Western Hub (Mumbai)', 'WH-MUM-02',
    'MIDC Industrial Area, Andheri East', 'Mumbai', 'Maharashtra',
    'Amit Joshi', '+91 98200 44556', false, true
) ON CONFLICT (id) DO NOTHING;

-- 3. Insert Product Categories
INSERT INTO product_categories (id, company_id, name, code, description) VALUES
('d0eebc99-9c0b-4ef8-bb6d-6bb9bd380d44', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'Computer Hardware', 'HW', 'Servers, Laptops, Desktops'),
('e0eebc99-9c0b-4ef8-bb6d-6bb9bd380e55', 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11', 'Networking Equipment', 'NET', 'Routers, Switches, Fiber cables')
ON CONFLICT (id) DO NOTHING;

-- 4. Insert Products
INSERT INTO products (
    id, company_id, category_id, sku, name, brand, unit, hsn_sac, barcode,
    purchase_price, selling_price, mrp, tax_rate, is_tax_inclusive,
    min_stock_alert, max_stock, current_stock, description, status
) VALUES 
(
    'f0eebc99-9c0b-4ef8-bb6d-6bb9bd380f66',
    'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
    'd0eebc99-9c0b-4ef8-bb6d-6bb9bd380d44',
    'DELL-OPT-7090',
    'Dell OptiPlex 7090 Micro Desktop',
    'Dell', 'Pcs', '8471', '8901030928412',
    52000.00, 68500.00, 74999.00, 18.00, false,
    5, 50, 24,
    'Intel Core i7 11th Gen, 16GB DDR4, 512GB NVMe SSD, Win 11 Pro',
    'Active'
),
(
    '01eebc99-9c0b-4ef8-bb6d-6bb9bd380077',
    'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
    'e0eebc99-9c0b-4ef8-bb6d-6bb9bd380e55',
    'CISCO-CAT-C1000',
    'Cisco Catalyst 1000 24-Port Gigabit Switch',
    'Cisco', 'Pcs', '8517', '8901030928429',
    38000.00, 49500.00, 55000.00, 18.00, false,
    3, 25, 12,
    'Managed 24 Port Gigabit Ethernet Switch with 4x 1G SFP uplinks',
    'Active'
) ON CONFLICT (id) DO NOTHING;

-- 5. Insert Customers
INSERT INTO customers (
    id, company_id, customer_code, name, business_name, email, phone,
    gstin, pan, customer_type, billing_address, billing_city, billing_state, billing_pincode,
    credit_limit, credit_days, opening_balance, current_balance
) VALUES 
(
    '11eebc99-9c0b-4ef8-bb6d-6bb9bd380188',
    'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
    'CUST-001',
    'Tata Consultancy Systems Corp',
    'TCS Infotech Ltd',
    'vendor.procure@tcs-corp.in',
    '+91 98301 99887',
    '19AABCT1332L1ZF', 'AABCT1332L', 'B2B',
    'TCS Gitobitan, Salt Lake Sector V', 'Kolkata', 'West Bengal', '700091',
    500000.00, 30, 0.00, 80830.00
) ON CONFLICT (id) DO NOTHING;

-- 6. Insert Suppliers
INSERT INTO suppliers (
    id, company_id, supplier_code, name, company_name, email, phone,
    gstin, pan, address, city, state, pincode,
    bank_name, bank_account_no, bank_ifsc, credit_terms, opening_balance, current_balance
) VALUES 
(
    '22eebc99-9c0b-4ef8-bb6d-6bb9bd380299',
    'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11',
    'SUPP-001',
    'Redington India Distributors',
    'Redington India Ltd',
    'orders@redington.in',
    '+91 44 4224 3353',
    '33AABCR1234D1ZU', 'AABCR1234D',
    'SPL Guindy House, Mount Road', 'Chennai', 'Tamil Nadu', '600032',
    'ICICI Bank Ltd', '000405012345', 'ICIC0000004', 'Net 30', 0.00, 82000.00
) ON CONFLICT (id) DO NOTHING;
