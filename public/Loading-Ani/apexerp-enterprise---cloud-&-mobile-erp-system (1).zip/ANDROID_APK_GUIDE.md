# ApexERP Enterprise — Android Native APK & Capacitor Architecture

## 1. Overview & Mobile Strategy

ApexERP Enterprise employs a **unified codebase strategy**: the Android APK shares 100% of the database schema, business logic, GST tax calculations, and Supabase PostgreSQL persistence with the web and desktop applications.

- **Application ID**: `com.apexerp.app`
- **Application Name**: `ApexERP Enterprise`
- **Runtime Bridge**: Capacitor 8 Native Android Runtime
- **Target SDK**: Android 14 (API Level 34)
- **Minimum Supported SDK**: Android 5.1 Lollipop (API Level 22)
- **Supported Architectures**: Universal (`arm64-v8a`, `armeabi-v7a`, `x86_64`)

---

## 2. Configured Native Android Hardware Capabilities

The Android configuration is housed under `/android` and configured in `capacitor.config.ts`:

1. **Hardware Camera Barcode Scanner**:
   - `android.permission.CAMERA`
   - `android.hardware.camera` (with autofocus)
   - Used for scanning product EAN-13 barcodes, warehouse rack QR codes, and vendor invoice receipts.
2. **Network State & Seamless Offline Sync**:
   - `android.permission.ACCESS_NETWORK_STATE` & `android.permission.INTERNET`
   - Listens to native Android network status changes. Operations performed offline are cached in reactive client persistence and synced immediately when connectivity resumes.
3. **Storage Access**:
   - `android.permission.READ_EXTERNAL_STORAGE` & `android.permission.WRITE_EXTERNAL_STORAGE`
   - Allows saving and viewing official A4 GST tax invoices, payslips, and compliance reports directly in the Android filesystem.
4. **Haptic Touch Engine**:
   - Emits tactile feedback (`triggerHaptic('light' | 'medium' | 'heavy')`) upon invoice generation, stock adjustment, and barcode recognition.

---

## 3. Directory Layout for Android APK

```
/
├── capacitor.config.ts                     # Capacitor configuration
├── android/
│   ├── build.gradle                        # Top-level Gradle script
│   ├── settings.gradle                     # Project inclusion settings
│   ├── gradle.properties                   # JVM & AndroidX memory options
│   └── app/
│       ├── build.gradle                    # Application build config & dependencies
│       └── src/main/
│           ├── AndroidManifest.xml         # Permissions, activity, & deep links
│           ├── java/com/apexerp/app/
│           │   └── MainActivity.java       # Capacitor BridgeActivity
│           └── res/
│               ├── values/
│               │   ├── strings.xml         # App name & URL schemes
│               │   ├── colors.xml          # Primary brand colors (#4F46E5)
│               │   └── styles.xml          # Android splash & launch theme
│               └── xml/
│                   └── file_paths.xml      # FileProvider download paths
```

---

## 4. Step-by-Step APK Generation Commands

### Prerequisites
- Node.js 18+
- Android Studio Hedgehog (2023.1.1+) or newer, OR Android SDK command-line tools
- JDK 17 (OpenJDK 17)

### Command Sequence

```bash
# 1. Build the production web distribution
npm run build

# 2. Sync web assets and plugins into the Android native directory
npx cap sync android

# 3. Enter the Android directory
cd android

# 4. Compile the Debug APK
./gradlew assembleDebug

# Output APK Location:
# android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 5. Sideloading the APK onto an Android Device

To test on any physical Android phone or tablet:

1. Enable **Developer Options** and **USB Debugging** on the Android phone.
2. Connect the phone to your computer via USB.
3. Verify connection:
   ```bash
   adb devices
   ```
4. Install the generated APK:
   ```bash
   adb install android/app/build/outputs/apk/debug/app-debug.apk
   ```

---

## 6. Building Signed Release APK / AAB for Google Play Store

For production distribution:

```bash
cd android

# Generate release bundle (Android App Bundle .aab)
./gradlew bundleRelease

# Or generate signed standalone APK:
./gradlew assembleRelease
```
The release bundle will be generated at:
`android/app/build/outputs/bundle/release/app-release.aab`
