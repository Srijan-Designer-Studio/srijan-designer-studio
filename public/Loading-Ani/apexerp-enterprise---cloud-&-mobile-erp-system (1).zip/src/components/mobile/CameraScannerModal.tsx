import React, { useRef, useState, useEffect } from 'react';
import { Camera, X, Check, Flashlight, AlertCircle } from 'lucide-react';
import { triggerHaptic } from '../../lib/capacitor';

interface CameraScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScan: (code: string) => void;
}

export const CameraScannerModal: React.FC<CameraScannerModalProps> = ({
  isOpen,
  onClose,
  onScan,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [manualCode, setManualCode] = useState('');

  useEffect(() => {
    if (!isOpen) {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
        setStream(null);
      }
      return;
    }

    let isMounted = true;

    async function startCamera() {
      try {
        setErrorMsg(null);
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          const mediaStream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'environment' },
            audio: false,
          });
          if (isMounted) {
            setStream(mediaStream);
            if (videoRef.current) {
              videoRef.current.srcObject = mediaStream;
              videoRef.current.play();
            }
          }
        } else {
          setErrorMsg('Camera access is not supported in this browser environment.');
        }
      } catch (err: any) {
        console.warn('Camera error:', err);
        setErrorMsg('Camera permission not granted or device has no camera. You can simulate barcode entry below.');
      }
    }

    startCamera();

    return () => {
      isMounted = false;
      if (stream) {
        stream.getTracks().forEach((t) => t.stop());
      }
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    triggerHaptic('heavy');
    onScan(manualCode.trim());
    onClose();
  };

  const sampleBarcodes = [
    { code: '8901030928412', name: 'Dell OptiPlex 7090' },
    { code: '8901030928429', name: 'Cisco Catalyst 1000' },
    { code: '8901030928436', name: 'HP LaserJet MFP' },
    { code: '8901030928443', name: 'APC Smart-UPS 1KVA' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-lg rounded-3xl border border-slate-800 bg-slate-900 p-6 text-white shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-indigo-600/30 text-indigo-400">
              <Camera className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold">Android Native Camera Scanner</h3>
              <p className="text-[11px] text-slate-400">Scan Barcode / QR or simulate hardware scanner</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Camera Viewfinder */}
        <div className="mt-4 relative rounded-2xl overflow-hidden bg-black aspect-video flex items-center justify-center border border-slate-800">
          <video
            ref={videoRef}
            playsInline
            muted
            className="w-full h-full object-cover"
          />

          {/* Viewfinder Target Box Overlay */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-48 h-28 border-2 border-indigo-500 rounded-xl relative shadow-[0_0_15px_rgba(99,102,241,0.5)]">
              <div className="absolute -top-1 -left-1 w-3 h-3 border-t-2 border-l-2 border-white" />
              <div className="absolute -top-1 -right-1 w-3 h-3 border-t-2 border-r-2 border-white" />
              <div className="absolute -bottom-1 -left-1 w-3 h-3 border-b-2 border-l-2 border-white" />
              <div className="absolute -bottom-1 -right-1 w-3 h-3 border-b-2 border-r-2 border-white" />
              <div className="w-full h-0.5 bg-rose-500/80 absolute top-1/2 -translate-y-1/2 animate-pulse" />
            </div>
          </div>

          {errorMsg && (
            <div className="absolute inset-0 bg-slate-900/90 flex flex-col items-center justify-center p-4 text-center">
              <AlertCircle className="h-8 w-8 text-amber-400 mb-2" />
              <p className="text-xs text-slate-300 max-w-xs">{errorMsg}</p>
            </div>
          )}
        </div>

        {/* Quick Sample Clickers for instant testing */}
        <div className="mt-4 space-y-2">
          <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Simulate Scanned Product Barcodes:
          </p>
          <div className="grid grid-cols-2 gap-2">
            {sampleBarcodes.map((b) => (
              <button
                key={b.code}
                onClick={() => {
                  triggerHaptic('medium');
                  onScan(b.code);
                  onClose();
                }}
                className="text-left p-2 rounded-xl bg-slate-800/80 hover:bg-indigo-950 border border-slate-700/60 hover:border-indigo-500 transition text-xs"
              >
                <p className="font-semibold text-slate-200">{b.name}</p>
                <p className="text-[10px] font-mono text-indigo-400">{b.code}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Manual Barcode Entry */}
        <form onSubmit={handleManualSubmit} className="mt-4 flex gap-2">
          <input
            type="text"
            value={manualCode}
            onChange={(e) => setManualCode(e.target.value)}
            placeholder="Type or paste SKU / Barcode..."
            className="flex-1 rounded-xl border border-slate-700 bg-slate-800 p-2.5 text-xs text-white placeholder:text-slate-500 font-mono"
          />
          <button
            type="submit"
            className="rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-bold text-white hover:bg-indigo-700 transition"
          >
            Confirm
          </button>
        </form>
      </div>
    </div>
  );
};
