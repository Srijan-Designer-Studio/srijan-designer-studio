import React, { useState } from 'react';
import { 
  Smartphone, 
  Download, 
  Terminal, 
  CheckCircle2, 
  Copy, 
  Camera, 
  Wifi, 
  WifiOff, 
  RotateCw, 
  Maximize2,
  Package,
  Layers,
  ShieldCheck,
  Zap,
  ExternalLink
} from 'lucide-react';
import { isNativeCapacitor, triggerHaptic } from '../../lib/capacitor';

interface MobileHubProps {
  onOpenScanner: () => void;
}

export const MobileHub: React.FC<MobileHubProps> = ({ onOpenScanner }) => {
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);
  const [previewDevice, setPreviewDevice] = useState<'pixel' | 'tablet'>('pixel');
  const [isLandscape, setIsLandscape] = useState(false);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(text);
    triggerHaptic('light');
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  const gradleCommands = [
    { title: '1. Build Web Production Bundle', cmd: 'npm run build' },
    { title: '2. Synchronize Assets with Android Capacitor Project', cmd: 'npx cap sync android' },
    { title: '3. Compile Debug Android APK (.apk)', cmd: 'cd android && ./gradlew assembleDebug' },
    { title: '4. Sideload APK directly onto connected phone / tablet via ADB', cmd: 'adb install app/build/outputs/apk/debug/app-debug.apk' },
    { title: '5. Build Production Signed AAB for Google Play Console', cmd: 'cd android && ./gradlew bundleRelease' },
  ];

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white sm:text-2xl">
              Android APK & Native Mobile Hub
            </h1>
            <span className="rounded-full bg-emerald-100 px-2.5 py-0.5 text-[11px] font-bold text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
              CAPACITOR 8 READY
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Build, test, and deploy the unified Android application connecting to the exact same Supabase database.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenScanner}
            className="flex items-center gap-1.5 rounded-xl border border-indigo-600 bg-indigo-50 px-3.5 py-2 text-xs font-bold text-indigo-700 hover:bg-indigo-100 dark:bg-indigo-950 dark:text-indigo-300 transition"
          >
            <Camera className="h-4 w-4" />
            Test Camera Scanner
          </button>
        </div>
      </div>

      {/* APK Meta & Specs Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <p className="text-xs font-medium text-slate-500">Package Identifier</p>
          <p className="mt-1 text-sm font-mono font-bold text-slate-900 dark:text-white">
            com.apexerp.app
          </p>
          <p className="mt-2 text-[11px] text-slate-400">Android Application ID</p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <p className="text-xs font-medium text-slate-500">Target & Min SDK</p>
          <p className="mt-1 text-sm font-mono font-bold text-slate-900 dark:text-white">
            Target: API 34 (Android 14)
          </p>
          <p className="mt-2 text-[11px] text-slate-400">Min SDK: 22 (Android 5.1+)</p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <p className="text-xs font-medium text-slate-500">Hardware Features</p>
          <p className="mt-1 text-sm font-bold text-emerald-600">
            Camera, Haptics & Storage
          </p>
          <p className="mt-2 text-[11px] text-slate-400">Autofocus Barcode Scanner</p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <p className="text-xs font-medium text-slate-500">Database Engine</p>
          <p className="mt-1 text-sm font-bold text-indigo-600 dark:text-indigo-400">
            Unified Supabase DB
          </p>
          <p className="mt-2 text-[11px] text-slate-400">Offline-first reactive sync</p>
        </div>
      </div>

      {/* Main Grid: Device Interactive Live Emulator & Gradle Command Center */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left: Interactive Mobile Screen Emulator Frame (5 cols) */}
        <div className="lg:col-span-5 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 flex flex-col items-center">
          <div className="w-full flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">Live Mobile Emulator</h2>
              <p className="text-[11px] text-slate-500">Interactive Android touch viewport</p>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setIsLandscape(!isLandscape)}
                title="Rotate Orientation"
                className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300"
              >
                <RotateCw className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Smartphone Frame Outer Shell */}
          <div className="mt-6 flex justify-center">
            <div
              className={`relative border-[10px] border-slate-900 rounded-[44px] shadow-2xl bg-slate-900 overflow-hidden transition-all duration-300 ${
                isLandscape ? 'w-[520px] h-[300px]' : 'w-[310px] h-[580px]'
              }`}
            >
              {/* Speaker / Notch bar */}
              <div className="absolute top-2 left-1/2 -translate-x-1/2 w-28 h-4 bg-slate-900 rounded-full z-30 flex items-center justify-center">
                <div className="w-10 h-1 bg-slate-800 rounded-full" />
                <div className="w-2.5 h-2.5 bg-slate-800 rounded-full ml-2" />
              </div>

              {/* In-frame responsive applet preview iframe */}
              <iframe
                src="/"
                title="ApexERP Android APK Simulator"
                className="w-full h-full border-none pt-4 bg-slate-100 dark:bg-slate-950"
              />

              {/* Bottom Home Indicator */}
              <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-24 h-1 bg-slate-400/80 rounded-full z-30 pointer-events-none" />
            </div>
          </div>
          <p className="mt-4 text-[11px] text-slate-400 text-center">
            Testing real touch gestures, bottom navigation, and invoice flow in simulated APK.
          </p>
        </div>

        {/* Right: Build Pipeline, Gradle Setup & Native Manifest (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Step by Step Gradle Build Center */}
          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-3 dark:border-slate-800">
              <Terminal className="h-5 w-5 text-indigo-600" />
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                Android APK Compilation & CLI Guide
              </h2>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              The project contains the complete native Android codebase in <code className="rounded bg-slate-100 px-1.5 py-0.5 font-mono text-[11px] dark:bg-slate-800">/android</code> with Gradle build scripts, AndroidManifest.xml, and Capacitor BridgeActivity.
            </p>

            <div className="space-y-3">
              {gradleCommands.map((item, idx) => (
                <div
                  key={idx}
                  className="rounded-xl border border-slate-200 bg-slate-50/80 p-3 dark:border-slate-800 dark:bg-slate-800/50"
                >
                  <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">{item.title}</p>
                  <div className="mt-1 flex items-center justify-between rounded-lg bg-slate-900 px-3 py-2 text-xs font-mono text-emerald-400">
                    <span className="truncate pr-2">{item.cmd}</span>
                    <button
                      onClick={() => copyToClipboard(item.cmd)}
                      className="p-1 text-slate-400 hover:text-white transition shrink-0"
                      title="Copy command"
                    >
                      {copiedCmd === item.cmd ? (
                        <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Android Manifest Permissions Overview */}
          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-3 dark:border-slate-800">
              <ShieldCheck className="h-5 w-5 text-emerald-600" />
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                Configured Android Native Permissions
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-slate-900 dark:text-white">android.permission.CAMERA</p>
                  <p className="text-[11px] text-slate-500">Live barcode scanning & paper bill capture</p>
                </div>
              </div>

              <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-slate-900 dark:text-white">android.permission.INTERNET</p>
                  <p className="text-[11px] text-slate-500">Realtime Supabase PostgreSQL syncing</p>
                </div>
              </div>

              <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-slate-900 dark:text-white">ACCESS_NETWORK_STATE</p>
                  <p className="text-[11px] text-slate-500">Auto offline/online state detection</p>
                </div>
              </div>

              <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-slate-900 dark:text-white">VIBRATE / Haptics</p>
                  <p className="text-[11px] text-slate-500">Tactile confirmation on successful scan</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
