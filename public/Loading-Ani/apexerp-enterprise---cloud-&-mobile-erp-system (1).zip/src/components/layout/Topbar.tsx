import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Search, 
  Bell, 
  Camera, 
  Moon, 
  Sun, 
  Wifi, 
  WifiOff, 
  ChevronDown, 
  Plus, 
  ShieldCheck,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { db } from '../../lib/db';
import { scanBarcodeOrQr, triggerHaptic } from '../../lib/capacitor';
import { isSupabaseConfigured } from '../../lib/supabase';

interface TopbarProps {
  onOpenSearch: () => void;
  onOpenNotifications: () => void;
  onNewInvoice: () => void;
  onScanResult?: (code: string) => void;
  onOpenScanner?: () => void;
  activeModule: string;
  setActiveModule: (module: string) => void;
}

export const Topbar: React.FC<TopbarProps> = ({
  onOpenSearch,
  onOpenNotifications,
  onNewInvoice,
  onScanResult,
  onOpenScanner,
  setActiveModule,
}) => {
  const [dbState, setDbState] = useState(db.getState());
  const [isOnline, setIsOnline] = useState(true);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [showCompanyMenu, setShowCompanyMenu] = useState(false);

  useEffect(() => {
    const unsub = db.subscribe(() => setDbState(db.getState()));
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      unsub();
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const currentCompany = db.getCurrentCompany();
  const unreadNotifs = dbState.notifications.filter((n) => !n.is_read).length;

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    if (!isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const handleBarcodeScan = async () => {
    triggerHaptic('medium');
    if (onOpenScanner) {
      onOpenScanner();
      return;
    }
    const result = await scanBarcodeOrQr();
    if (result.hasContent) {
      triggerHaptic('heavy');
      if (onScanResult) {
        onScanResult(result.content);
      } else {
        alert(`Scanned Barcode: ${result.content}`);
      }
    }
  };

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-200 bg-white/95 px-4 backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/95 lg:px-6">
      {/* Left: Company Selector & Quick Switch */}
      <div className="flex items-center gap-3">
        <div className="relative">
          <button
            onClick={() => setShowCompanyMenu(!showCompanyMenu)}
            className="flex items-center gap-2.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-left text-sm font-medium text-slate-800 transition hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
          >
            <div className="flex h-7 w-7 items-center justify-center rounded-md bg-indigo-600 text-white font-bold text-xs shadow-sm">
              {currentCompany.name.slice(0, 2).toUpperCase()}
            </div>
            <div className="hidden sm:block">
              <p className="max-w-[180px] truncate text-xs font-semibold leading-tight text-slate-900 dark:text-white">
                {currentCompany.name}
              </p>
              <p className="text-[10px] text-slate-500 font-mono">
                {currentCompany.gstin || 'GST Unregistered'}
              </p>
            </div>
            <ChevronDown className="h-4 w-4 text-slate-400" />
          </button>

          {showCompanyMenu && (
            <div className="absolute left-0 mt-2 w-72 rounded-xl border border-slate-200 bg-white p-2 shadow-xl dark:border-slate-800 dark:bg-slate-900 z-50 animate-in fade-in zoom-in-95">
              <p className="px-2 py-1 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                Switch Business Entity
              </p>
              <div className="my-1 divide-y divide-slate-100 dark:divide-slate-800 max-h-60 overflow-y-auto">
                {dbState.companies.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => {
                      db.switchCompany(c.id);
                      setShowCompanyMenu(false);
                    }}
                    className={`flex w-full items-center justify-between rounded-lg p-2 text-left text-xs transition ${
                      c.id === currentCompany.id
                        ? 'bg-indigo-50 font-semibold text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400'
                        : 'text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div>
                      <p className="truncate font-medium">{c.name}</p>
                      <p className="text-[10px] text-slate-400 font-mono">{c.gstin || c.state}</p>
                    </div>
                    {c.id === currentCompany.id && (
                      <CheckCircle2 className="h-4 w-4 text-indigo-600 shrink-0" />
                    )}
                  </button>
                ))}
              </div>
              <div className="border-t border-slate-100 pt-2 dark:border-slate-800">
                <button
                  onClick={() => {
                    setShowCompanyMenu(false);
                    setActiveModule('settings');
                  }}
                  className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-xs font-medium text-indigo-600 hover:bg-indigo-50 dark:text-indigo-400 dark:hover:bg-indigo-950/50"
                >
                  <Plus className="h-3.5 w-3.5" />
                  Register New Company
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Supabase Status Pill */}
        <div 
          onClick={() => setActiveModule('settings')}
          className="hidden md:flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-medium cursor-pointer transition hover:opacity-90 border border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900/50 dark:bg-emerald-950/40 dark:text-emerald-400"
          title={isSupabaseConfigured ? 'Connected to live Supabase PostgreSQL' : 'Local Enterprise DB active (Sync ready)'}
        >
          <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>{isSupabaseConfigured ? 'Supabase Live' : 'Apex PostgreSQL DB'}</span>
        </div>
      </div>

      {/* Center: Global Search Trigger */}
      <div className="flex-1 max-w-md mx-4 hidden md:block">
        <button
          onClick={onOpenSearch}
          className="flex w-full items-center justify-between rounded-lg border border-slate-200 bg-slate-50/80 px-3.5 py-1.5 text-xs text-slate-500 transition hover:border-slate-300 hover:bg-white dark:border-slate-700 dark:bg-slate-800/80 dark:text-slate-400 dark:hover:bg-slate-800"
        >
          <div className="flex items-center gap-2">
            <Search className="h-4 w-4 text-slate-400" />
            <span>Search invoices, customers, items, employees...</span>
          </div>
          <kbd className="hidden sm:inline-block rounded border border-slate-300 bg-white px-1.5 py-0.5 text-[10px] font-mono text-slate-500 shadow-sm dark:border-slate-600 dark:bg-slate-900">
            Ctrl + K
          </kbd>
        </button>
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Mobile Search button */}
        <button
          onClick={onOpenSearch}
          className="md:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-lg dark:text-slate-300 dark:hover:bg-slate-800"
          aria-label="Search"
        >
          <Search className="h-5 w-5" />
        </button>

        {/* Quick New Invoice Button */}
        <button
          onClick={onNewInvoice}
          className="hidden sm:flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm hover:bg-indigo-700 active:scale-95 transition"
        >
          <Plus className="h-3.5 w-3.5" />
          <span>New Invoice</span>
        </button>

        {/* Barcode / Camera Scan (Capacitor & Web) */}
        <button
          onClick={handleBarcodeScan}
          title="Scan Barcode / QR Code"
          className="flex items-center justify-center p-2 rounded-lg text-slate-600 hover:bg-slate-100 hover:text-indigo-600 transition dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-indigo-400"
        >
          <Camera className="h-5 w-5" />
        </button>

        {/* Online / Offline status */}
        <div
          title={isOnline ? 'Online (Realtime connected)' : 'Offline mode (Changes will sync when online)'}
          className="p-2 text-slate-600 dark:text-slate-300"
        >
          {isOnline ? (
            <Wifi className="h-4 w-4 text-emerald-500" />
          ) : (
            <WifiOff className="h-4 w-4 text-amber-500 animate-pulse" />
          )}
        </div>

        {/* Notifications */}
        <button
          onClick={onOpenNotifications}
          className="relative p-2 text-slate-600 hover:bg-slate-100 rounded-lg dark:text-slate-300 dark:hover:bg-slate-800"
          aria-label="Notifications"
        >
          <Bell className="h-5 w-5" />
          {unreadNotifs > 0 && (
            <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[9px] font-bold text-white ring-2 ring-white dark:ring-slate-900">
              {unreadNotifs}
            </span>
          )}
        </button>

        {/* Dark Mode toggle */}
        <button
          onClick={toggleDarkMode}
          className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg dark:text-slate-300 dark:hover:bg-slate-800"
          aria-label="Toggle Theme"
        >
          {isDarkMode ? <Sun className="h-5 w-5 text-amber-400" /> : <Moon className="h-5 w-5" />}
        </button>

        {/* User Avatar */}
        <div className="flex items-center gap-2 pl-2 border-l border-slate-200 dark:border-slate-800">
          <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center text-white font-semibold text-xs shadow-sm">
            RP
          </div>
          <div className="hidden xl:block text-left">
            <p className="text-xs font-semibold text-slate-800 dark:text-slate-100 leading-none">
              {dbState.currentUser.name}
            </p>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">
              {dbState.currentUser.role_name}
            </p>
          </div>
        </div>
      </div>
    </header>
  );
};
