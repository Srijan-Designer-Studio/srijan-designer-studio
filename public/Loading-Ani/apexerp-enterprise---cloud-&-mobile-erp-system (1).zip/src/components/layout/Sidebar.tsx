import React from 'react';
import {
  LayoutDashboard,
  FileText,
  Users,
  Package,
  Warehouse,
  ShoppingCart,
  Truck,
  CreditCard,
  Receipt,
  BookOpen,
  UserCheck,
  Briefcase,
  FolderOpen,
  BarChart3,
  ShieldAlert,
  Settings,
  Sparkles,
  ChevronRight,
  LogOut,
  Layers,
  Smartphone
} from 'lucide-react';

export type ERPModule = 
  | 'dashboard'
  | 'invoices'
  | 'quotations'
  | 'customers'
  | 'products'
  | 'warehouses'
  | 'purchases'
  | 'suppliers'
  | 'payments'
  | 'expenses'
  | 'accounting'
  | 'hr'
  | 'assets'
  | 'documents'
  | 'reports'
  | 'audit'
  | 'settings'
  | 'mobile';

interface SidebarProps {
  activeModule: ERPModule;
  setActiveModule: (m: ERPModule) => void;
  isCollapsed: boolean;
  setIsCollapsed: (c: boolean) => void;
  mobileOpen: boolean;
  setMobileOpen: (o: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeModule,
  setActiveModule,
  isCollapsed,
  mobileOpen,
  setMobileOpen,
}) => {
  const navSections = [
    {
      title: 'CORE OPERATIONS',
      items: [
        { id: 'dashboard', label: 'Executive Dashboard', icon: LayoutDashboard },
        { id: 'invoices', label: 'GST Invoices', icon: FileText, badge: 'Active' },
        { id: 'quotations', label: 'Quotations & Estimates', icon: Layers },
        { id: 'customers', label: 'Customer CRM', icon: Users },
      ],
    },
    {
      title: 'SUPPLY CHAIN & INVENTORY',
      items: [
        { id: 'products', label: 'Products & Stock', icon: Package },
        { id: 'warehouses', label: 'Multi-Warehouses', icon: Warehouse },
        { id: 'purchases', label: 'Purchase Bills & POs', icon: ShoppingCart },
        { id: 'suppliers', label: 'Supplier Vendors', icon: Truck },
      ],
    },
    {
      title: 'FINANCE & ACCOUNTING',
      items: [
        { id: 'payments', label: 'Payment Transactions', icon: CreditCard },
        { id: 'expenses', label: 'Expense Management', icon: Receipt },
        { id: 'accounting', label: 'Double-Entry Ledger & P&L', icon: BookOpen, badge: 'Compliant' },
      ],
    },
    {
      title: 'HUMAN CAPITAL & ASSETS',
      items: [
        { id: 'hr', label: 'HR, Attendance & Payroll', icon: UserCheck },
        { id: 'assets', label: 'Fixed Asset Tracking', icon: Briefcase },
        { id: 'documents', label: 'Document Vault', icon: FolderOpen },
      ],
    },
    {
      title: 'INTELLIGENCE & GOVERNANCE',
      items: [
        { id: 'reports', label: 'Reports & GST Filing', icon: BarChart3 },
        { id: 'audit', label: 'Immutable Audit Trail', icon: ShieldAlert },
        { id: 'mobile', label: 'Android APK & Native Hub', icon: Smartphone, badge: 'Capacitor' },
        { id: 'settings', label: 'System & Supabase Settings', icon: Settings },
      ],
    },
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {mobileOpen && (
        <div
          onClick={() => setMobileOpen(false)}
          className="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-sm lg:hidden"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 flex flex-col border-r border-slate-200 bg-white transition-all duration-300 dark:border-slate-800 dark:bg-slate-900 lg:static ${
          mobileOpen ? 'translate-x-0 w-64' : '-translate-x-full lg:translate-x-0'
        } ${isCollapsed ? 'lg:w-20' : 'lg:w-64'}`}
      >
        {/* Brand Header */}
        <div className="flex h-16 items-center justify-between px-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-700 to-violet-600 text-white shadow-md shadow-indigo-500/20">
              <Sparkles className="h-5 w-5" />
            </div>
            {!isCollapsed && (
              <div className="text-left">
                <span className="text-base font-bold tracking-tight text-slate-900 dark:text-white">
                  Apex<span className="text-indigo-600 dark:text-indigo-400">ERP</span>
                </span>
                <span className="ml-1.5 rounded bg-indigo-100 px-1.5 py-0.5 text-[9px] font-semibold text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300">
                  ENTERPRISE
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Scrollable Nav Items */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
          {navSections.map((section, idx) => (
            <div key={idx} className="space-y-1">
              {!isCollapsed && (
                <p className="px-2 pb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  {section.title}
                </p>
              )}
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeModule === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveModule(item.id as ERPModule);
                      setMobileOpen(false);
                    }}
                    title={isCollapsed ? item.label : undefined}
                    className={`group flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-xs font-medium transition-all ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20 dark:bg-indigo-600'
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white'
                    } ${isCollapsed ? 'justify-center px-0' : 'justify-start'}`}
                  >
                    <Icon className={`h-4 w-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-700 dark:group-hover:text-slate-200'}`} />
                    {!isCollapsed && (
                      <div className="flex flex-1 items-center justify-between truncate">
                        <span className="truncate">{item.label}</span>
                        {item.badge && !isActive && (
                          <span className="rounded-full bg-slate-100 px-1.5 py-0.5 text-[9px] font-medium text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                            {item.badge}
                          </span>
                        )}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </div>

        {/* Bottom Status footer */}
        {!isCollapsed && (
          <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
            <div className="flex items-center justify-between text-[11px] text-slate-500">
              <span>Financial Year: 2026-27</span>
              <span className="font-mono text-emerald-600 font-semibold">Q3 LIVE</span>
            </div>
          </div>
        )}
      </aside>
    </>
  );
};
